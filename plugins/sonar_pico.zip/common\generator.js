// ============================================================
//  sonar_pico — generator.js
// ============================================================

Blockly.Arduino.forBlock['sonar_pico_read'] = function(block) {
  const trig = block.getFieldValue('TRIG');
  const echo = block.getFieldValue('ECHO');
  return [`sonarPico(${trig}, ${echo})`, Blockly.Arduino.ORDER_ATOMIC];
};
