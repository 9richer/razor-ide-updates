// ============================================================
//  sonar_pico — blocks.js
//  HC-SR04 Sonar สำหรับ Raspberry Pi Pico (RP2040)
// ============================================================

const _PICO_PINS = [
  ['GP0','0'],  ['GP1','1'],  ['GP2','2'],  ['GP3','3'],
  ['GP4','4'],  ['GP5','5'],  ['GP6','6'],  ['GP7','7'],
  ['GP8','8'],  ['GP9','9'],  ['GP10','10'],['GP11','11'],
  ['GP12','12'],['GP13','13'],['GP14','14'],['GP15','15'],
  ['GP16','16'],['GP17','17'],['GP18','18'],['GP19','19'],
  ['GP20','20'],['GP21','21'],['GP22','22'],
];

Blockly.Blocks['sonar_pico_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Sonar TRIG')
        .appendField(new Blockly.FieldDropdown(_PICO_PINS), 'TRIG')
        .appendField('ECHO')
        .appendField(new Blockly.FieldDropdown(_PICO_PINS), 'ECHO')
        .appendField('cm');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('วัดระยะด้วย HC-SR04 — คืนค่า cm, -1 ถ้าไม่พบวัตถุ (> 4m)');
  }
};
