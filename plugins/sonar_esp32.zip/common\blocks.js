// ============================================================
//  sonar_esp32 — blocks.js
//  HC-SR04 Sonar สำหรับ ESP32
// ============================================================

const _ESP32_PINS = [
  ['GPIO 2',  '2'],  ['GPIO 4',  '4'],  ['GPIO 5',  '5'],
  ['GPIO 12', '12'], ['GPIO 13', '13'], ['GPIO 14', '14'],
  ['GPIO 15', '15'], ['GPIO 16', '16'], ['GPIO 17', '17'],
  ['GPIO 18', '18'], ['GPIO 19', '19'], ['GPIO 21', '21'],
  ['GPIO 22', '22'], ['GPIO 23', '23'], ['GPIO 25', '25'],
  ['GPIO 26', '26'], ['GPIO 27', '27'], ['GPIO 32', '32'],
  ['GPIO 33', '33'],
];

Blockly.Blocks['sonar_esp32_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Sonar TRIG')
        .appendField(new Blockly.FieldDropdown(_ESP32_PINS), 'TRIG')
        .appendField('ECHO')
        .appendField(new Blockly.FieldDropdown(_ESP32_PINS), 'ECHO')
        .appendField('cm');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('วัดระยะด้วย HC-SR04 — คืนค่า cm, -1 ถ้าไม่พบวัตถุ (> 4m)');
  }
};
