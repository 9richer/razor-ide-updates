// ============================================================
//  sonar_esp32 — generator.js
// ============================================================

Blockly.Arduino.forBlock['sonar_esp32_read'] = function(block) {
  const trig = block.getFieldValue('TRIG');
  const echo = block.getFieldValue('ECHO');
  return [`sonarESP32(${trig}, ${echo})`, Blockly.Arduino.ORDER_ATOMIC];
};
