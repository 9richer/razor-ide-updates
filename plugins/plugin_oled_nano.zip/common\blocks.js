Blockly.Blocks['nano_oled_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED เริ่มต้น')
        .appendField('SDA: A4  SCL: A5 (Arduino Nano)');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('Init OLED บน Arduino Nano — I2C ใช้ A4(SDA), A5(SCL) เป็น hardware fixed');
  }
};

// ─── OLED Display / Clear / Update ───────────────────────────

Blockly.Blocks['nano_oled_show'] = {
  init: function() {
    this.appendValueInput('VALUE').appendField('OLED');
    this.appendDummyInput()
        .appendField('line')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2'],['3','3'],['4','4'],['5','5'],['6','6']]), 'LINE')
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2'],['3','3']]), 'SIZE');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('แสดงข้อความหรือค่าบน OLED');
  }
};

Blockly.Blocks['nano_oled_clear'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED ล้างหน้าจอ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('ล้างหน้าจอ OLED');
  }
};

Blockly.Blocks['nano_oled_update'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED แสดงผล');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8');
    this.setTooltip('สั่งให้จอแสดงผลจริง');
  }
};

Blockly.Blocks['nano_oled_xy'] = {
  init: function() {
    this.appendValueInput('VALUE')
        .appendField('🖥 OLED พิมพ์ที่ x')
        .appendField(new Blockly.FieldNumber(0,0,127), 'X')
        .appendField('y')
        .appendField(new Blockly.FieldNumber(0,0,63), 'Y')
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2'],['3','3']]), 'SIZE');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
  }
};

Blockly.Blocks['nano_oled_line'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED วาดเส้น x1').appendField(new Blockly.FieldNumber(0,0,127),'X1')
        .appendField('y1').appendField(new Blockly.FieldNumber(0,0,63),'Y1')
        .appendField('x2').appendField(new Blockly.FieldNumber(64,0,127),'X2')
        .appendField('y2').appendField(new Blockly.FieldNumber(32,0,63),'Y2');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
  }
};

Blockly.Blocks['nano_oled_rect'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED สี่เหลี่ยม x').appendField(new Blockly.FieldNumber(0,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(0,0,63),'Y')
        .appendField('w').appendField(new Blockly.FieldNumber(40,1,128),'W')
        .appendField('h').appendField(new Blockly.FieldNumber(20,1,64),'H');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
  }
};

Blockly.Blocks['nano_oled_fill_rect'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED สี่เหลี่ยมทึบ x').appendField(new Blockly.FieldNumber(0,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(0,0,63),'Y')
        .appendField('w').appendField(new Blockly.FieldNumber(40,1,128),'W')
        .appendField('h').appendField(new Blockly.FieldNumber(20,1,64),'H');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8');
  }
};

Blockly.Blocks['nano_oled_circle'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED วงกลม x').appendField(new Blockly.FieldNumber(64,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(32,0,63),'Y')
        .appendField('r').appendField(new Blockly.FieldNumber(10,1,32),'R');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
  }
};

Blockly.Blocks['nano_oled_fill_circle'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED วงกลมทึบ x').appendField(new Blockly.FieldNumber(64,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(32,0,63),'Y')
        .appendField('r').appendField(new Blockly.FieldNumber(10,1,32),'R');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8');
  }
};

Blockly.Blocks['nano_oled_invert'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED กลับสี')
        .appendField(new Blockly.FieldDropdown([['เปิด','true'],['ปิด','false']]), 'INVERT');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
  }
};

Blockly.Blocks['nano_oled_dim'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED ความสว่าง')
        .appendField(new Blockly.FieldDropdown([['หรี่','true'],['สว่าง','false']]), 'DIM');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
  }
};

Blockly.Blocks['nano_oled_progress'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED progress bar x').appendField(new Blockly.FieldNumber(0,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(50,0,63),'Y')
        .appendField('w').appendField(new Blockly.FieldNumber(128,1,128),'W')
        .appendField('h').appendField(new Blockly.FieldNumber(10,1,32),'H');
    this.appendValueInput('VALUE').appendField('%');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#059669');
  }
};
