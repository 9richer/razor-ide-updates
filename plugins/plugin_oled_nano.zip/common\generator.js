Blockly.Arduino.forBlock['nano_oled_begin'] = function() {
  return 'oled_nano_begin();\n';
};

Blockly.Arduino.forBlock['nano_oled_show'] = function(block) {
  var inputBlock = block.getInputTargetBlock('VALUE');
  var value = '""';
  if (inputBlock) {
    if (inputBlock.type === 'text') {
      var txt = inputBlock.getFieldValue('TEXT') || '';
      txt = txt.split('"').join('\"');
      value = '"' + txt + '"';
    } else {
      value = Blockly.Arduino.valueToCode(block, 'VALUE', Blockly.Arduino.ORDER_ATOMIC) || '""';
    }
  }
  var line = block.getFieldValue('LINE') || '1';
  var size = block.getFieldValue('SIZE') || '1';
  return 'oled(' + line + ', ' + value + ', ' + size + ');\n';
};

Blockly.Arduino.forBlock['nano_oled_clear']  = function() { return 'oled_clear();\n'; };
Blockly.Arduino.forBlock['nano_oled_update'] = function() { return 'oled_update();\n'; };

Blockly.Arduino.forBlock['nano_oled_xy'] = function(block) {
  var x=block.getFieldValue('X'), y=block.getFieldValue('Y'), size=block.getFieldValue('SIZE');
  var inputBlock = block.getInputTargetBlock('VALUE');
  var value = '""';
  if (inputBlock) {
    if (inputBlock.type === 'text') {
      var txt = inputBlock.getFieldValue('TEXT') || '';
      txt = txt.split('"').join('\"');
      value = '"' + txt + '"';
    } else {
      value = Blockly.Arduino.valueToCode(block,'VALUE',Blockly.Arduino.ORDER_ATOMIC)||'""';
    }
  }
  return 'oled_xy('+x+','+y+','+value+','+size+');\n';
};

Blockly.Arduino.forBlock['nano_oled_line'] = function(block) {
  return 'oled_line('+block.getFieldValue('X1')+','+block.getFieldValue('Y1')+','+block.getFieldValue('X2')+','+block.getFieldValue('Y2')+');\n';
};
Blockly.Arduino.forBlock['nano_oled_rect'] = function(block) {
  return 'oled_rect('+block.getFieldValue('X')+','+block.getFieldValue('Y')+','+block.getFieldValue('W')+','+block.getFieldValue('H')+');\n';
};
Blockly.Arduino.forBlock['nano_oled_fill_rect'] = function(block) {
  return 'oled_fill_rect('+block.getFieldValue('X')+','+block.getFieldValue('Y')+','+block.getFieldValue('W')+','+block.getFieldValue('H')+');\n';
};
Blockly.Arduino.forBlock['nano_oled_circle'] = function(block) {
  return 'oled_circle('+block.getFieldValue('X')+','+block.getFieldValue('Y')+','+block.getFieldValue('R')+');\n';
};
Blockly.Arduino.forBlock['nano_oled_fill_circle'] = function(block) {
  return 'oled_fill_circle('+block.getFieldValue('X')+','+block.getFieldValue('Y')+','+block.getFieldValue('R')+');\n';
};
Blockly.Arduino.forBlock['nano_oled_invert'] = function(block) {
  return 'oled_invert('+block.getFieldValue('INVERT')+');\n';
};
Blockly.Arduino.forBlock['nano_oled_dim'] = function(block) {
  return 'oled_dim('+block.getFieldValue('DIM')+');\n';
};
Blockly.Arduino.forBlock['nano_oled_progress'] = function(block) {
  var x=block.getFieldValue('X'),y=block.getFieldValue('Y'),w=block.getFieldValue('W'),h=block.getFieldValue('H');
  var val=Blockly.Arduino.valueToCode(block,'VALUE',Blockly.Arduino.ORDER_ATOMIC)||'0';
  return 'oled_progress('+x+','+y+','+w+','+h+','+val+');\n';
};
