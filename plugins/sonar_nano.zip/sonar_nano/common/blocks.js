// ============================================================
//  sonar_nano — blocks.js
//  HC-SR04 Sonar สำหรับ Arduino Nano
// ============================================================

const _NANO_PINS = [
  ['D2', '2'], ['D3', '3'], ['D4', '4'],  ['D5', '5'],
  ['D6', '6'], ['D7', '7'], ['D8', '8'],  ['D9', '9'],
  ['D10','10'],['D11','11'],['D12','12'],
];

// ── sonar_nano_read — วัดระยะ (คืน Number) ──────────────────
Blockly.Blocks['sonar_nano_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Sonar TRIG')
        .appendField(new Blockly.FieldDropdown(_NANO_PINS), 'TRIG')
        .appendField('ECHO')
        .appendField(new Blockly.FieldDropdown(_NANO_PINS), 'ECHO')
        .appendField('cm');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('วัดระยะด้วย HC-SR04 — คืนค่า cm, -1 ถ้าไม่พบวัตถุ (> 4m)');
  }
};
