// ============================================================
//  sonar_nano — generator.js
// ============================================================

Blockly.Arduino.forBlock['sonar_nano_read'] = function(block) {
  const trig = block.getFieldValue('TRIG');
  const echo = block.getFieldValue('ECHO');
  return [`sonarNano(${trig}, ${echo})`, Blockly.Arduino.ORDER_ATOMIC];
};
