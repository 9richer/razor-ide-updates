Blockly.Blocks['esp32_oled32_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 เริ่มต้น SDA')
        .appendField(new Blockly.FieldDropdown([
          ['21','21'],['22','22'],['23','23'],
          ['25','25'],['26','26'],['27','27'],
          ['32','32'],['33','33'],
        ]), 'SDA')
        .appendField('SCL')
        .appendField(new Blockly.FieldDropdown([
          ['21','21'],['22','22'],['23','23'],
          ['25','25'],['26','26'],['27','27'],
          ['32','32'],['33','33'],
        ]), 'SCL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('Init OLED32 บน ESP32 — เลือก SDA/SCL GPIO ได้');
  }
};

// ─── OLED32 Display / Clear / Update ───────────────────────────

Blockly.Blocks['esp32_oled32_show'] = {
  init: function() {
    this.appendValueInput('VALUE').appendField('OLED');
    this.appendDummyInput()
        .appendField('line')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2'],['3','3'],['4','4'],['5','5'],['6','6']]), 'LINE')
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2'],['3','3']]), 'SIZE');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('แสดงข้อความหรือค่าบน OLED');
  }
};

Blockly.Blocks['esp32_oled32_clear'] = {
  init: function() {
    this.appendDummyInput().appendField('📺 OLED3232 ล้างหน้าจอ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('ล้างหน้าจอ OLED');
  }
};

Blockly.Blocks['esp32_oled32_update'] = {
  init: function() {
    this.appendDummyInput().appendField('📺 OLED3232 แสดงผล');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('สั่งให้จอแสดงผลจริง');
  }
};

Blockly.Blocks['esp32_oled32_xy'] = {
  init: function() {
    this.appendValueInput('VALUE')
        .appendField('📺 OLED3232 พิมพ์ที่ x')
        .appendField(new Blockly.FieldNumber(0,0,127), 'X')
        .appendField('y')
        .appendField(new Blockly.FieldNumber(0,0,63), 'Y')
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2'],['3','3']]), 'SIZE');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
  }
};

Blockly.Blocks['esp32_oled32_line'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 วาดเส้น x1').appendField(new Blockly.FieldNumber(0,0,127),'X1')
        .appendField('y1').appendField(new Blockly.FieldNumber(0,0,63),'Y1')
        .appendField('x2').appendField(new Blockly.FieldNumber(64,0,127),'X2')
        .appendField('y2').appendField(new Blockly.FieldNumber(32,0,63),'Y2');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
  }
};

Blockly.Blocks['esp32_oled32_rect'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 สี่เหลี่ยม x').appendField(new Blockly.FieldNumber(0,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(0,0,63),'Y')
        .appendField('w').appendField(new Blockly.FieldNumber(40,1,128),'W')
        .appendField('h').appendField(new Blockly.FieldNumber(20,1,64),'H');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
  }
};

Blockly.Blocks['esp32_oled32_fill_rect'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 สี่เหลี่ยมทึบ x').appendField(new Blockly.FieldNumber(0,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(0,0,63),'Y')
        .appendField('w').appendField(new Blockly.FieldNumber(40,1,128),'W')
        .appendField('h').appendField(new Blockly.FieldNumber(20,1,64),'H');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
  }
};

Blockly.Blocks['esp32_oled32_circle'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 วงกลม x').appendField(new Blockly.FieldNumber(64,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(32,0,63),'Y')
        .appendField('r').appendField(new Blockly.FieldNumber(10,1,32),'R');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
  }
};

Blockly.Blocks['esp32_oled32_fill_circle'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 วงกลมทึบ x').appendField(new Blockly.FieldNumber(64,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(32,0,63),'Y')
        .appendField('r').appendField(new Blockly.FieldNumber(10,1,32),'R');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
  }
};

Blockly.Blocks['esp32_oled32_invert'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 กลับสี')
        .appendField(new Blockly.FieldDropdown([['เปิด','true'],['ปิด','false']]), 'INVERT');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
  }
};

Blockly.Blocks['esp32_oled32_dim'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 ความสว่าง')
        .appendField(new Blockly.FieldDropdown([['หรี่','true'],['สว่าง','false']]), 'DIM');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
  }
};

Blockly.Blocks['esp32_oled32_progress'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📺 OLED3232 progress bar x').appendField(new Blockly.FieldNumber(0,0,127),'X')
        .appendField('y').appendField(new Blockly.FieldNumber(50,0,63),'Y')
        .appendField('w').appendField(new Blockly.FieldNumber(128,1,128),'W')
        .appendField('h').appendField(new Blockly.FieldNumber(10,1,32),'H');
    this.appendValueInput('VALUE').appendField('%');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#059669');
  }
};
