// ==========================================
// RazorS4-Python Generator
// block → MicroPython code
// ==========================================

Blockly.Python.forBlock['py_wait_ms'] = function(block) {
  const t = block.getFieldValue('time');
  return 'utime.sleep_ms(' + t + ')\n';
};

Blockly.Python.forBlock['py_beep'] = function(block) {
  return 'robot.beep()\n';
};

Blockly.Python.forBlock['py_wait_go'] = function(block) {
  return 'robot.wait_go()\n';
};

Blockly.Python.forBlock['py_motor_set'] = function(block) {
  const motor = block.getFieldValue('MOTOR');
  const dir   = block.getFieldValue('DIR');
  const spd   = Blockly.Python.valueToCode(block, 'SPD', Blockly.Python.ORDER_ATOMIC) || '0';
  return 'robot.motor("' + motor + '","' + dir + '",' + spd + ')\n';
};

Blockly.Python.forBlock['py_stop_motor'] = function(block) {
  return 'robot.stop()\n';
};

Blockly.Python.forBlock['py_robot_move'] = function(block) {
  const dir = block.getFieldValue('DIR');
  const spd = Blockly.Python.valueToCode(block, 'SPD', Blockly.Python.ORDER_ATOMIC) || '0';
  return 'robot.move("' + dir + '",' + spd + ')\n';
};

Blockly.Python.forBlock['py_oled_show'] = function(block) {
  const text = Blockly.Python.valueToCode(block, 'TEXT', Blockly.Python.ORDER_ATOMIC) || "''";
  const line = block.getFieldValue('LINE') || '1';
  return 'oled.show(' + text + ', ' + line + ')\n';
};

Blockly.Python.forBlock['py_oled_clear'] = function(block) {
  return 'oled.clear()\n';
};

Blockly.Python.forBlock['py_oled_update'] = function(block) {
  return 'oled.update()\n';
};

Blockly.Python.forBlock['py_forever'] = function(block) {
  const body = Blockly.Python.statementToCode(block, 'DO') || '    pass\n';
  return 'while True:\n' + body;
};

// ── Arduino generator aliases — ใช้กับ Live Code preview ──
// Live Code ใช้ Blockly.Arduino ในการ generate preview
// py_* blocks ต้องมี Arduino generator ด้วย ไม่งั้น error
[
  'py_wait_ms','py_beep','py_wait_go','py_motor_set',
  'py_stop_motor','py_robot_move','py_oled_show',
  'py_oled_clear','py_oled_update','py_forever'
].forEach(function(type) {
  if (Blockly.Arduino && !Blockly.Arduino.forBlock[type]) {
    Blockly.Arduino.forBlock[type] = Blockly.Python.forBlock[type];
  }
});