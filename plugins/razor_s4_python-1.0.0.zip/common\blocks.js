// ==========================================
// RazorS4-Python Blocks
// ==========================================

// --- Time ---
Blockly.Blocks['py_wait_ms'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('รอ')
        .appendField(new Blockly.FieldNumber(1000, 0), 'time')
        .appendField('ms');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(0);
    this.setTooltip('หน่วงเวลา (ms)');
  }
};

// --- Sound ---
Blockly.Blocks['py_beep'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Beep');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(300);
    this.setTooltip('เปิดเสียงบีบ');
  }
};

// --- Sensor ---
Blockly.Blocks['py_wait_go'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('รอปุ่มเริ่ม');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#16a34a');
    this.setTooltip('รอจนกว่าจะกดปุ่มเริ่ม');
  }
};

// --- Motor ---
Blockly.Blocks['py_motor_set'] = {
  init: function() {
    this.appendValueInput('SPD')
        .setCheck('Number')
        .appendField('Motor')
        .appendField(new Blockly.FieldDropdown([
          ['ซ้าย','L'], ['ขวา','R'], ['ทั้งคู่','B']
        ]), 'MOTOR')
        .appendField(new Blockly.FieldDropdown([
          ['หน้า','F'], ['หลัง','B'], ['หยุด','S']
        ]), 'DIR')
        .appendField('ความเร็ว');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#c2410c');
    this.setTooltip('ควบคุมมอเตอร์');
  }
};

Blockly.Blocks['py_stop_motor'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('หยุดมอเตอร์');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#c2410c');
    this.setTooltip('หยุดมอเตอร์ทั้งหมด');
  }
};

Blockly.Blocks['py_robot_move'] = {
  init: function() {
    this.appendValueInput('SPD')
        .setCheck('Number')
        .appendField('หุ่นยนต์')
        .appendField(new Blockly.FieldDropdown([
          ['เดินหน้า','F'], ['ถอยหลัง','B'],
          ['เลี้ยวซ้าย','L'], ['เลี้ยวขวา','R']
        ]), 'DIR')
        .appendField('ความเร็ว');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#c2410c');
    this.setTooltip('สั่งให้หุ่นยนต์เคลื่อนที่');
  }
};

// --- OLED ---
Blockly.Blocks['py_oled_show'] = {
  init: function() {
    this.appendValueInput('TEXT')
        .setCheck('String')
        .appendField('OLED แสดง');
    this.appendDummyInput()
        .appendField('บรรทัด')
        .appendField(new Blockly.FieldDropdown([
          ['1','1'],['2','2'],['3','3'],
          ['4','4'],['5','5'],['6','6']
        ]), 'LINE');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('แสดงข้อความบน OLED');
  }
};

Blockly.Blocks['py_oled_clear'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('OLED ล้างหน้าจอ');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('ล้างหน้าจอ OLED');
  }
};

Blockly.Blocks['py_oled_update'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('OLED แสดงผล (update)');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('flush buffer ไปที่จอ — ใช้หลัง OLED แสดง หลายบรรทัด');
  }
};

// --- Forever ---
Blockly.Blocks['py_forever'] = {
  init: function() {
    this.appendStatementInput('DO')
        .appendField('Forever');
    this.setColour('#ff3366');
    this.setPreviousStatement(true);
    this.setNextStatement(false);
    this.setTooltip('วนซ้ำตลอดเวลา');
  }
};
