# ============================================================
#  razors4.py — MicroPython library for RazorS4 (RP2040)
#  แปลงจาก RazorS4.h + motor_razors4.h + myoled.h (C++)
#  ขาต่างๆ ตรงกับ C++ ทุกขา
# ============================================================

from machine import Pin, PWM, I2C
import utime
import ssd1306

# ============================================================
#  PIN MAP (ตรงกับ C++ motor_razors4.h + RazorS4.h)
# ============================================================
# Motor 1 (ซ้ายหน้า)  PWM=0  DIR1=11  DIR2=12
# Motor 2 (ซ้ายหลัง) PWM=1  DIR1=20  DIR2=21
# Motor 3 (ขวาหน้า)  PWM=2  DIR1=15  DIR2=22
# Motor 4 (ขวาหลัง)  PWM=3  DIR1=13  DIR2=14
# Buzzer              PIN=9
# SW Go               PIN=10
# OLED SDA=26  SCL=27  (Wire1 ใน C++)

# ============================================================
#  _Motor — ควบคุมมอเตอร์ 1 ตัว
# ============================================================
class _Motor:
    def __init__(self, pwm_pin, dir1_pin, dir2_pin):
        self._pwm  = PWM(Pin(pwm_pin))
        self._pwm.freq(1000)
        self._dir1 = Pin(dir1_pin, Pin.OUT)
        self._dir2 = Pin(dir2_pin, Pin.OUT)

    def set(self, speed):
        # speed: -100 ถึง 100
        if speed > 100:  speed = 100
        if speed < -100: speed = -100

        duty = int(abs(speed) * 65535 // 100)

        if speed > 0:
            self._dir1.value(1)
            self._dir2.value(0)
            self._pwm.duty_u16(duty)
        elif speed < 0:
            self._dir1.value(0)
            self._dir2.value(1)
            self._pwm.duty_u16(duty)
        else:
            # brake
            self._dir1.value(0)
            self._dir2.value(0)
            self._pwm.duty_u16(65535)

# ============================================================
#  RazorS4 — class หลัก
# ============================================================
class RazorS4:
    def __init__(self):
        self._m1 = _Motor(0,  11, 12)
        self._m2 = _Motor(1,  20, 21)
        self._m3 = _Motor(2,  15, 22)
        self._m4 = _Motor(3,  13, 14)
        self._buzzer = Pin(9, Pin.OUT)
        self._sw     = Pin(10, Pin.IN, Pin.PULL_UP)

    # ── Buzzer ──────────────────────────────────────────────
    def beep(self, freq=1000, ms=200):
        bz = PWM(self._buzzer)
        bz.freq(freq)
        bz.duty_u16(32768)   # 50% duty
        utime.sleep_ms(ms)
        bz.duty_u16(0)
        bz.deinit()
        utime.sleep_ms(100)

    # ── Switch ──────────────────────────────────────────────
    def wait_go(self):
        """รอกดปุ่ม SW10 แล้วบีบเสียงยืนยัน (เหมือน sw_go() ใน C++)"""
        while True:
            if self._sw.value() == 0:
                break
            utime.sleep_ms(10)
        self.beep()

    def sw(self):
        """อ่านสถานะปุ่ม SW10: True = กด"""
        return self._sw.value() == 0

    # ── Motor ──────────────────────────────────────────────
    def motor(self, side, direction, speed):
        """
        side:      'L'=ซ้าย  'R'=ขวา  'B'=ทั้งคู่
        direction: 'F'=หน้า  'B'=หลัง  'S'=หยุด
        speed:     0-100
        """
        if direction == 'B': speed = -speed
        if direction == 'S': speed = 0

        if side == 'L' or side == 'B':
            self._m1.set(speed)
            self._m2.set(speed)
        if side == 'R' or side == 'B':
            self._m3.set(speed)
            self._m4.set(speed)

    def motorL(self, speed):
        """มอเตอร์ซ้าย -100 ถึง 100"""
        self._m1.set(speed)
        self._m2.set(speed)

    def motorR(self, speed):
        """มอเตอร์ขวา -100 ถึง 100"""
        self._m3.set(speed)
        self._m4.set(speed)

    def move(self, direction, speed):
        """
        direction: 'F'=หน้า  'B'=หลัง  'L'=เลี้ยวซ้าย  'R'=เลี้ยวขวา
        speed:     0-100
        """
        if direction == 'F':
            self.motorL(speed);  self.motorR(speed)
        elif direction == 'B':
            self.motorL(-speed); self.motorR(-speed)
        elif direction == 'L':   # หมุนซ้าย (sl)
            self.motorL(-speed); self.motorR(speed)
        elif direction == 'R':   # หมุนขวา (sr)
            self.motorL(speed);  self.motorR(-speed)

    def stop(self):
        """หยุดมอเตอร์ทั้งหมด (ao ใน C++)"""
        self._m1.set(0)
        self._m2.set(0)
        self._m3.set(0)
        self._m4.set(0)

# ============================================================
#  OLED — SSD1306 128x64  SDA=26  SCL=27 (Wire1 ใน C++)
# ============================================================
class OLED:
    def __init__(self):
        i2c = I2C(1, sda=Pin(26), scl=Pin(27), freq=400000)
        self._d = ssd1306.SSD1306_I2C(128, 64, i2c, addr=0x3C)
        self._d.fill(0)
        self._d.show()

    def show(self, text, line=1, auto_update=True):
        """แสดงข้อความที่ line (1-8)
        1 บรรทัด  → ใช้ได้เลย ไม่ต้องเรียก update()
        หลายบรรทัด → เรียก show(...) หลายครั้ง แล้วค่อย update() ครั้งเดียว
                       เพื่อไม่ให้กระพริบ ใช้ show(text, line, False) + update()
        """
        y = (line - 1) * 8   # FIX: 8px ต่อบรรทัด = 8 บรรทัดพอดี 64px
        if y < 0:  y = 0
        if y > 56: y = 56    # ป้องกันเกิน 64px (64-8=56)
        self._d.fill_rect(0, y, 128, 8, 0)
        self._d.text(str(text), 0, y)
        if auto_update:
            self._d.show()

    def clear(self):
        self._d.fill(0)
        self._d.show()

    def update(self):
        """flush buffer ไปที่จอ — ใช้หลัง show() หลายบรรทัด"""
        self._d.show()