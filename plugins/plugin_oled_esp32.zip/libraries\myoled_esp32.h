#pragma once
#include "Adafruit_GFX.h"
#include "Adafruit_SSD1306.h"

#define OLED_SCREEN_WIDTH  128
#define OLED_SCREEN_HEIGHT 64
#define OLED_ADDR          0x3C

Adafruit_SSD1306 display(OLED_SCREEN_WIDTH, OLED_SCREEN_HEIGHT, &Wire, -1);

// ESP32 I2C — เลือก SDA, SCL ได้อิสระ
void oled_esp32_begin(int sda, int scl) {
  Wire.begin(sda, scl);
  display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.display();
}

void oled_clear()  { display.clearDisplay(); }
void oled_update() { display.display(); }

template<typename T>
void oled(int line, T value, int size = 1) {
  display.setTextSize(size);
  display.setCursor(0, (line - 1) * (size * 10));
  display.println(value);
}

void oled_line(int x1,int y1,int x2,int y2)           { display.drawLine(x1,y1,x2,y2,SSD1306_WHITE); }
void oled_rect(int x,int y,int w,int h)                { display.drawRect(x,y,w,h,SSD1306_WHITE); }
void oled_fill_rect(int x,int y,int w,int h)           { display.fillRect(x,y,w,h,SSD1306_WHITE); }
void oled_circle(int x,int y,int r)                    { display.drawCircle(x,y,r,SSD1306_WHITE); }
void oled_fill_circle(int x,int y,int r)               { display.fillCircle(x,y,r,SSD1306_WHITE); }
void oled_invert(bool inv)                              { display.invertDisplay(inv); }
void oled_dim(bool dim)                                 { display.dim(dim); }

template<typename T>
void oled_xy(int x,int y,T value,int size=1) {
  display.setTextSize(size);
  display.setCursor(x,y);
  display.print(value);
}

void oled_progress(int x,int y,int w,int h,int value) {
  if(value<0) value=0; if(value>100) value=100;
  display.drawRect(x,y,w,h,SSD1306_WHITE);
  int fw=(int)((w-2)*value/100.0);
  if(fw>0) display.fillRect(x+1,y+1,fw,h-2,SSD1306_WHITE);
}
