// ============================================================
//  Servo generators — srv_pico
// ============================================================

Blockly.Arduino.forBlock['srv_pico_servo_attach'] = function(block) {
  var pin = block.getFieldValue('PIN');
  return 'servo_attach(' + pin + ');\n';
};

Blockly.Arduino.forBlock['srv_pico_servo'] = function(block) {
  var pin   = block.getFieldValue('PIN');
  var angle = Blockly.Arduino.valueToCode(block, 'ANGLE', Blockly.Arduino.ORDER_ATOMIC) || '90';
  var speed = Blockly.Arduino.valueToCode(block, 'SPEED', Blockly.Arduino.ORDER_ATOMIC) || '5';
  return 'servo(' + pin + ', ' + angle + ', ' + speed + ');\n';
};

Blockly.Arduino.forBlock['srv_pico_servo_write'] = function(block) {
  var pin   = block.getFieldValue('PIN');
  var angle = Blockly.Arduino.valueToCode(block, 'ANGLE', Blockly.Arduino.ORDER_ATOMIC) || '90';
  return 'servo_write(' + pin + ', ' + angle + ');\n';
};

Blockly.Arduino.forBlock['srv_pico_servo_us'] = function(block) {
  var pin = block.getFieldValue('PIN');
  var us  = Blockly.Arduino.valueToCode(block, 'US', Blockly.Arduino.ORDER_ATOMIC) || '1500';
  return 'servo_us(' + pin + ', ' + us + ');\n';
};

Blockly.Arduino.forBlock['srv_pico_servo_read'] = function(block) {
  var pin = block.getFieldValue('PIN');
  return ['servo_read(' + pin + ')', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['srv_pico_servo_detach'] = function(block) {
  var pin = block.getFieldValue('PIN');
  return 'servo_detach(' + pin + ');\n';
};

Blockly.Arduino.forBlock['srv_pico_servo_sweep'] = function(block) {
  var pin   = block.getFieldValue('PIN');
  var speed = Blockly.Arduino.valueToCode(block, 'SPEED', Blockly.Arduino.ORDER_ATOMIC) || '5';
  return 'servo_sweep(' + pin + ', ' + speed + ');\n';
};
