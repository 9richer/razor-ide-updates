// ============================================================
//  Servo blocks — srv_pico
//  ขาที่รองรับ: GP0, GP1, GP2, GP3, GP4, GP5, GP6, GP7, GP8, GP9, GP10, GP11, GP12, GP13, GP14, GP15, GP18, GP19, GP20, GP21, GP26, GP27, GP28
// ============================================================

// ── 1. servo_attach — กำหนดขา ─────────────────────────────
Blockly.Blocks['srv_pico_servo_attach'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo กำหนดขา')
        .appendField(new Blockly.FieldDropdown([['GP0','0'],['GP1','1'],['GP2','2'],['GP3','3'],['GP4','4'],['GP5','5'],['GP6','6'],['GP7','7'],['GP8','8'],['GP9','9'],['GP10','10'],['GP11','11'],['GP12','12'],['GP13','13'],['GP14','14'],['GP15','15'],['GP18','18'],['GP19','19'],['GP20','20'],['GP21','21'],['GP26','26'],['GP27','27'],['GP28','28']]), 'PIN');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip('กำหนดขา PWM สำหรับ Servo motor');
  }
};

// ── 2. servo() — หมุนพร้อม speed ──────────────────────────
Blockly.Blocks['srv_pico_servo'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo ขา')
        .appendField(new Blockly.FieldDropdown([['GP0','0'],['GP1','1'],['GP2','2'],['GP3','3'],['GP4','4'],['GP5','5'],['GP6','6'],['GP7','7'],['GP8','8'],['GP9','9'],['GP10','10'],['GP11','11'],['GP12','12'],['GP13','13'],['GP14','14'],['GP15','15'],['GP18','18'],['GP19','19'],['GP20','20'],['GP21','21'],['GP26','26'],['GP27','27'],['GP28','28']]), 'PIN');
    this.appendValueInput('ANGLE')
        .appendField('องศา (0-180)');
    this.appendValueInput('SPEED')
        .appendField('ความเร็ว (1-10)');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip('หมุน Servo ไปยังองศาที่กำหนด พร้อม speed control\n1=ช้าสุด, 10=เร็วสุด');
  }
};

// ── 3. servo_write — หมุนทันที ────────────────────────────
Blockly.Blocks['srv_pico_servo_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo หมุนทันที ขา')
        .appendField(new Blockly.FieldDropdown([['GP0','0'],['GP1','1'],['GP2','2'],['GP3','3'],['GP4','4'],['GP5','5'],['GP6','6'],['GP7','7'],['GP8','8'],['GP9','9'],['GP10','10'],['GP11','11'],['GP12','12'],['GP13','13'],['GP14','14'],['GP15','15'],['GP18','18'],['GP19','19'],['GP20','20'],['GP21','21'],['GP26','26'],['GP27','27'],['GP28','28']]), 'PIN');
    this.appendValueInput('ANGLE')
        .appendField('องศา (0-180)');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip('หมุน Servo ทันทีโดยไม่มี speed control');
  }
};

// ── 4. servo_us — หมุน microseconds ───────────────────────
Blockly.Blocks['srv_pico_servo_us'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo microseconds ขา')
        .appendField(new Blockly.FieldDropdown([['GP0','0'],['GP1','1'],['GP2','2'],['GP3','3'],['GP4','4'],['GP5','5'],['GP6','6'],['GP7','7'],['GP8','8'],['GP9','9'],['GP10','10'],['GP11','11'],['GP12','12'],['GP13','13'],['GP14','14'],['GP15','15'],['GP18','18'],['GP19','19'],['GP20','20'],['GP21','21'],['GP26','26'],['GP27','27'],['GP28','28']]), 'PIN');
    this.appendValueInput('US')
        .appendField('µs (500-2500)');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#92400e');
    this.setTooltip('สั่ง Servo ด้วย pulse width (microseconds)\n500=0°, 1500=90°, 2500=180°');
  }
};

// ── 5. servo_read — อ่านองศา ──────────────────────────────
Blockly.Blocks['srv_pico_servo_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo อ่านองศา ขา')
        .appendField(new Blockly.FieldDropdown([['GP0','0'],['GP1','1'],['GP2','2'],['GP3','3'],['GP4','4'],['GP5','5'],['GP6','6'],['GP7','7'],['GP8','8'],['GP9','9'],['GP10','10'],['GP11','11'],['GP12','12'],['GP13','13'],['GP14','14'],['GP15','15'],['GP18','18'],['GP19','19'],['GP20','20'],['GP21','21'],['GP26','26'],['GP27','27'],['GP28','28']]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#b45309');
    this.setTooltip('อ่านองศาปัจจุบันของ Servo');
  }
};

// ── 6. servo_detach — ปล่อยขา ─────────────────────────────
Blockly.Blocks['srv_pico_servo_detach'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo ปล่อยขา')
        .appendField(new Blockly.FieldDropdown([['GP0','0'],['GP1','1'],['GP2','2'],['GP3','3'],['GP4','4'],['GP5','5'],['GP6','6'],['GP7','7'],['GP8','8'],['GP9','9'],['GP10','10'],['GP11','11'],['GP12','12'],['GP13','13'],['GP14','14'],['GP15','15'],['GP18','18'],['GP19','19'],['GP20','20'],['GP21','21'],['GP26','26'],['GP27','27'],['GP28','28']]), 'PIN');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#78350f');
    this.setTooltip('ปล่อยขา Servo — หยุดส่ง PWM signal');
  }
};

// ── 7. servo_sweep — Sweep อัตโนมัติ ──────────────────────
Blockly.Blocks['srv_pico_servo_sweep'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo Sweep ขา')
        .appendField(new Blockly.FieldDropdown([['GP0','0'],['GP1','1'],['GP2','2'],['GP3','3'],['GP4','4'],['GP5','5'],['GP6','6'],['GP7','7'],['GP8','8'],['GP9','9'],['GP10','10'],['GP11','11'],['GP12','12'],['GP13','13'],['GP14','14'],['GP15','15'],['GP18','18'],['GP19','19'],['GP20','20'],['GP21','21'],['GP26','26'],['GP27','27'],['GP28','28']]), 'PIN');
    this.appendValueInput('SPEED')
        .appendField('ความเร็ว (1-10)');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#92400e');
    this.setTooltip('Sweep อัตโนมัติ 0° → 180° → 0°');
  }
};
