#pragma once
#include <Servo.h>

// ============================================================
//  myservo_pico.h — Servo helper สำหรับ Raspberry Pi Pico RP2040
//  รองรับ 8 servo พร้อมกัน
//  GP pins รองรับ PWM: GP0-GP15, GP18-GP21, GP26-GP28
//  servo(pin, angle, speed) — speed 1=ช้า, 10=เร็ว
// ============================================================

static Servo _servo[8];
static int   _servo_pin[8];
static int   _servo_pos[8];
static bool  _servo_used[8];

static int _servo_idx(int pin) {
  for (int i = 0; i < 8; i++) {
    if (_servo_used[i] && _servo_pin[i] == pin) return i;
  }
  return -1;
}
static int _servo_slot() {
  for (int i = 0; i < 8; i++) {
    if (!_servo_used[i]) return i;
  }
  return -1;
}

void servo_attach(int pin) {
  int idx = _servo_idx(pin);
  if (idx < 0) {
    idx = _servo_slot();
    if (idx < 0) return;
    _servo_used[idx] = true;
    _servo_pin[idx]  = pin;
    _servo_pos[idx]  = 90;
  }
  _servo[idx].attach(pin);
}

void servo_write(int pin, int angle) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  angle = constrain(angle, 0, 180);
  _servo_pos[idx] = angle;
  _servo[idx].write(angle);
}

void servo(int pin, int angle, int speed) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  angle = constrain(angle, 0, 180);
  speed = constrain(speed, 1, 10);
  int del = map(speed, 1, 10, 20, 2);
  int cur = _servo_pos[idx];
  int step = (angle > cur) ? 1 : -1;
  while (cur != angle) {
    cur += step;
    _servo[idx].write(cur);
    delay(del);
  }
  _servo_pos[idx] = angle;
}

void servo_us(int pin, int us) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  us = constrain(us, 500, 2500);
  _servo[idx].writeMicroseconds(us);
}

int servo_read(int pin) {
  int idx = _servo_idx(pin);
  if (idx < 0) return 0;
  return _servo[idx].read();
}

void servo_detach(int pin) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  _servo[idx].detach();
  _servo_used[idx] = false;
}

void servo_sweep(int pin, int speed) {
  servo(pin, 0,   speed);
  servo(pin, 180, speed);
  servo(pin, 0,   speed);
}
