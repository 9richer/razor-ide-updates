#pragma once
#include <Servo.h>

// ============================================================
//  myservo_nano.h — Servo helper สำหรับ Arduino Nano
//  รองรับ 6 servo พร้อมกัน (ขา PWM: D3,D5,D6,D9,D10,D11)
//  servo(pin, angle, speed) — speed 1=ช้า, 10=เร็ว
// ============================================================

static Servo _servo[6];       // servo instances
static int   _servo_pin[6];   // ขาที่ attach ไว้
static int   _servo_pos[6];   // ตำแหน่งปัจจุบัน (องศา)

// แปลง pin → index (0-5)
static int _servo_idx(int pin) {
  const int PINS[6] = {3, 5, 6, 9, 10, 11};
  for (int i = 0; i < 6; i++) if (PINS[i] == pin) return i;
  return -1;
}

// กำหนดขา servo
void servo_attach(int pin) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  _servo_pin[idx] = pin;
  _servo_pos[idx] = 90;
  _servo[idx].attach(pin);
}

// หมุน servo ทันที
void servo_write(int pin, int angle) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  angle = constrain(angle, 0, 180);
  _servo_pos[idx] = angle;
  _servo[idx].write(angle);
}

// servo() — หมุนพร้อม speed control
// speed: 1=ช้ามาก (delay 20ms/องศา), 10=เร็วมาก (delay 2ms/องศา)
void servo(int pin, int angle, int speed) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  angle = constrain(angle, 0, 180);
  speed = constrain(speed, 1, 10);
  int del = map(speed, 1, 10, 20, 2);  // ms ต่อองศา
  int cur = _servo_pos[idx];
  int step = (angle > cur) ? 1 : -1;
  while (cur != angle) {
    cur += step;
    _servo[idx].write(cur);
    delay(del);
  }
  _servo_pos[idx] = angle;
}

// หมุน microseconds
void servo_us(int pin, int us) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  us = constrain(us, 500, 2500);
  _servo[idx].writeMicroseconds(us);
}

// อ่านองศาปัจจุบัน
int servo_read(int pin) {
  int idx = _servo_idx(pin);
  if (idx < 0) return 0;
  return _servo[idx].read();
}

// ปล่อยขา servo
void servo_detach(int pin) {
  int idx = _servo_idx(pin);
  if (idx < 0) return;
  _servo[idx].detach();
}

// Sweep อัตโนมัติ 0→180→0
void servo_sweep(int pin, int speed) {
  servo(pin, 0,   speed);
  servo(pin, 180, speed);
  servo(pin, 0,   speed);
}
