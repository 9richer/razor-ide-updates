// ============================================================
//  Servo blocks — srv_nano
//  ขาที่รองรับ: D3, D5, D6, D9, D10, D11
// ============================================================

// ── 1. servo_attach — กำหนดขา ─────────────────────────────
Blockly.Blocks['srv_nano_servo_attach'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo กำหนดขา')
        .appendField(new Blockly.FieldDropdown([['D3','3'],['D5','5'],['D6','6'],['D9','9'],['D10','10'],['D11','11']]), 'PIN');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip('กำหนดขา PWM สำหรับ Servo motor');
  }
};

// ── 2. servo() — หมุนพร้อม speed ──────────────────────────
Blockly.Blocks['srv_nano_servo'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo ขา')
        .appendField(new Blockly.FieldDropdown([['D3','3'],['D5','5'],['D6','6'],['D9','9'],['D10','10'],['D11','11']]), 'PIN');
    this.appendValueInput('ANGLE')
        .appendField('องศา (0-180)');
    this.appendValueInput('SPEED')
        .appendField('ความเร็ว (1-10)');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip('หมุน Servo ไปยังองศาที่กำหนด พร้อม speed control\n1=ช้าสุด, 10=เร็วสุด');
  }
};

// ── 3. servo_write — หมุนทันที ────────────────────────────
Blockly.Blocks['srv_nano_servo_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo หมุนทันที ขา')
        .appendField(new Blockly.FieldDropdown([['D3','3'],['D5','5'],['D6','6'],['D9','9'],['D10','10'],['D11','11']]), 'PIN');
    this.appendValueInput('ANGLE')
        .appendField('องศา (0-180)');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip('หมุน Servo ทันทีโดยไม่มี speed control');
  }
};

// ── 4. servo_us — หมุน microseconds ───────────────────────
Blockly.Blocks['srv_nano_servo_us'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo microseconds ขา')
        .appendField(new Blockly.FieldDropdown([['D3','3'],['D5','5'],['D6','6'],['D9','9'],['D10','10'],['D11','11']]), 'PIN');
    this.appendValueInput('US')
        .appendField('µs (500-2500)');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#92400e');
    this.setTooltip('สั่ง Servo ด้วย pulse width (microseconds)\n500=0°, 1500=90°, 2500=180°');
  }
};

// ── 5. servo_read — อ่านองศา ──────────────────────────────
Blockly.Blocks['srv_nano_servo_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo อ่านองศา ขา')
        .appendField(new Blockly.FieldDropdown([['D3','3'],['D5','5'],['D6','6'],['D9','9'],['D10','10'],['D11','11']]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#b45309');
    this.setTooltip('อ่านองศาปัจจุบันของ Servo');
  }
};

// ── 6. servo_detach — ปล่อยขา ─────────────────────────────
Blockly.Blocks['srv_nano_servo_detach'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo ปล่อยขา')
        .appendField(new Blockly.FieldDropdown([['D3','3'],['D5','5'],['D6','6'],['D9','9'],['D10','10'],['D11','11']]), 'PIN');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#78350f');
    this.setTooltip('ปล่อยขา Servo — หยุดส่ง PWM signal');
  }
};

// ── 7. servo_sweep — Sweep อัตโนมัติ ──────────────────────
Blockly.Blocks['srv_nano_servo_sweep'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo Sweep ขา')
        .appendField(new Blockly.FieldDropdown([['D3','3'],['D5','5'],['D6','6'],['D9','9'],['D10','10'],['D11','11']]), 'PIN');
    this.appendValueInput('SPEED')
        .appendField('ความเร็ว (1-10)');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#92400e');
    this.setTooltip('Sweep อัตโนมัติ 0° → 180° → 0°');
  }
};
