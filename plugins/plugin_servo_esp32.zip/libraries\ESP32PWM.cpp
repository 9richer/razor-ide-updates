/*
 * ESP32PWM.cpp - Updated for ESP32 Arduino core 3.x compatibility
 */

#include <ESP32PWM.h>
#include "esp32-hal-ledc.h"

// ── ESP32 core version compatibility ──────────────────────────────────────
// core 2.x: ledcSetup(chan,freq,res) + ledcAttachPin(pin,chan) + ledcDetachPin(pin)
// core 3.x: ledcAttach(pin,freq,res) + ledcDetach(pin)  (API ใหม่ รวมกัน)
#ifndef ESP_ARDUINO_VERSION_VAL
  #define ESP_ARDUINO_VERSION_VAL(a,b,c) (((a)<<16)|((b)<<8)|(c))
#endif
#ifndef ESP_ARDUINO_VERSION
  #define ESP_ARDUINO_VERSION ESP_ARDUINO_VERSION_VAL(2,0,0)
#endif

#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3,0,0)
  // core 3.x
  static inline double _compat_ledcSetup(uint8_t chan, double freq, uint8_t bits) {
    return freq; // จัดการใน attachPin แทน
  }
  static inline void _compat_ledcAttachPin(uint8_t pin, uint8_t chan, double freq, uint8_t bits) {
    ledcAttach(pin, (uint32_t)freq, bits);
  }
  static inline void _compat_ledcDetachPin(uint8_t pin) {
    ledcDetach(pin);
  }
#else
  // core 2.x
  static inline double _compat_ledcSetup(uint8_t chan, double freq, uint8_t bits) {
    return ledcSetup(chan, freq, bits);
  }
  static inline void _compat_ledcAttachPin(uint8_t pin, uint8_t chan, double freq, uint8_t bits) {
    ledcAttachPin(pin, chan);
  }
  static inline void _compat_ledcDetachPin(uint8_t pin) {
    ledcDetachPin(pin);
  }
#endif
// ──────────────────────────────────────────────────────────────────────────

int ESP32PWM::PWMCount = -1;
ESP32PWM * ESP32PWM::ChannelUsed[NUM_PWM];
long ESP32PWM::timerFreqSet[4] = { -1, -1, -1, -1 };
int ESP32PWM::timerCount[4] = { 0, 0, 0, 0 };

ESP32PWM::ESP32PWM() {
	resolutionBits = 8;
	pwmChannel = -1;
	pin = -1;
	myFreq = -1;
	if (PWMCount == -1) {
		for (int i = 0; i < NUM_PWM; i++)
			ChannelUsed[i] = NULL;
		PWMCount = PWM_BASE_INDEX;
	}
}

ESP32PWM::~ESP32PWM() {
	if (attached()) {
		_compat_ledcDetachPin(pin);
	}
	deallocate();
}

double ESP32PWM::_ledcSetupTimerFreq(uint8_t chan, double freq, uint8_t bit_num) {
	return _compat_ledcSetup(chan, freq, bit_num);
}

int ESP32PWM::timerAndIndexToChannel(int timerNum, int index) {
	int localIndex = 0;
	for (int j = 0; j < NUM_PWM; j++) {
		if (((j / 2) % 4) == timerNum) {
			if (localIndex == index) return j;
			localIndex++;
		}
	}
	return -1;
}

int ESP32PWM::allocatenext(double freq) {
	long freqlocal = (long) freq;
	if (pwmChannel < 0) {
		for (int i = 0; i < 4; i++) {
			bool freqAllocated = ((timerFreqSet[i] == freqlocal) || (timerFreqSet[i] == -1));
			if (freqAllocated && timerCount[i] < 4) {
				if (timerFreqSet[i] == -1) timerFreqSet[i] = freqlocal;
				timerNum = i;
				for (int index = 0; index < 4; ++index) {
					int myTimerNumber = timerAndIndexToChannel(timerNum, index);
					if ((myTimerNumber >= 0) && (!ChannelUsed[myTimerNumber])) {
						pwmChannel = myTimerNumber;
						ChannelUsed[pwmChannel] = this;
						timerCount[timerNum]++;
						PWMCount++;
						myFreq = freq;
						return pwmChannel;
					}
				}
			}
		}
	} else {
		return pwmChannel;
	}
	while (1);
}

void ESP32PWM::deallocate() {
	if (pwmChannel < 0) return;
	timerCount[getTimer()]--;
	if (timerCount[getTimer()] == 0) timerFreqSet[getTimer()] = -1;
	timerNum = -1;
	attachedState = false;
	ChannelUsed[pwmChannel] = NULL;
	pwmChannel = -1;
	PWMCount--;
}

int ESP32PWM::getChannel() {
	return pwmChannel;
}

double ESP32PWM::setup(double freq, uint8_t resolution_bits) {
	checkFrequencyForSideEffects(freq);
	resolutionBits = resolution_bits;
	if (attached()) {
		_compat_ledcDetachPin(pin);
		double val = _compat_ledcSetup(getChannel(), freq, resolution_bits);
		attachPin(pin);
		return val;
	}
	return _compat_ledcSetup(getChannel(), freq, resolution_bits);
}

float ESP32PWM::getDutyScaled() {
	return mapf((float) myDuty, 0, (float)((1 << resolutionBits) - 1), 0.0, 1.0);
}

void ESP32PWM::writeScaled(float duty) {
	write(mapf(duty, 0.0, 1.0, 0, (float)((1 << resolutionBits) - 1)));
}

void ESP32PWM::write(uint32_t duty) {
	myDuty = duty;
	ledcWrite(getChannel(), duty);
}

void ESP32PWM::adjustFrequencyLocal(double freq, float dutyScaled) {
	timerFreqSet[getTimer()] = (long) freq;
	myFreq = freq;
	if (attached()) {
		_compat_ledcDetachPin(pin);
		_ledcSetupTimerFreq(getChannel(), freq, resolutionBits);
		writeScaled(dutyScaled);
		_compat_ledcAttachPin(pin, getChannel(), freq, resolutionBits);
	} else {
		_ledcSetupTimerFreq(getChannel(), freq, resolutionBits);
		writeScaled(dutyScaled);
	}
}

void ESP32PWM::adjustFrequency(double freq, float dutyScaled) {
	if (dutyScaled < 0) dutyScaled = getDutyScaled();
	writeScaled(dutyScaled);
	for (int i = 0; i < timerCount[getTimer()]; i++) {
		int pwm = timerAndIndexToChannel(getTimer(), i);
		if (ChannelUsed[pwm] != NULL && ChannelUsed[pwm]->myFreq != freq)
			ChannelUsed[pwm]->adjustFrequencyLocal(freq, ChannelUsed[pwm]->getDutyScaled());
	}
}

double ESP32PWM::writeTone(double freq) {
	for (int i = 0; i < timerCount[getTimer()]; i++) {
		int pwm = timerAndIndexToChannel(getTimer(), i);
		if (ChannelUsed[pwm] != NULL) {
			if (ChannelUsed[pwm]->myFreq != freq)
				ChannelUsed[pwm]->adjustFrequencyLocal(freq, ChannelUsed[pwm]->getDutyScaled());
			write(1 << (resolutionBits - 1));
		}
	}
	return 0;
}

double ESP32PWM::writeNote(note_t note, uint8_t octave) {
	const uint16_t noteFrequencyBase[12] = { 4186,4435,4699,4978,5274,5588,5920,6272,6645,7040,7459,7902 };
	if (octave > 8 || note >= NOTE_MAX) return 0;
	double noteFreq = (double)noteFrequencyBase[note] / (double)(1 << (8 - octave));
	return writeTone(noteFreq);
}

uint32_t ESP32PWM::read() {
	return ledcRead(getChannel());
}

double ESP32PWM::readFreq() { return myFreq; }

void ESP32PWM::attach(int p) {
	pin = p;
	attachedState = true;
}

void ESP32PWM::attachPin(uint8_t pin) {
	if (hasPwm(pin)) {
		attach(pin);
		_compat_ledcAttachPin(pin, getChannel(), myFreq, resolutionBits);
	}
}

void ESP32PWM::attachPin(uint8_t pin, double freq, uint8_t resolution_bits) {
	if (hasPwm(pin)) setup(freq, resolution_bits);
	attachPin(pin);
}

void ESP32PWM::detachPin(int pin) {
	_compat_ledcDetachPin(pin);
	deallocate();
}

bool ESP32PWM::checkFrequencyForSideEffects(double freq) {
	allocatenext(freq);
	for (int i = 0; i < timerCount[getTimer()]; i++) {
		int pwm = timerAndIndexToChannel(getTimer(), i);
		if (pwm == pwmChannel) continue;
		if (ChannelUsed[pwm] != NULL && ChannelUsed[pwm]->getTimer() == getTimer()) {
			double diff = abs(ChannelUsed[pwm]->myFreq - freq);
			if (abs(diff) > 0.1) ChannelUsed[pwm]->myFreq = freq;
		}
	}
	return true;
}

ESP32PWM* pwmFactory(int pin) {
	for (int i = 0; i < NUM_PWM; i++)
		if (ESP32PWM::ChannelUsed[i] != NULL && ESP32PWM::ChannelUsed[i]->getPin() == pin)
			return ESP32PWM::ChannelUsed[i];
	return NULL;
}
