// ============================================================
//  huskylens_razor — generator.js  (Blockly.Arduino)
//  map บล็อก → ฟังก์ชันใน huskylens_razor.h
// ============================================================

// helper: valueToCode + fallback (ตั้งชื่อเฉพาะ กันชนกับ board)
function _hkv(block, name, def) {
  return Blockly.Arduino.valueToCode(block, name, Blockly.Arduino.ORDER_ATOMIC) || def;
}

Blockly.Arduino.forBlock['husky_begin'] = function(block) {
  return 'husky_begin();\n';
};

Blockly.Arduino.forBlock['husky_set_mode'] = function(block) {
  var algo = block.getFieldValue('ALGO');   // '0'..'6'
  return 'husky_setMode(' + algo + ');\n';
};

Blockly.Arduino.forBlock['husky_request'] = function(block) {
  return 'husky_request();\n';
};

Blockly.Arduino.forBlock['husky_request_id'] = function(block) {
  var id = _hkv(block, 'ID', '1');
  return 'husky_requestID(' + id + ');\n';
};

Blockly.Arduino.forBlock['husky_available'] = function(block) {
  return ['husky_available()', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['husky_count'] = function(block) {
  return ['husky_count()', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['husky_id_available'] = function(block) {
  var id = _hkv(block, 'ID', '1');
  return ['husky_idAvailable(' + id + ')', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['husky_block'] = function(block) {
  var i     = _hkv(block, 'I', '1');
  var field = block.getFieldValue('FIELD');   // x|y|w|h|id
  return ['husky_' + field + '(' + i + ')', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['husky_arrow'] = function(block) {
  var i     = _hkv(block, 'I', '1');
  var field = block.getFieldValue('FIELD');   // arrow_xo|arrow_yo|arrow_xt|arrow_yt|arrow_id
  return ['husky_' + field + '(' + i + ')', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['husky_learned_count'] = function(block) {
  return ['husky_learnedCount()', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['husky_learn'] = function(block) {
  var id = _hkv(block, 'ID', '1');
  return 'husky_learn(' + id + ');\n';
};

Blockly.Arduino.forBlock['husky_forget'] = function(block) {
  return 'husky_forget();\n';
};
