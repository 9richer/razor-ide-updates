#pragma once
#include <Arduino.h>
#include <Wire.h>

// ══════════════════════════════════════════════════════════════
//  HuskyLens — I2C driver (single-header, เขียนเอง)
//  สำหรับ RAZOR-S3 (RP2040)  —  ใช้บัส I2C ร่วมกับ OLED (address ต่างกัน)
//
//  HuskyLens I2C address = 0x32   (OLED = 0x3C → ไม่ชนกัน)
//  Protocol เฟรม:  0x55 0xAA 0x11 [len] [cmd] [content...] [checksum]
//                  checksum = ผลรวมไบต์ทั้งหมดก่อน checksum & 0xFF
//
//  ⚠ ต้องเรียก razors4() (board init → Wire.begin) ก่อนใช้กล้องเสมอ
//  ⚠ driver นี้ทดสอบกับกล้องจริงแล้วค่อยปรับจูน timeout ได้
// ══════════════════════════════════════════════════════════════

#define HUSKY_ADDR  0x32
#define HUSKY_MAX   8       // เก็บผลได้สูงสุด 8 อันต่อเฟรม

// ── อัลกอริทึม (ค่า content ของคำสั่งเปลี่ยนโหมด 0x2D) ──────────
#define HUSKY_FACE_RECOGNITION     0
#define HUSKY_OBJECT_TRACKING      1
#define HUSKY_OBJECT_RECOGNITION   2
#define HUSKY_LINE_TRACKING        3
#define HUSKY_COLOR_RECOGNITION    4
#define HUSKY_TAG_RECOGNITION      5
#define HUSKY_OBJECT_CLASSIFY      6

// ── ผลลัพธ์ 1 อัน — block: x1,y1=ศูนย์กลาง x2,y2=กว้าง,สูง
//                    arrow: x1,y1=จุดเริ่ม  x2,y2=จุดปลาย ──────
struct HuskyResult {
  int16_t x1, y1, x2, y2, id;
  bool    isBlock;   // true=block(วัตถุ)  false=arrow(เส้น)
};

static HuskyResult _huskyResults[HUSKY_MAX];
static int _huskyCount        = 0;   // จำนวนที่เก็บได้รอบล่าสุด
static int _huskyLearnedCount = 0;   // จำนวน ID ที่กล้องเรียนรู้แล้ว
static int _huskyFrameTotal   = 0;   // จำนวนทั้งหมดบนจอ (อาจ > HUSKY_MAX)

// ══════════════════════════════════════════════════════════════
//  I/O ระดับล่าง
// ══════════════════════════════════════════════════════════════

// ส่งคำสั่ง 1 เฟรมไปกล้อง
inline void husky_writeCmd(uint8_t cmd, const uint8_t* content, uint8_t len) {
  uint8_t buf[16];
  buf[0] = 0x55; buf[1] = 0xAA; buf[2] = 0x11; buf[3] = len; buf[4] = cmd;
  for (uint8_t i = 0; i < len; i++) buf[5 + i] = content[i];
  uint16_t sum = 0;
  for (uint8_t i = 0; i < (uint8_t)(5 + len); i++) sum += buf[i];
  buf[5 + len] = (uint8_t)(sum & 0xFF);
  Wire.beginTransmission(HUSKY_ADDR);
  Wire.write(buf, (size_t)(6 + len));
  Wire.endTransmission();
}

// อ่าน 1 ไบต์จากกล้อง (requestFrom ทีละไบต์ — เชื่อถือได้กับ HuskyLens)
inline int husky_readByte() {
  if (Wire.requestFrom((uint8_t)HUSKY_ADDR, (uint8_t)1) != 1) return -1;
  return Wire.read();
}

// อ่าน 1 เฟรมตอบกลับ → คืน cmd + แปลง content เป็น int16 ได้สูงสุด 5 ตัว
inline bool husky_readFrame(uint8_t &cmd, int16_t out[5]) {
  // ── sync หา header 0x55 0xAA 0x11 (ข้ามไบต์ขยะ) ──
  int tries = 0;
  bool synced = false;
  while (tries < 60) {
    int b = husky_readByte(); tries++;
    if (b < 0) return false;
    if (b == 0x55) {
      if (husky_readByte() != 0xAA) continue;
      if (husky_readByte() != 0x11) continue;
      synced = true; break;
    }
  }
  if (!synced) return false;

  int len = husky_readByte(); if (len < 0 || len > 16) return false;
  int c   = husky_readByte(); if (c < 0) return false;
  cmd = (uint8_t)c;

  uint8_t content[16];
  for (int i = 0; i < len; i++) {
    int d = husky_readByte(); if (d < 0) return false;
    content[i] = (uint8_t)d;
  }
  (void)husky_readByte();   // checksum — อ่านทิ้ง (ไม่ตรวจ)

  for (int i = 0; i < 5; i++) {
    if (2 * i + 1 < len)
      out[i] = (int16_t)((uint16_t)content[2*i] | ((uint16_t)content[2*i+1] << 8));
    else
      out[i] = 0;
  }
  return true;
}

// เก็บผลลัพธ์หลังส่งคำสั่ง request (อ่าน INFO ก่อน แล้วตามด้วย block/arrow)
inline bool _husky_collect() {
  uint8_t cmd; int16_t v[5];
  if (!husky_readFrame(cmd, v)) return false;
  if (cmd != 0x29) return false;          // 0x29 = RETURN_INFO
  _huskyFrameTotal   = v[0];
  _huskyLearnedCount = v[1];
  _huskyCount = 0;
  for (int i = 0; i < v[0]; i++) {
    uint8_t c2; int16_t r[5];
    if (!husky_readFrame(c2, r)) break;
    if ((c2 == 0x2A || c2 == 0x2B) && _huskyCount < HUSKY_MAX) {   // 0x2A=BLOCK 0x2B=ARROW
      _huskyResults[_huskyCount].x1      = r[0];
      _huskyResults[_huskyCount].y1      = r[1];
      _huskyResults[_huskyCount].x2      = r[2];
      _huskyResults[_huskyCount].y2      = r[3];
      _huskyResults[_huskyCount].id      = r[4];
      _huskyResults[_huskyCount].isBlock = (c2 == 0x2A);
      _huskyCount++;
    }
  }
  return true;
}

// ══════════════════════════════════════════════════════════════
//  API ใช้งาน (บล็อกเรียกฟังก์ชันเหล่านี้)
// ══════════════════════════════════════════════════════════════

// เริ่มต้น/handshake (knock 0x2C → รอ RETURN_OK 0x2E) — คืน true ถ้าเจอกล้อง
inline bool husky_begin() {
  for (int k = 0; k < 5; k++) {
    husky_writeCmd(0x2C, nullptr, 0);
    uint8_t cmd; int16_t v[5];
    if (husky_readFrame(cmd, v) && cmd == 0x2E) return true;
    delay(100);
  }
  return false;
}

// เปลี่ยนโหมด/อัลกอริทึม (0x2D) — algo = 0..6
inline void husky_setMode(int algo) {
  uint8_t c[2] = { (uint8_t)(algo & 0xFF), (uint8_t)((algo >> 8) & 0xFF) };
  husky_writeCmd(0x2D, c, 2);
  uint8_t cmd; int16_t v[5];
  husky_readFrame(cmd, v);   // RETURN_OK
  delay(50);
}

// อ่านข้อมูลทุกอย่างบนจอ (0x20)
inline bool husky_request() {
  husky_writeCmd(0x20, nullptr, 0);
  return _husky_collect();
}

// อ่านเฉพาะ ID ที่ต้องการ (0x26)
inline bool husky_requestID(int id) {
  uint8_t c[2] = { (uint8_t)(id & 0xFF), (uint8_t)((id >> 8) & 0xFF) };
  husky_writeCmd(0x26, c, 2);
  return _husky_collect();
}

// ── ตัวอ่านผลลัพธ์ (index เริ่มที่ 1 = ตัวแรก/เด่นสุด) ──────────
inline int  husky_count()        { return _huskyCount; }
inline bool husky_available()    { return _huskyCount > 0; }
inline int  husky_learnedCount() { return _huskyLearnedCount; }

inline bool husky_idAvailable(int id) {
  for (int i = 0; i < _huskyCount; i++)
    if (_huskyResults[i].id == id) return true;
  return false;
}

// block (วัตถุ): X,Y=ศูนย์กลาง  W,H=กว้าง,สูง  — คืน -1 ถ้าไม่มี
inline int husky_x (int i) { i--; return (i >= 0 && i < _huskyCount) ? _huskyResults[i].x1 : -1; }
inline int husky_y (int i) { i--; return (i >= 0 && i < _huskyCount) ? _huskyResults[i].y1 : -1; }
inline int husky_w (int i) { i--; return (i >= 0 && i < _huskyCount) ? _huskyResults[i].x2 : -1; }
inline int husky_h (int i) { i--; return (i >= 0 && i < _huskyCount) ? _huskyResults[i].y2 : -1; }
inline int husky_id(int i) { i--; return (i >= 0 && i < _huskyCount) ? _huskyResults[i].id : -1; }

// arrow (ตามเส้น): เริ่ม(xo,yo) ปลาย(xt,yt) — ใช้ที่เก็บเดียวกับ block
inline int husky_arrow_xo(int i) { return husky_x(i); }
inline int husky_arrow_yo(int i) { return husky_y(i); }
inline int husky_arrow_xt(int i) { return husky_w(i); }
inline int husky_arrow_yt(int i) { return husky_h(i); }
inline int husky_arrow_id(int i) { return husky_id(i); }

// ── เรียนรู้/ลบ (โหมดที่รองรับ learn เช่น face/object/color/tag) ──
inline void husky_learn(int id) {
  uint8_t c[2] = { (uint8_t)(id & 0xFF), (uint8_t)((id >> 8) & 0xFF) };
  husky_writeCmd(0x36, c, 2);
  uint8_t cmd; int16_t v[5];
  husky_readFrame(cmd, v);   // RETURN_OK
}

inline void husky_forget() {
  husky_writeCmd(0x37, nullptr, 0);
  uint8_t cmd; int16_t v[5];
  husky_readFrame(cmd, v);   // RETURN_OK
}
