// ============================================================
//  huskylens_razor — blocks.js
//  กล้อง AI HuskyLens (I2C) สำหรับ RAZOR-S3
//  ครอบคลุม 7 โหมด + อ่านผล + learn/forget
//  หมายเหตุ: block label ใช้ข้อความล้วน ไม่ใส่ emoji
// ============================================================

var _HUSKY_COL = '#0d9488';

// ── เริ่มต้นกล้อง (ใส่ใน Setup) ───────────────────────────────
Blockly.Blocks['husky_begin'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง HuskyLens เริ่มต้น (I2C)');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(_HUSKY_COL);
    this.setTooltip(
      'จับมือกับกล้องผ่าน I2C (address 0x32) — ใส่ใน Setup\n' +
      'ต้องอยู่หลัง board init (Wire พร้อมแล้ว)\n' +
      'Generate: husky_begin();'
    );
  }
};

// ── เลือกโหมด/อัลกอริทึม ──────────────────────────────────────
Blockly.Blocks['husky_set_mode'] = {
  init: function() {
    var _MODE = [
      ['จดจำใบหน้า', '0'],
      ['ติดตามวัตถุ', '1'],
      ['จดจำวัตถุ',  '2'],
      ['ตามเส้น',    '3'],
      ['จดจำสี',     '4'],
      ['จดจำแท็ก',   '5'],
      ['จำแนกวัตถุ', '6']
    ];
    this.appendDummyInput()
        .appendField('กล้อง เลือกโหมด')
        .appendField(new Blockly.FieldDropdown(_MODE), 'ALGO');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(_HUSKY_COL);
    this.setTooltip(
      'เปลี่ยนอัลกอริทึมของกล้อง (ครบ 7 โหมด)\n' +
      'ใส่ใน Setup หรือก่อนเริ่มใช้แต่ละโหมด\n' +
      'Generate: husky_setMode(0..6);'
    );
  }
};

// ── อ่านข้อมูลทั้งหมดบนจอ ─────────────────────────────────────
Blockly.Blocks['husky_request'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง อ่านข้อมูล');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(_HUSKY_COL);
    this.setTooltip(
      'ดึงข้อมูลเฟรมล่าสุดจากกล้อง — เรียกก่อนอ่านค่าทุกครั้ง\n' +
      'Generate: husky_request();'
    );
  }
};

// ── อ่านข้อมูลเฉพาะ ID ────────────────────────────────────────
Blockly.Blocks['husky_request_id'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง อ่านข้อมูล เฉพาะ ID');
    this.appendValueInput('ID').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(_HUSKY_COL);
    this.setTooltip(
      'ดึงเฉพาะวัตถุ/เส้นที่มี ID ตามที่ระบุ\n' +
      'Generate: husky_requestID(id);'
    );
  }
};

// ── เจอวัตถุไหม (boolean) ─────────────────────────────────────
Blockly.Blocks['husky_available'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง เจอวัตถุ?');
    this.setOutput(true, 'Boolean');
    this.setColour(_HUSKY_COL);
    this.setTooltip('คืน true ถ้ารอบล่าสุดเจอวัตถุ/เส้นอย่างน้อย 1 อัน\nGenerate: husky_available()');
  }
};

// ── จำนวนที่เจอ (number) ──────────────────────────────────────
Blockly.Blocks['husky_count'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง จำนวนที่เจอ');
    this.setOutput(true, 'Number');
    this.setColour(_HUSKY_COL);
    this.setTooltip('จำนวนวัตถุ/เส้นที่เก็บได้รอบล่าสุด (0-8)\nGenerate: husky_count()');
  }
};

// ── เจอ ID นี้ไหม (boolean) ───────────────────────────────────
Blockly.Blocks['husky_id_available'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง เจอ ID');
    this.appendValueInput('ID').setCheck('Number');
    this.setInputsInline(true);
    this.setOutput(true, 'Boolean');
    this.setColour(_HUSKY_COL);
    this.setTooltip('คืน true ถ้ารอบล่าสุดเจอวัตถุที่มี ID นี้\nGenerate: husky_idAvailable(id)');
  }
};

// ── อ่านค่าวัตถุ (block) ตัวที่ i ────────────────────────────
Blockly.Blocks['husky_block'] = {
  init: function() {
    var _F = [['X','x'],['Y','y'],['กว้าง','w'],['สูง','h'],['ID','id']];
    this.appendDummyInput().appendField('กล้อง วัตถุตัวที่');
    this.appendValueInput('I').setCheck('Number');
    this.appendDummyInput()
        .appendField('ค่า')
        .appendField(new Blockly.FieldDropdown(_F), 'FIELD');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour(_HUSKY_COL);
    this.setTooltip(
      'อ่านค่ากล่องวัตถุ (โหมดใบหน้า/วัตถุ/สี/แท็ก/จำแนก)\n' +
      'X,Y = จุดศูนย์กลาง (จอ 320x240)  กว้าง,สูง = ขนาด  ID = หมายเลข\n' +
      'ตัวที่ 1 = เด่นสุด  คืน -1 ถ้าไม่มี\n' +
      'Generate: husky_x/y/w/h/id(i)'
    );
  }
};

// ── อ่านค่าเส้น (arrow) ตัวที่ i — โหมดตามเส้น ────────────────
Blockly.Blocks['husky_arrow'] = {
  init: function() {
    var _F = [['เริ่ม X','arrow_xo'],['เริ่ม Y','arrow_yo'],
              ['ปลาย X','arrow_xt'],['ปลาย Y','arrow_yt'],['ID','arrow_id']];
    this.appendDummyInput().appendField('กล้อง เส้นตัวที่');
    this.appendValueInput('I').setCheck('Number');
    this.appendDummyInput()
        .appendField('ค่า')
        .appendField(new Blockly.FieldDropdown(_F), 'FIELD');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour(_HUSKY_COL);
    this.setTooltip(
      'อ่านลูกศรเส้น (เฉพาะโหมด "ตามเส้น")\n' +
      'เริ่ม = จุดล่าง(ใกล้หุ่น)  ปลาย = จุดบน(ทิศเส้น)  จอ 320x240\n' +
      'ตัวที่ 1 = เด่นสุด  คืน -1 ถ้าไม่มี\n' +
      'Generate: husky_arrow_xo/yo/xt/yt/id(i)'
    );
  }
};

// ── จำนวนที่เรียนรู้แล้ว (number) ─────────────────────────────
Blockly.Blocks['husky_learned_count'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง จำนวนที่เรียนแล้ว');
    this.setOutput(true, 'Number');
    this.setColour(_HUSKY_COL);
    this.setTooltip('จำนวน ID ที่กล้องเรียนรู้ไว้\nGenerate: husky_learnedCount()');
  }
};

// ── สอนวัตถุ (learn) ──────────────────────────────────────────
Blockly.Blocks['husky_learn'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง สอนวัตถุ ID');
    this.appendValueInput('ID').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(_HUSKY_COL);
    this.setTooltip(
      'สั่งกล้องเรียนรู้วัตถุที่อยู่กลางจอ ให้เป็น ID นี้\n' +
      '(โหมดที่รองรับ: ใบหน้า/วัตถุ/สี/แท็ก)\n' +
      'Generate: husky_learn(id);'
    );
  }
};

// ── ลบที่เรียนทั้งหมด (forget) ────────────────────────────────
Blockly.Blocks['husky_forget'] = {
  init: function() {
    this.appendDummyInput().appendField('กล้อง ลบที่เรียนทั้งหมด');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(_HUSKY_COL);
    this.setTooltip('ลืมทุก ID ที่เรียนไว้ในโหมดปัจจุบัน\nGenerate: husky_forget();');
  }
};
