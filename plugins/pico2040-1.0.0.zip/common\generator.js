// ============================================================
//  Raspberry Pi Pico (RP2040) Generators
// ============================================================

// ══ I/O ══════════════════════════════════════════════════════

Blockly.Arduino.forBlock['pico_pin_mode'] = function(block) {
  var pin  = block.getFieldValue('PIN');
  var mode = block.getFieldValue('MODE');
  return 'pinMode(' + pin + ', ' + mode + ');\n';
};

Blockly.Arduino.forBlock['pico_digital_write'] = function(block) {
  var pin = block.getFieldValue('PIN');
  var val = block.getFieldValue('VAL');
  return 'digitalWrite(' + pin + ', ' + val + ');\n';
};

Blockly.Arduino.forBlock['pico_digital_read'] = function(block) {
  var pin = block.getFieldValue('PIN');
  return ['digitalRead(' + pin + ')', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['pico_analog_read'] = function(block) {
  var pin = block.getFieldValue('PIN');
  return ['analogRead(' + pin + ')', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['pico_pwm_write'] = function(block) {
  var pin = block.getFieldValue('PIN');
  var val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return 'analogWrite(' + pin + ', ' + val + ');\n';
};

// ══ LED ══════════════════════════════════════════════════════

Blockly.Arduino.forBlock['pico_led_on'] = function() {
  return 'digitalWrite(LED_BUILTIN, HIGH);\n';
};

Blockly.Arduino.forBlock['pico_led_off'] = function() {
  return 'digitalWrite(LED_BUILTIN, LOW);\n';
};

Blockly.Arduino.forBlock['pico_led_toggle'] = function() {
  return 'digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));\n';
};

// ══ Serial ═══════════════════════════════════════════════════

Blockly.Arduino.forBlock['pico_serial_begin'] = function(block) {
  var baud = block.getFieldValue('BAUD');
  return 'Serial.begin(' + baud + ');\n';
};

Blockly.Arduino.forBlock['pico_serial_print'] = function(block) {
  var val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  var nl  = block.getFieldValue('NL') === 'TRUE';
  return 'Serial.' + (nl ? 'println' : 'print') + '(' + val + ');\n';
};

Blockly.Arduino.forBlock['pico_serial_available'] = function() {
  return ['Serial.available()', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['pico_serial_read'] = function() {
  return ['Serial.read()', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['pico_serial_readstring'] = function() {
  return ['Serial.readString()', Blockly.Arduino.ORDER_ATOMIC];
};

// ══ Timer ════════════════════════════════════════════════════

Blockly.Arduino.forBlock['pico_delay_ms'] = function(block) {
  var t = Blockly.Arduino.valueToCode(block, 'TIME', Blockly.Arduino.ORDER_ATOMIC) || '1000';
  return 'delay(' + t + ');\n';
};

Blockly.Arduino.forBlock['pico_delay_us'] = function(block) {
  var t = Blockly.Arduino.valueToCode(block, 'TIME', Blockly.Arduino.ORDER_ATOMIC) || '100';
  return 'delayMicroseconds(' + t + ');\n';
};

Blockly.Arduino.forBlock['pico_millis'] = function() {
  return ['millis()', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['pico_micros'] = function() {
  return ['micros()', Blockly.Arduino.ORDER_ATOMIC];
};

// ══ Sound ════════════════════════════════════════════════════

Blockly.Arduino.forBlock['pico_tone'] = function(block) {
  var pin  = block.getFieldValue('PIN');
  var freq = Blockly.Arduino.valueToCode(block, 'FREQ', Blockly.Arduino.ORDER_ATOMIC) || '1000';
  var dur  = Blockly.Arduino.valueToCode(block, 'DUR',  Blockly.Arduino.ORDER_ATOMIC) || '200';
  return 'tone(' + pin + ', ' + freq + ', ' + dur + ');\n';
};

Blockly.Arduino.forBlock['pico_no_tone'] = function(block) {
  var pin = block.getFieldValue('PIN');
  return 'noTone(' + pin + ');\n';
};

// ══ Math ═════════════════════════════════════════════════════

Blockly.Arduino.forBlock['pico_map'] = function(block) {
  var val    = Blockly.Arduino.valueToCode(block, 'VAL',     Blockly.Arduino.ORDER_ATOMIC) || '0';
  var inMin  = Blockly.Arduino.valueToCode(block, 'IN_MIN',  Blockly.Arduino.ORDER_ATOMIC) || '0';
  var inMax  = Blockly.Arduino.valueToCode(block, 'IN_MAX',  Blockly.Arduino.ORDER_ATOMIC) || '1023';
  var outMin = Blockly.Arduino.valueToCode(block, 'OUT_MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  var outMax = Blockly.Arduino.valueToCode(block, 'OUT_MAX', Blockly.Arduino.ORDER_ATOMIC) || '255';
  return ['map(' + val + ', ' + inMin + ', ' + inMax + ', ' + outMin + ', ' + outMax + ')', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['pico_constrain'] = function(block) {
  var val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  var min = Blockly.Arduino.valueToCode(block, 'MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  var max = Blockly.Arduino.valueToCode(block, 'MAX', Blockly.Arduino.ORDER_ATOMIC) || '255';
  return ['constrain(' + val + ', ' + min + ', ' + max + ')', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['pico_random'] = function(block) {
  var min = Blockly.Arduino.valueToCode(block, 'MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  var max = Blockly.Arduino.valueToCode(block, 'MAX', Blockly.Arduino.ORDER_ATOMIC) || '100';
  return ['random(' + min + ', ' + max + ')', Blockly.Arduino.ORDER_ATOMIC];
};

// ══ I2C ══════════════════════════════════════════════════════

Blockly.Arduino.forBlock['pico_i2c_begin'] = function(block) {
  var sda = block.getFieldValue('SDA');
  var scl = block.getFieldValue('SCL');
  return 'Wire.setSDA(' + sda + ');\nWire.setSCL(' + scl + ');\nWire.begin();\n';
};

Blockly.Arduino.forBlock['pico_i2c_write'] = function(block) {
  var addr = block.getFieldValue('ADDR');
  var data = Blockly.Arduino.valueToCode(block, 'DATA', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return 'Wire.beginTransmission(' + addr + ');\nWire.write(' + data + ');\nWire.endTransmission();\n';
};

Blockly.Arduino.forBlock['pico_i2c_read'] = function() {
  return ['Wire.read()', Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['pico_i2c_request'] = function(block) {
  var addr  = block.getFieldValue('ADDR');
  var bytes = block.getFieldValue('BYTES');
  return 'Wire.requestFrom(' + addr + ', ' + bytes + ');\n';
};

// forever — while(true)
Blockly.Arduino.forBlock['forever'] = function(block) {
  const body = Blockly.Arduino.statementToCode(block, 'DO');
  return 'while (true) {\n' + body + '}\n';
};
