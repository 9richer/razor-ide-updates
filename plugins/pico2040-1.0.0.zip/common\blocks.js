// ============================================================
//  Raspberry Pi Pico (RP2040) Blocks
//  พื้นฐาน: Digital I/O, Analog, PWM, Serial, I2C, Timer
// ============================================================

// ══ I/O ══════════════════════════════════════════════════════

Blockly.Blocks['pico_pin_mode'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('pinMode GP')
        .appendField(new Blockly.FieldNumber(0, 0, 28), 'PIN')
        .appendField('เป็น')
        .appendField(new Blockly.FieldDropdown([
          ['OUTPUT','OUTPUT'],
          ['INPUT','INPUT'],
          ['INPUT_PULLUP','INPUT_PULLUP'],
          ['INPUT_PULLDOWN','INPUT_PULLDOWN'],
        ]), 'MODE');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e');
    this.setTooltip('ตั้งโหมด GPIO pin (GP0-GP28)');
  }
};

Blockly.Blocks['pico_digital_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalWrite GP')
        .appendField(new Blockly.FieldNumber(0, 0, 28), 'PIN')
        .appendField('=')
        .appendField(new Blockly.FieldDropdown([['HIGH','HIGH'],['LOW','LOW']]), 'VAL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e');
    this.setTooltip('ตั้งค่า digital output HIGH/LOW');
  }
};

Blockly.Blocks['pico_digital_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalRead GP')
        .appendField(new Blockly.FieldNumber(0, 0, 28), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e');
    this.setTooltip('อ่าน digital input (0/1)');
  }
};

Blockly.Blocks['pico_analog_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogRead')
        .appendField(new Blockly.FieldDropdown([
          ['GP26 (A0)','26'],
          ['GP27 (A1)','27'],
          ['GP28 (A2)','28'],
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e');
    this.setTooltip('อ่าน ADC 0-4095 (12-bit) — GP26, GP27, GP28 เท่านั้น');
  }
};

Blockly.Blocks['pico_pwm_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogWrite (PWM) GP')
        .appendField(new Blockly.FieldNumber(0, 0, 28), 'PIN')
        .appendField('ค่า');
    this.appendValueInput('VAL').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e');
    this.setTooltip('PWM output 0-255 (ทุก GP pin รองรับ PWM)');
  }
};

// ══ LED บนบอร์ด (GP25) ════════════════════════════════════════

Blockly.Blocks['pico_led_on'] = {
  init: function() {
    this.appendDummyInput().appendField('LED บนบอร์ด เปิด');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
    this.setTooltip('เปิด LED บนบอร์ด (GP25)');
  }
};

Blockly.Blocks['pico_led_off'] = {
  init: function() {
    this.appendDummyInput().appendField('LED บนบอร์ด ปิด');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
    this.setTooltip('ปิด LED บนบอร์ด (GP25)');
  }
};

Blockly.Blocks['pico_led_toggle'] = {
  init: function() {
    this.appendDummyInput().appendField('LED บนบอร์ด สลับ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
    this.setTooltip('สลับ LED บนบอร์ด on/off (GP25)');
  }
};

// ══ Serial ═══════════════════════════════════════════════════

Blockly.Blocks['pico_serial_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Serial.begin')
        .appendField(new Blockly.FieldDropdown([
          ['115200','115200'],['9600','9600'],
          ['57600','57600'],['230400','230400'],
        ]), 'BAUD');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b');
    this.setTooltip('เริ่ม USB Serial');
  }
};

Blockly.Blocks['pico_serial_print'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('Serial.print');
    this.appendDummyInput()
        .appendField(new Blockly.FieldCheckbox('TRUE'), 'NL')
        .appendField('newline');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b');
  }
};

Blockly.Blocks['pico_serial_available'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.available()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b');
  }
};

Blockly.Blocks['pico_serial_read'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.read()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b');
  }
};

Blockly.Blocks['pico_serial_readstring'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.readString()');
    this.setOutput(true, 'String');
    this.setColour('#c0392b');
  }
};

// ══ Timer ════════════════════════════════════════════════════

Blockly.Blocks['pico_delay_ms'] = {
  init: function() {
    this.appendValueInput('TIME').appendField('รอ (ms)');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8');
    this.setTooltip('หน่วงเวลา millisecond');
  }
};

Blockly.Blocks['pico_delay_us'] = {
  init: function() {
    this.appendValueInput('TIME').appendField('รอ (µs)');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8');
    this.setTooltip('หน่วงเวลา microsecond');
  }
};

Blockly.Blocks['pico_millis'] = {
  init: function() {
    this.appendDummyInput().appendField('millis()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8');
  }
};

Blockly.Blocks['pico_micros'] = {
  init: function() {
    this.appendDummyInput().appendField('micros()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8');
  }
};

// ══ Sound ════════════════════════════════════════════════════

Blockly.Blocks['pico_tone'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('tone GP')
        .appendField(new Blockly.FieldNumber(15, 0, 28), 'PIN')
        .appendField('ความถี่');
    this.appendValueInput('FREQ').setCheck('Number');
    this.appendDummyInput().appendField('นาน (ms)');
    this.appendValueInput('DUR').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
  }
};

Blockly.Blocks['pico_no_tone'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('noTone GP')
        .appendField(new Blockly.FieldNumber(15, 0, 28), 'PIN');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
  }
};

// ══ Math ══════════════════════════════════════════════════════

Blockly.Blocks['pico_map'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('map');
    this.appendValueInput('IN_MIN').appendField('จาก');
    this.appendValueInput('IN_MAX').appendField('ถึง');
    this.appendValueInput('OUT_MIN').appendField('→');
    this.appendValueInput('OUT_MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed');
  }
};

Blockly.Blocks['pico_constrain'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('constrain');
    this.appendValueInput('MIN').appendField('min');
    this.appendValueInput('MAX').appendField('max');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed');
  }
};

Blockly.Blocks['pico_random'] = {
  init: function() {
    this.appendValueInput('MIN').appendField('random จาก');
    this.appendValueInput('MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed');
  }
};

// ══ I2C ══════════════════════════════════════════════════════

Blockly.Blocks['pico_i2c_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('I2C เริ่มต้น SDA GP')
        .appendField(new Blockly.FieldDropdown([
          ['GP0','0'],['GP2','2'],['GP4','4'],['GP6','6'],
          ['GP8','8'],['GP10','10'],['GP12','12'],['GP14','14'],
          ['GP16','16'],['GP18','18'],['GP20','20'],['GP26','26'],
        ]), 'SDA')
        .appendField('SCL GP')
        .appendField(new Blockly.FieldDropdown([
          ['GP1','1'],['GP3','3'],['GP5','5'],['GP7','7'],
          ['GP9','9'],['GP11','11'],['GP13','13'],['GP15','15'],
          ['GP17','17'],['GP19','19'],['GP21','21'],['GP27','27'],
        ]), 'SCL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('เริ่มต้น I2C — เลือก SDA/SCL GP pin');
  }
};

Blockly.Blocks['pico_i2c_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('I2C write address')
        .appendField(new Blockly.FieldNumber(0x3C, 0, 127), 'ADDR');
    this.appendValueInput('DATA').appendField('data');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('เขียนข้อมูลผ่าน I2C');
  }
};

Blockly.Blocks['pico_i2c_read'] = {
  init: function() {
    this.appendDummyInput().appendField('I2C read()');
    this.setOutput(true, 'Number');
    this.setColour('#0891b2');
    this.setTooltip('อ่าน 1 byte จาก I2C');
  }
};

Blockly.Blocks['pico_i2c_request'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('I2C requestFrom address')
        .appendField(new Blockly.FieldNumber(0x3C, 0, 127), 'ADDR')
        .appendField('bytes')
        .appendField(new Blockly.FieldNumber(1, 1, 32), 'BYTES');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('ขอรับข้อมูลจาก I2C device');
  }
};

// forever — while(true)
// แต่ละ board กำหนด style เองได้อิสระ (สี, tooltip, format)
Blockly.Blocks['forever'] = {
  init: function() {
    this.appendStatementInput('DO').appendField('🔁 Forever');
    this.setPreviousStatement(true);
    this.setNextStatement(false);
    this.setColour('#e63946');
    this.setTooltip('while(true) — วนซ้ำตลอดไป');
  }
};
