// ============================================================
//  Board Blocks — ใส่ Blockly.Blocks['block_name'] ที่นี่
// ============================================================

// ตัวอย่าง: Motor block
Blockly.Blocks['my_board_move'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('เดินหน้า ความเร็ว')
        .appendField(new Blockly.FieldNumber(50, 0, 100), 'SPEED');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(210);
  }
};

// ── forever block ────────────────────────────────────────────
// แต่ละ board กำหนดเองได้อิสระ: สี, tooltip, label
// คนสร้างบอร์ดใหม่ copy block นี้ไปปรับได้เลย
Blockly.Blocks['forever'] = {
  init: function() {
    this.appendStatementInput('DO').appendField('🔁 Forever');
    this.setPreviousStatement(true);
    this.setNextStatement(false);
    this.setColour('#e63946');
    this.setTooltip('while(true) — วนซ้ำตลอดไป');
  }
};
