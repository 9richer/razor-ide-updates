// ============================================================
//  Board Generator — ใส่ Blockly.Arduino.forBlock['block_name'] ที่นี่
// ============================================================

Blockly.Arduino.forBlock['my_board_move'] = function(block) {
  const speed = block.getFieldValue('SPEED');
  return 'move(' + speed + ');\n';
};

// ── forever generator ────────────────────────────────────────
// ปรับ format โค้ดที่ generate ได้ตามสไตล์ของบอร์ด
Blockly.Arduino.forBlock['forever'] = function(block) {
  const body = Blockly.Arduino.statementToCode(block, 'DO');
  return 'while (true) {\n' + body + '}\n';
};
