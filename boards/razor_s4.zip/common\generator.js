// Razor-S4 Generators  (Blockly.Arduino เท่านั้น)




Blockly.Arduino.forBlock['wait_ms'] = function(block) {
  const t = _v(block, 'time', '1000');
  return 'delay(' + t + ');\n';
};


//--------------------sensor-----------------------------------------------

Blockly.Arduino.forBlock['wait_go'] = function(block) {

  return 'sw_go();\n';
};

Blockly.Arduino.forBlock['sw10_status'] = function(block) {

  return ['SW10()', Blockly.Arduino.ORDER_ATOMIC];
};


Blockly.Arduino.forBlock['beep'] = function(block) {
  return 'Beep();\n';
};



Blockly.Arduino.forBlock['forever'] = function(block) {   //forever block


  var statements_do =
      Blockly.Arduino.statementToCode(
        block,
        'DO'
      );

  var code =
`while(true)
{
${statements_do}
}
`;

  return code;
};

//--------------------------------motor-----------------------------------------------------

Blockly.Arduino.forBlock['motor_set'] = function(block) {  //รวมมอเตอร์

  const motor = block.getFieldValue('MOTOR');

  const dir = block.getFieldValue('DIR');

  let spd = Blockly.Arduino.valueToCode(
    block,
    'SPD',
    Blockly.Arduino.ORDER_ATOMIC
  ) || 0;

  if (dir === 'BWD') {
    spd = `-${spd}`;
  }

  if (dir === 'STOP') {
    spd = 0;
  }

  return `motor${motor}(${spd});\n`;
};




Blockly.Arduino.forBlock['motorL'] = function(block) {   //มอเตอร์ซ้าย

  const spd = _v(block, 'SPD', '50');

  return `motorL(${spd});\n`;
};

Blockly.Arduino.forBlock['motorR'] = function(block) {  //มอเตอร์ขวา

  const spd = _v(block, 'SPD', '50');

  return `motorR(${spd});\n`;
};

Blockly.Arduino.forBlock['stop_motor'] = function(block) {  //หยุดมอเตอร์
  return 'ao();\n';
};

Blockly.Arduino.forBlock['motor_forward'] = function(block) {
  const spdL = _v(block, 'SPDL', '50');
  const spdR = _v(block, 'SPDR', '50');
  return `fd2(${spdL}, ${spdR});\n`;
};

Blockly.Arduino.forBlock['motor_backward'] = function(block) {
  const spdL = _v(block, 'SPDL', '50');
  const spdR = _v(block, 'SPDR', '50');
  return `bk(${spdL}, ${spdR});\n`;
};


Blockly.Arduino.forBlock['robot_move'] = function(block) {  //การเคลื่อนที่หมุน เลี้ยว

  const dir = block.getFieldValue('DIR');

  const spd = Blockly.Arduino.valueToCode(
    block,
    'SPD',
    Blockly.Arduino.ORDER_ATOMIC
  ) || 0;

  let func = 'fd2';  // FIX: fallback ที่ปลอดภัย กัน DIR ที่ไม่รู้จัก

  if (dir === 'SR') func = 'sr';
  else if (dir === 'SL') func = 'sl';
  else if (dir === 'TR') func = 'tr';
  else if (dir === 'TL') func = 'tl';

  return `${func}(${spd});\n`;
};

// ── OLED Generators ──────────────────────────────────────────
// myoled.h มีฟังก์ชัน:
//   razors4()          — init OLED (เรียกใน setup อัตโนมัติ)
//   oled(line, value, size) — แสดงค่าที่บรรทัด line
//   oled_clear()       — ล้างหน้าจอ
//   oled_update()      — สั่งแสดงผลจริง (display.display())

// oled_show: แสดงค่าที่บรรทัดที่เลือก
// ใช้งาน: OLED [ค่า] line [1-6] size [1-3]
Blockly.Arduino.forBlock['oled_show'] = function(block) {
  // handle block type "text" (shadow string) และ block อื่นๆ
  var value = '""';
  var inputBlock = block.getInputTargetBlock('VALUE');
  if (inputBlock) {
    if (inputBlock.type === 'text') {
      var txt = inputBlock.getFieldValue('TEXT') || '';
      // escape " ใน string — ใช้ split/join แทน regex ป้องกัน SyntaxError
      // FIX: '\"' ใน JS = '"' (ไม่มี backslash) ต้องใช้ '\\"' แบบเดียวกับ oled_xy
      txt = txt.split('"').join('\\"');
      value = '"' + txt + '"';
    } else {
      value = Blockly.Arduino.valueToCode(
        block, 'VALUE', Blockly.Arduino.ORDER_ATOMIC
      ) || '""';
    }
  }
  var line = block.getFieldValue('LINE') || '1';
  var size = block.getFieldValue('SIZE') || '1';
  return 'oled(' + line + ', ' + value + ', ' + size + ');\n';
};

// oled_clear: ล้างหน้าจอ
Blockly.Arduino.forBlock['oled_clear'] = function(block) {
  return 'oled_clear();\n';
};

// oled_update: สั่งแสดงผลจริงบนจอ
Blockly.Arduino.forBlock['oled_update'] = function(block) {
  return 'oled_update();\n';
};

// ── OLED Graphic Generators ──────────────────────────────────

Blockly.Arduino.forBlock['oled_line'] = function(block) {
  var x1 = _v(block, 'X1', '0');
  var y1 = _v(block, 'Y1', '0');
  var x2 = _v(block, 'X2', '64');
  var y2 = _v(block, 'Y2', '32');
  return 'oled_line(' + x1 + ', ' + y1 + ', ' + x2 + ', ' + y2 + ');\n';
};

Blockly.Arduino.forBlock['oled_rect'] = function(block) {
  var x = _v(block, 'X', '0');
  var y = _v(block, 'Y', '0');
  var w = _v(block, 'W', '40');
  var h = _v(block, 'H', '20');
  return 'oled_rect(' + x + ', ' + y + ', ' + w + ', ' + h + ');\n';
};

Blockly.Arduino.forBlock['oled_fill_rect'] = function(block) {
  var x = _v(block, 'X', '0');
  var y = _v(block, 'Y', '0');
  var w = _v(block, 'W', '40');
  var h = _v(block, 'H', '20');
  return 'oled_fill_rect(' + x + ', ' + y + ', ' + w + ', ' + h + ');\n';
};

Blockly.Arduino.forBlock['oled_circle'] = function(block) {
  var x = _v(block, 'X', '64');
  var y = _v(block, 'Y', '32');
  var r = _v(block, 'R', '10');
  return 'oled_circle(' + x + ', ' + y + ', ' + r + ');\n';
};

Blockly.Arduino.forBlock['oled_fill_circle'] = function(block) {
  var x = _v(block, 'X', '64');
  var y = _v(block, 'Y', '32');
  var r = _v(block, 'R', '10');
  return 'oled_fill_circle(' + x + ', ' + y + ', ' + r + ');\n';
};

Blockly.Arduino.forBlock['oled_xy'] = function(block) {
  var x    = _v(block, 'X', '0');
  var y    = _v(block, 'Y', '0');
  var size = block.getFieldValue('SIZE');
  var inputBlock = block.getInputTargetBlock('VALUE');
  var value = '""';
  if (inputBlock) {
    if (inputBlock.type === 'text') {
      var txt = inputBlock.getFieldValue('TEXT') || '';
      txt = txt.split('"').join('\\"');
      value = '"' + txt + '"';
    } else {
      value = Blockly.Arduino.valueToCode(block, 'VALUE', Blockly.Arduino.ORDER_ATOMIC) || '""';
    }
  }
  return 'oled_xy(' + x + ', ' + y + ', ' + value + ', ' + size + ');\n';
};

Blockly.Arduino.forBlock['oled_invert'] = function(block) {
  var invert = block.getFieldValue('INVERT');
  return 'oled_invert(' + invert + ');\n';
};

Blockly.Arduino.forBlock['oled_dim'] = function(block) {
  var dim = block.getFieldValue('DIM');
  return 'oled_dim(' + dim + ');\n';
};

Blockly.Arduino.forBlock['oled_progress'] = function(block) {
  var x   = _v(block, 'X', '0');
  var y   = _v(block, 'Y', '50');
  var w   = _v(block, 'W', '128');
  var h   = _v(block, 'H', '10');
  var val = _v(block, 'VALUE', '0');
  return 'oled_progress(' + x + ', ' + y + ', ' + w + ', ' + h + ', ' + val + ');\n';
};

// ══════════════════════════════════════════════════════════════
//  MCP3008 / MCP3208 — ADC Generators
// ══════════════════════════════════════════════════════════════

Blockly.Arduino.forBlock['adc_read'] = function(block) {
  const chip = block.getFieldValue('CHIP');  // '3008' หรือ '3208'
  const ch   = block.getFieldValue('CH');
  return [`analog${chip}(${ch})`, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['adc_voltage'] = function(block) {
  const chip = block.getFieldValue('CHIP');
  const ch   = block.getFieldValue('CH');
  return [`analogVolt${chip}(${ch})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ══════════════════════════════════════════════════════════════
//  IMU / BNO055 Generators
// ══════════════════════════════════════════════════════════════

Blockly.Arduino.forBlock['imu_get_yaw'] = function(block) {
  return ['getYaw()', Blockly.Arduino.ORDER_UNARY_POSTFIX];
};

Blockly.Arduino.forBlock['imu_get_yaw_raw'] = function(block) {
  return ['getYawRaw()', Blockly.Arduino.ORDER_UNARY_POSTFIX];
};

Blockly.Arduino.forBlock['imu_calibrate'] = function(block) {
  return 'initIMU();\ncalibrateYawStart();\n';
};

Blockly.Arduino.forBlock['imu_reset_yaw'] = function(block) {
  const samples = _v(block, 'SAMPLES', '10');
  return 'resetYaw(' + samples + ');\n';
};

// ── helper: valueToCode พร้อม fallback ─────────────────────────
function _v(block, name, def) {
  return Blockly.Arduino.valueToCode(block, name, Blockly.Arduino.ORDER_ATOMIC) || def;
}

Blockly.Arduino.forBlock['imu_turnF_pid'] = function(block) {
  const yaw  = _v(block, 'YAW',  '90');
  const smin = _v(block, 'SMIN', '20');
  const smax = _v(block, 'SMAX', '80');
  const kp   = _v(block, 'KP',   '2.0');
  const kd   = _v(block, 'KD',   '0.1');
  const err  = _v(block, 'ERR',  '5.0');
  return `TurnF_PID(${yaw}, ${smin}, ${smax}, ${kp}, ${kd}, ${err});\n`;
};

Blockly.Arduino.forBlock['imu_turnB_pid'] = function(block) {
  const yaw  = _v(block, 'YAW',  '90');
  const smin = _v(block, 'SMIN', '20');
  const smax = _v(block, 'SMAX', '80');
  const kp   = _v(block, 'KP',   '2.0');
  const kd   = _v(block, 'KD',   '0.1');
  const err  = _v(block, 'ERR',  '5.0');
  return `TurnB_PID(${yaw}, ${smin}, ${smax}, ${kp}, ${kd}, ${err});\n`;
};

Blockly.Arduino.forBlock['imu_turnF_pid_dir'] = function(block) {
  const yaw  = block.getFieldValue('YAW');   // dropdown → ยังใช้ getFieldValue
  const smin = _v(block, 'SMIN', '20');
  const smax = _v(block, 'SMAX', '80');
  const kp   = _v(block, 'KP',   '2.0');
  const kd   = _v(block, 'KD',   '0.1');
  const err  = _v(block, 'ERR',  '5.0');
  return `TurnF_PID(${yaw}, ${smin}, ${smax}, ${kp}, ${kd}, ${err});\n`;
};

Blockly.Arduino.forBlock['imu_turnB_pid_dir'] = function(block) {
  const yaw  = block.getFieldValue('YAW');   // dropdown → ยังใช้ getFieldValue
  const smin = _v(block, 'SMIN', '20');
  const smax = _v(block, 'SMAX', '80');
  const kp   = _v(block, 'KP',   '2.0');
  const kd   = _v(block, 'KD',   '0.1');
  const err  = _v(block, 'ERR',  '5.0');
  return `TurnB_PID(${yaw}, ${smin}, ${smax}, ${kp}, ${kd}, ${err});\n`;
};

Blockly.Arduino.forBlock['imu_move'] = function(block) {
  const dir      = block.getFieldValue('DIR');    // dropdown
  const yaw      = block.getFieldValue('YAW');    // dropdown
  const spd      = _v(block, 'SPD', '50');
  const time     = _v(block, 'TIME', '500');
  const kp       = _v(block, 'KP', '1');
  const ki       = _v(block, 'KI', '0');
  const kd       = _v(block, 'KD', '0.1');
  const rampup   = _v(block, 'RAMPUP', '0');
  const rampdown = _v(block, 'RAMPDOWN', '0');
  const startspd = _v(block, 'STARTSPD', '30');
  return `MOVE(${dir}, ${yaw}, ${spd}, ${time}, ${kp}, ${ki}, ${kd}, ${rampup}, ${rampdown}, ${startspd});\n`;
};

Blockly.Arduino.forBlock['imu_move_num'] = function(block) {
  const dir      = block.getFieldValue('DIR');    // dropdown
  const yaw      = _v(block, 'YAW', '0');
  const spd      = _v(block, 'SPD', '50');
  const time     = _v(block, 'TIME', '500');
  const kp       = _v(block, 'KP', '1');
  const ki       = _v(block, 'KI', '0');
  const kd       = _v(block, 'KD', '0.1');
  const rampup   = _v(block, 'RAMPUP', '0');
  const rampdown = _v(block, 'RAMPDOWN', '0');
  const startspd = _v(block, 'STARTSPD', '30');
  return `MOVE(${dir}, ${yaw}, ${spd}, ${time}, ${kp}, ${ki}, ${kd}, ${rampup}, ${rampdown}, ${startspd});\n`;
};

Blockly.Arduino.forBlock['imu_spin_config'] = function(block) {
  const kpf = _v(block, 'KP_FAST', '6.0');
  const kpm = _v(block, 'KP_MID', '3.5');
  const kps = _v(block, 'KP_SLOW', '1.5');
  const kd  = _v(block, 'KD', '0.3');
  return `setSpinConfig(${kpf}, ${kpm}, ${kps}, ${kd});\n`;
};

Blockly.Arduino.forBlock['imu_spin_to_dir'] = function(block) {
  const yaw  = block.getFieldValue('YAW');   // dropdown
  const err  = _v(block, 'ERR', '1.5');
  const tout = _v(block, 'TIMEOUT', '200');
  const smin = _v(block, 'SMIN', '40');
  const smax = _v(block, 'SMAX', '70');
  return `spinTo(${yaw}, ${err}, ${tout}, ${smin}, ${smax});\n`;
};

Blockly.Arduino.forBlock['imu_spin_to_num'] = function(block) {
  const yaw  = _v(block, 'YAW', '90');
  const err  = _v(block, 'ERR', '1.5');
  const tout = _v(block, 'TIMEOUT', '200');
  const smin = _v(block, 'SMIN', '40');
  const smax = _v(block, 'SMAX', '70');
  return `spinTo(${yaw}, ${err}, ${tout}, ${smin}, ${smax});\n`;
};

Blockly.Arduino.forBlock['servo_move'] = function(block) {
  const pin   = block.getFieldValue('PIN');   // dropdown
  const angle = _v(block, 'ANGLE', '90');
  const speed = _v(block, 'SPEED', '10');
  return `servo(${pin}, ${angle}, ${speed});\n`;
};

Blockly.Arduino.forBlock['servo_fast'] = function(block) {
  const pin   = block.getFieldValue('PIN');   // dropdown
  const angle = _v(block, 'ANGLE', '90');
  return `servoFast(${pin}, ${angle});\n`;
};

Blockly.Arduino.forBlock['line_calibrate'] = function(block) {
  const chip = block.getFieldValue('CHIP');   // dropdown
  const dur  = _v(block, 'DUR', '5000');
  return `autoScanSensor(${chip}, ${dur});\n`;
};

Blockly.Arduino.forBlock['line_load_cal'] = function(block) {
  return `loadCalibration();\n`;
};

Blockly.Arduino.forBlock['line_get_ref'] = function(block) {
  const ch = block.getFieldValue('CH');
  return [`getRef(${ch})`, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['line_on_line'] = function(block) {
  const ch   = block.getFieldValue('CH');
  const type = block.getFieldValue('TYPE');
  return [`sensorOnLine(${ch}, ${type})`, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['line_count'] = function(block) {
  const from = block.getFieldValue('FROM');
  const to   = block.getFieldValue('TO');
  const type = block.getFieldValue('TYPE');
  return [`countSensors(${from}, ${to}, ${type})`, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['line_show'] = function(block) {
  const from = block.getFieldValue('FROM');
  const to   = block.getFieldValue('TO');
  const row  = block.getFieldValue('ROW');
  const type = block.getFieldValue('TYPE');
  return `showSensors(${from}, ${to}, ${row}, ${type});\n`;
};

Blockly.Arduino.forBlock['line_position'] = function(block) {
  const from = block.getFieldValue('FROM');
  const to   = block.getFieldValue('TO');
  const type = block.getFieldValue('TYPE');
  return [`linePosition(${from}, ${to}, ${type})`, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['ultrasonic_read'] = function(block) {
  const trig = block.getFieldValue('TRIG');
  const echo = block.getFieldValue('ECHO');
  return [`sonarRead(${trig}, ${echo})`, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['imu_move_wall'] = function(block) {
  const dir      = block.getFieldValue('DIR');    // dropdown
  const yaw      = block.getFieldValue('YAW');    // dropdown
  const startspd = _v(block, 'STARTSPD', '30');
  const spd      = _v(block, 'SPD', '50');
  const time     = _v(block, 'TIME', '1000');
  const kpyaw    = _v(block, 'KP_YAW', '1.0');
  const kpwall   = _v(block, 'KP_WALL', '0.5');
  const dist     = _v(block, 'DIST', '20');
  const trig     = block.getFieldValue('TRIG');   // dropdown
  const echo     = block.getFieldValue('ECHO');   // dropdown
  const rampup   = _v(block, 'RAMPUP', '0');
  const rampdown = _v(block, 'RAMPDOWN', '0');
  return `MOVE_WALL(${dir}, ${yaw}, ${spd}, ${time}, ${kpyaw}, ${kpwall}, ${dist}, ${trig}, ${echo}, ${rampup}, ${rampdown}, ${startspd});\n`;
};

Blockly.Arduino.forBlock['reset_drop'] = function(block) {
  return 'resetDrop();\n';
};

Blockly.Arduino.forBlock['imu_move_wall_until'] = function(block) {
  const dir      = block.getFieldValue('DIR');    // dropdown
  const yaw      = block.getFieldValue('YAW');    // dropdown
  const startspd = _v(block, 'STARTSPD', '30');
  const spd      = _v(block, 'SPD', '60');
  const stopdist = _v(block, 'STOPDIST', '15');
  const trigf    = block.getFieldValue('TRIGF');  // dropdown
  const echof    = block.getFieldValue('ECHOF');  // dropdown
  const timeout  = _v(block, 'TIMEOUT', '5000');
  const kpyaw    = _v(block, 'KPYAW', '1.0');
  const kpwall   = _v(block, 'KPWALL', '0.5');
  const walldist = _v(block, 'WALLDIST', '20');
  const trigs    = block.getFieldValue('TRIGS');  // dropdown
  const echos    = block.getFieldValue('ECHOS');  // dropdown
  const type     = block.getFieldValue('TYPE');   // dropdown
  const overtime = _v(block, 'OVERTIME', '300');
  const maxback  = _v(block, 'MAXBACK', '2');
  const pinback  = block.getFieldValue('PINBACK');  // dropdown
  const angback  = _v(block, 'ANGBACK', '0');
  const pinfront = block.getFieldValue('PINFRONT'); // dropdown
  const angfront = _v(block, 'ANGFRONT', '0');
  return `MOVE_WALL_UNTIL(${dir}, ${yaw}, ${spd}, ${startspd}, ${stopdist}, ${trigf}, ${echof}, ${kpyaw}, ${kpwall}, ${walldist}, ${trigs}, ${echos}, ${type}, ${overtime}, ${pinback}, ${angback}, ${pinfront}, ${angfront}, ${maxback}, ${timeout});\n`;
};

Blockly.Arduino.forBlock['imu_move_loop_reset'] = function(block) {
  return 'MOVE_LOOP_RESET();\n';
};

Blockly.Arduino.forBlock['imu_move_loop'] = function(block) {
  const dir      = block.getFieldValue('DIR');    // dropdown
  const yaw      = block.getFieldValue('YAW');    // dropdown
  const startspd = _v(block, 'STARTSPD', '30');
  const spd      = _v(block, 'SPD', '60');
  const kpyaw    = _v(block, 'KPYAW', '1.0');
  const kdyaw    = _v(block, 'KDYAW', '0');
  return `MOVE_LOOP(${dir}, ${yaw}, ${spd}, ${kpyaw}, ${kdyaw}, ${startspd});\n`;
};

Blockly.Arduino.forBlock['imu_move_loop_num'] = function(block) {
  const dir      = block.getFieldValue('DIR');    // dropdown
  const yaw      = _v(block, 'YAW', '0');        // value input — พิมพ์/เสียบตัวแปรได้
  const startspd = _v(block, 'STARTSPD', '30');
  const spd      = _v(block, 'SPD', '60');
  const kpyaw    = _v(block, 'KPYAW', '1.0');
  const kdyaw    = _v(block, 'KDYAW', '0');
  return `MOVE_LOOP(${dir}, ${yaw}, ${spd}, ${kpyaw}, ${kdyaw}, ${startspd});\n`;
};

Blockly.Arduino.forBlock['imu_move_wall_loop'] = function(block) {
  const dir      = block.getFieldValue('DIR');    // dropdown
  const yaw      = block.getFieldValue('YAW');    // dropdown
  const startspd = _v(block, 'STARTSPD', '30');
  const spd      = _v(block, 'SPD', '60');
  const kpyaw    = _v(block, 'KPYAW', '1.0');
  const kpwall   = _v(block, 'KPWALL', '0.5');
  const walldist = _v(block, 'WALLDIST', '20');
  const trig     = block.getFieldValue('TRIG');   // dropdown
  const echo     = block.getFieldValue('ECHO');   // dropdown
  return `MOVE_WALL_LOOP(${dir}, ${yaw}, ${spd}, ${kpyaw}, ${kpwall}, ${walldist}, ${trig}, ${echo}, ${startspd});\n`;
};

Blockly.Arduino.forBlock['motor_scale'] = function(block) {
  const offsetL = _v(block, 'SCALEL', '0');
  const offsetR = _v(block, 'SCALER', '0');
  return `setMotorOffset(${offsetL}, ${offsetR});\n`;
};

// ── Robot Menu ────────────────────────────────────────────────
// กดสั้น (< 600ms) = เลือก & รัน  |  กดค้าง (≥ 600ms) = เลื่อนถัดไป
// OLED scrolling window — รองรับ 2-8 รายการ
Blockly.Arduino.forBlock['robot_menu'] = function(block) {
  const count = block.itemCount_ || 4;
  const names = [];
  const dos   = [];
  for (let i = 0; i < count; i++) {
    names.push((block.getFieldValue('NAME' + i) || ('Mode ' + (i + 1))).split('"').join('\\"'));
    dos.push(Blockly.Arduino.statementToCode(block, 'DO' + i));
  }

  let code = '{\n';
  code += '  int _ms = 0;\n';
  code += '  const int _mc = ' + count + ';\n';
  code += '  const char* _mn[' + count + '] = {' +
          names.map(function(n){ return '"' + n + '"'; }).join(', ') + '};\n';

  // lambda แสดงเมนู — scrolling window 4 บรรทัด + header position
  code += '  auto _mshow = [&]() {\n';
  code += '    oled_clear();\n';
  code += '    char _hdr[18]; snprintf(_hdr, 18, "[ %d/%d ]", _ms + 1, _mc);\n';
  code += '    oled(1, _hdr, 1);\n';
  // คำนวณ window: เลื่อนให้ cursor อยู่บรรทัดที่ 2 ของ window เสมอ
  code += '    int _win = _ms - 1;\n';
  code += '    if (_win < 0) _win = 0;\n';
  code += '    if (_win + 4 > _mc) _win = _mc - 4;\n';
  code += '    if (_win < 0) _win = 0;\n';
  code += '    for (int _wi = 0; _wi < 4 && _win + _wi < _mc; _wi++) {\n';
  code += '      int _ii = _win + _wi;\n';
  code += '      char _row[18];\n';
  code += '      snprintf(_row, 18, "%c%.15s", _ii == _ms ? \'>\' : \' \', _mn[_ii]);\n';
  code += '      oled(_wi + 2, _row, 1);\n';
  code += '    }\n';
  code += '    oled_update();\n';
  code += '  };\n';

  // navigation loop
  code += '  _mshow();\n';
  code += '  while (true) {\n';
  code += '    if (SW10()) {\n';
  code += '      unsigned long _ts = millis();\n';
  code += '      while (SW10()) delay(10);\n';
  code += '      if (millis() - _ts < 600) break;\n';  // กดสั้น = เลือก
  code += '      _ms = (_ms + 1) % _mc;\n';            // กดค้าง = ถัดไป
  code += '      _mshow();\n';
  code += '    }\n';
  code += '    delay(20);\n';
  code += '  }\n';

  // ยืนยันบน OLED แล้วรัน
  code += '  oled_clear();\n';
  code += '  oled(3, "STARTING...", 2);\n';
  code += '  oled_update(); delay(400);\n';

  for (let i = 0; i < count; i++) {
    if (i === 0)           code += '  if (_ms == 0) {\n' + dos[i];
    else if (i === count - 1) code += '  } else {\n' + dos[i];
    else                   code += '  } else if (_ms == ' + i + ') {\n' + dos[i];
  }
  code += '  }\n}\n';
  return code;
};