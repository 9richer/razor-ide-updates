#pragma once

// ══════════════════════════════════════════════════════════════
//  Motor Offset — ชดเชยมอเตอร์ซ้าย/ขวาไม่เท่ากัน
//  ตั้งค่าใน Setup ครั้งเดียว → ใช้ได้ทุกฟังก์ชัน
//
//  offsetL > 0 → เพิ่มซ้าย (ถ้าซ้ายช้ากว่า)
//  offsetL < 0 → ลดซ้าย   (ถ้าซ้ายเร็วกว่า)
//  offsetR > 0 → เพิ่มขวา
//  offsetR < 0 → ลดขวา
// ══════════════════════════════════════════════════════════════

static int _offsetL = 0;
static int _offsetR = 0;

inline void setMotorOffset(int offsetL, int offsetR) {
  _offsetL = offsetL;
  _offsetR = offsetR;
}

inline void motor1(int speed1)   
    {
      pinMode(0,OUTPUT);  //pwm Motor1  12 
      pinMode(11,OUTPUT);     
      pinMode(12,OUTPUT);     

       if(speed1>100)
         {
          speed1 = 100;
         }
       else if(speed1<-100)
         {
          speed1 = -100;
         }
      

      if(speed1>0)
         {
            analogWrite(0,(speed1*255)/100);
            digitalWrite(11,HIGH);
            digitalWrite(12,LOW); 
         }
      else if(speed1<0)
         {
            analogWrite(0,-(speed1*255)/100);
            digitalWrite(11,LOW);
            digitalWrite(12,HIGH); 
         }
      else
         {
            analogWrite(0,255);
            digitalWrite(11,LOW);
            digitalWrite(12,LOW); 
         }



       
    }

inline void motor2(int speed1) {

      pinMode(1,OUTPUT);  //pwm Motor2 
      pinMode(20,OUTPUT);     
      pinMode(21,OUTPUT);     

       if(speed1>100)
         { speed1 = 100;  }
       else if(speed1<-100)
         { speed1 = -100;}

  if(speed1 > 0)
  {
    analogWrite(1, (speed1*255)/100);
    digitalWrite(20, HIGH);
    digitalWrite(21, LOW);
  }
  else if(speed1 < 0)
  {
    analogWrite(1, -(speed1*255)/100);
    digitalWrite(20,LOW );
    digitalWrite(21, HIGH);
  }
  else
  {
    // brake
    digitalWrite(20, LOW);
    digitalWrite(21, LOW);
    analogWrite(1, 255);
  }
}


inline void motor3(int speed1)   
    {
      pinMode(2,OUTPUT);  //pwm Motor2 
      pinMode(15,OUTPUT);     
      pinMode(22,OUTPUT);     
       if(speed1>100)
         { speed1 = 100;  }
       else if(speed1<-100)
         { speed1 = -100;}

      if(speed1>0)
         {
            analogWrite(2,(speed1*255)/100);
            digitalWrite(15,HIGH);
            digitalWrite(22,LOW); 
         }
      else if(speed1<0)
         {
            analogWrite(2,-(speed1*255)/100);
            digitalWrite(15,LOW);
            digitalWrite(22,HIGH); 
         }
      else
         {
            analogWrite(2,255);
            digitalWrite(15,LOW);
            digitalWrite(22,LOW); 
         }


       
    }


    inline void motor4(int speed1)   
    {
      pinMode(3,OUTPUT);  //pwm Motor2 
      pinMode(13,OUTPUT);     
      pinMode(14,OUTPUT);     
      if(speed1>100)
         { speed1 = 100;  }
      else if(speed1<-100)
         { speed1 = -100;}

      if(speed1>0)
         {
            analogWrite(3,(speed1*255)/100);
            digitalWrite(13,HIGH);
            digitalWrite(14,LOW); 
         }
      else if(speed1<0)
         {
            analogWrite(3,-(speed1*255)/100);
            digitalWrite(13,LOW);
            digitalWrite(14,HIGH); 
         }
      else
         {
            analogWrite(3,255);
            digitalWrite(13,LOW);
            digitalWrite(14,LOW);  // FIX: pin 14 = IN2 ของ motor4 (ไม่ใช่ 22 ซึ่งเป็น motor3)
         }


       
    }

inline void motorL(int SPR) {
  int spd = constrain(SPR + _offsetL, -100, 100);
  motor1(spd);
  motor2(spd);
}

inline void motorR(int SPR) {
  int spd = constrain(SPR + _offsetR, -100, 100);
  motor3(spd);
  motor4(spd);
}


    inline void sr(int SPR)  //หมุนขวา
  {
    motor1(SPR);
    motor2(SPR);
    motor3(-SPR);
    motor4(-SPR);
  
  }

 inline void sl(int SPL) //หมุนซ้าย
  {
    motor1(-SPL);
    motor2(-SPL);
    motor3(SPL);
    motor4(SPL);
  
  }

  inline void tr(int SPR)  //เลี้ยวขวา
  {
    motor1(SPR);
    motor2(SPR);
    motor3(0);
    motor4(0);
  
  }

 inline void tl(int SPL)  //เลี้ยวซ้าย
  {
    motor1(0);
    motor2(0);
    motor3(SPL);
    motor4(SPL);
  
  }

inline void fd2(int speedL, int speedR) {
  motor1(speedL);
  motor2(speedL);
  motor3(speedR);
  motor4(speedR);
}

inline void bk(int speedL, int speedR) {
  motor1(-speedL);
  motor2(-speedL);
  motor3(-speedR);
  motor4(-speedR);
}

  inline void ao() {
  
  analogWrite(0, 0); 
  digitalWrite(11, 1);
  digitalWrite(12, 1);
 
  analogWrite(1,0);
  digitalWrite(20,1);
  digitalWrite(21,1); 

  analogWrite(2,0);
  digitalWrite(15,1);
  digitalWrite(22,1);

  analogWrite(3,0);
  digitalWrite(13,1);
  digitalWrite(14,1); 

} 


