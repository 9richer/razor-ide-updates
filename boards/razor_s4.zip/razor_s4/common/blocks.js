// ==========================================
// RAZOR-S3 Blocks  (ใช้ Blockly.Arduino เท่านั้น)
// ==========================================



Blockly.Blocks['wait_ms'] = {
  init: function() {
    this.appendDummyInput().appendField('รอ');
    this.appendValueInput('time').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(0);
    this.setTooltip('หน่วงเวลา (ms)');
  }
};

// --- Sound ---

Blockly.Blocks['beep'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Beep');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(300);
    this.setTooltip('เปิดเสียงบีบ');
  }
};

// --- Sensor ---------------------------------------

Blockly.Blocks['wait_go'] = {      //sw_press

  init: function() {

    this.appendDummyInput()
        .appendField("รอปุ่มเริ่ม");

    this.setPreviousStatement(true);

    this.setNextStatement(true);

    this.setColour("#16a34a");

    this.setTooltip("รอจนกว่าจะกดปุ่มเริ่ม");
  }
};


Blockly.Blocks['sw10_status'] = {

  init: function() {

    this.appendDummyInput()
        .appendField("🔘 sw10_status");

    this.setOutput(true, null);

    this.setColour("#eab308");

    this.setTooltip("ตรวจสอบปุ่ม SW10 — คืน 1 (กด) หรือ 0 (ไม่กด)");
  }
};



Blockly.Blocks['forever'] = {
  init: function() {

    this.appendStatementInput("DO")
        .appendField("Forever");

    this.setColour("#ff3366");

    this.setPreviousStatement(true);
    this.setNextStatement(false);

  }
};

//--------------------------------------มอเตอร์---------------------------------------------

Blockly.Blocks['motor_set'] = {
  init: function() {

    this.appendDummyInput()
        .appendField("set motor")

        .appendField(
          new Blockly.FieldDropdown([
            ["1", "1"],
            ["2", "2"],
            ["3", "3"],
            ["4", "4"]
          ]),
          "MOTOR"
        )

        .appendField("direction")

        .appendField(
          new Blockly.FieldDropdown([
            ["Forward", "FWD"],
            ["Backward", "BWD"],
            ["Brake", "STOP"]
          ]),
          "DIR"
        )

        .appendField("speed");

    this.appendValueInput("SPD")
        .setCheck("Number");

    this.appendDummyInput()
        .appendField("%");

    this.setPreviousStatement(true, null);

    this.setNextStatement(true, null);

    this.setColour(0);
  }
};


Blockly.Blocks['motorL'] = {   //ขับมอเตอร์ซ้าย motor1 และmotor2 พร้อมกัน
  init: function() {
    this.appendDummyInput().appendField('motorL speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(0);
  }
};



Blockly.Blocks['motorR'] = {
  init: function() {
    this.appendDummyInput().appendField('motorR speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(0);
  }
};

Blockly.Blocks['stop_motor'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('หยุด');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(0);
    this.setTooltip('หยุดมอเตอร์ทั้งหมด');
  }
};

Blockly.Blocks['motor_forward'] = {
  init: function() {
    this.appendDummyInput().appendField('🟢 FORWARD  L');
    this.appendValueInput('SPDL').setCheck('Number');
    this.appendDummyInput().appendField('R');
    this.appendValueInput('SPDR').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(0);
    this.setTooltip('เดินหน้า ซ้าย/ขวาอิสระ\nfd2(speedL, speedR)');
  }
};

Blockly.Blocks['motor_backward'] = {
  init: function() {
    this.appendDummyInput().appendField('🔴 BACKWARD  L');
    this.appendValueInput('SPDL').setCheck('Number');
    this.appendDummyInput().appendField('R');
    this.appendValueInput('SPDR').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(0);
    this.setTooltip('ถอยหลัง ซ้าย/ขวาอิสระ\nbk(speedL, speedR)');
  }
};

Blockly.Blocks['robot_move'] = {
  init: function() {

    this.appendDummyInput()
        .appendField("move")

        .appendField(
          new Blockly.FieldDropdown([
            ["Spin Right", "SR"],
            ["Spin Left", "SL"],
            ["Turn Right", "TR"],
            ["Turn Left", "TL"]
          ]),
          "DIR"
        )

        .appendField("speed");

    this.appendValueInput("SPD")
        .setCheck("Number");

    this.setPreviousStatement(true);

    this.setNextStatement(true);

    this.setColour(0);        //"#2563eb"
  }
};

//--------------------------------------OLED---------------------------------------------

Blockly.Blocks['oled_show'] = {
  init: function() {

    this.appendValueInput("VALUE")
        .setCheck(null)
        .appendField("OLED");

    this.appendDummyInput()
        .appendField("line")
        .appendField(
          new Blockly.FieldDropdown([
            ["1","1"],
            ["2","2"],
            ["3","3"],
            ["4","4"],
            ["5","5"],
            ["6","6"]
          ]),
          "LINE"
        );

    this.appendDummyInput()
        .appendField("size")
        .appendField(
          new Blockly.FieldDropdown([
            ["1","1"],
            ["2","2"],
            ["3","3"]
          ]),
          "SIZE"
        );

    this.setInputsInline(true);

    this.setPreviousStatement(true);
    this.setNextStatement(true);

    this.setColour("#2563eb");

    this.setTooltip(
      "แสดงข้อความหรือค่าตัวแปรบน OLED"
    );
  }
};


// ── OLED Clear — ล้างหน้าจอ ──────────────────────────────────
// ต้องเรียกก่อนแสดงผลใหม่ทุกครั้ง
// Generate: oled_clear();
Blockly.Blocks['oled_clear'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED ล้างหน้าจอ');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip(
      'ล้างข้อความทั้งหมดบนจอ OLED\n' +
      '⚠️ ต้องเรียก "OLED แสดงผล" หลังจากนี้\n' +
      'Generate: oled_clear();'
    );
  }
};

// ── OLED Update — สั่งแสดงผลจริงบนจอ ────────────────────────
// Adafruit SSD1306 ต้องเรียก display.display() ทุกครั้ง
// Generate: oled_update();
Blockly.Blocks['oled_update'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED แสดงผล');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#1d4ed8');
    this.setTooltip(
      'สั่งให้จอ OLED แสดงผลจริง\n' +
      '⚠️ ต้องเรียกทุกครั้งหลังจาก OLED ล้างหน้าจอ + OLED บรรทัด\n' +
      'Generate: oled_update();'
    );
  }
};

// ══════════════════════════════════════════════════════
//  OLED Graphic Blocks
// ══════════════════════════════════════════════════════

// ── วาดเส้น ──────────────────────────────────────────
Blockly.Blocks['oled_line'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED วาดเส้น จาก x1');
    this.appendValueInput('X1').setCheck('Number');
    this.appendDummyInput().appendField('y1');
    this.appendValueInput('Y1').setCheck('Number');
    this.appendDummyInput().appendField('ถึง x2');
    this.appendValueInput('X2').setCheck('Number');
    this.appendDummyInput().appendField('y2');
    this.appendValueInput('Y2').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('วาดเส้นตรง จอ 128x64 pixel\nGenerate: oled_line(x1,y1,x2,y2);');
  }
};

// ── วาดสี่เหลี่ยม (กรอบ) ─────────────────────────────
Blockly.Blocks['oled_rect'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED สี่เหลี่ยม x');
    this.appendValueInput('X').setCheck('Number');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y').setCheck('Number');
    this.appendDummyInput().appendField('w');
    this.appendValueInput('W').setCheck('Number');
    this.appendDummyInput().appendField('h');
    this.appendValueInput('H').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('วาดกรอบสี่เหลี่ยม\nGenerate: oled_rect(x,y,w,h);');
  }
};

// ── วาดสี่เหลี่ยมทึบ ─────────────────────────────────
Blockly.Blocks['oled_fill_rect'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED สี่เหลี่ยมทึบ x');
    this.appendValueInput('X').setCheck('Number');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y').setCheck('Number');
    this.appendDummyInput().appendField('w');
    this.appendValueInput('W').setCheck('Number');
    this.appendDummyInput().appendField('h');
    this.appendValueInput('H').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8');
    this.setTooltip('วาดสี่เหลี่ยมทึบ\nGenerate: oled_fill_rect(x,y,w,h);');
  }
};

// ── วาดวงกลม (กรอบ) ──────────────────────────────────
Blockly.Blocks['oled_circle'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED วงกลม กึ่งกลาง x');
    this.appendValueInput('X').setCheck('Number');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y').setCheck('Number');
    this.appendDummyInput().appendField('r');
    this.appendValueInput('R').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('วาดกรอบวงกลม\nGenerate: oled_circle(x,y,r);');
  }
};

// ── วาดวงกลมทึบ ──────────────────────────────────────
Blockly.Blocks['oled_fill_circle'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED วงกลมทึบ กึ่งกลาง x');
    this.appendValueInput('X').setCheck('Number');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y').setCheck('Number');
    this.appendDummyInput().appendField('r');
    this.appendValueInput('R').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8');
    this.setTooltip('วาดวงกลมทึบ\nGenerate: oled_fill_circle(x,y,r);');
  }
};

// ── พิมพ์ที่ตำแหน่ง X,Y ──────────────────────────────
Blockly.Blocks['oled_xy'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED พิมพ์ที่ x');
    this.appendValueInput('X').setCheck('Number');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y').setCheck('Number');
    this.appendDummyInput()
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2'],['3','3']]), 'SIZE');
    this.appendValueInput('VALUE');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('พิมพ์ที่ตำแหน่ง pixel (x,y) ควบคุมได้แม่นยำ\nGenerate: oled_xy(x,y,value,size);');
  }
};

// ── กลับสี ────────────────────────────────────────────
Blockly.Blocks['oled_invert'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED กลับสี')
        .appendField(new Blockly.FieldDropdown([['เปิด','true'],['ปิด','false']]), 'INVERT');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('กลับสีจอ: พื้นขาว-อักษรดำ / พื้นดำ-อักษรขาว\nGenerate: oled_invert(true/false);');
  }
};

// ── หรี่แสง ───────────────────────────────────────────
Blockly.Blocks['oled_dim'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED ความสว่าง')
        .appendField(new Blockly.FieldDropdown([['หรี่','true'],['สว่าง','false']]), 'DIM');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('ปรับความสว่างจอ\nGenerate: oled_dim(true/false);');
  }
};

// ── Progress Bar ──────────────────────────────────────
Blockly.Blocks['oled_progress'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED progress bar x');
    this.appendValueInput('X').setCheck('Number');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y').setCheck('Number');
    this.appendDummyInput().appendField('w');
    this.appendValueInput('W').setCheck('Number');
    this.appendDummyInput().appendField('h');
    this.appendValueInput('H').setCheck('Number');
    this.appendValueInput('VALUE').appendField('%');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#059669');
    this.setTooltip('แถบความคืบหน้า 0-100%\nGenerate: oled_progress(x,y,w,h,value);');
  }
};

// ══════════════════════════════════════════════════════════════
//  MCP3008 / MCP3208 — ADC Blocks
// ══════════════════════════════════════════════════════════════

// ── อ่านค่า ADC (คืน int) ────────────────────────────────────
Blockly.Blocks['adc_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('อ่าน ADC')
        .appendField(
          new Blockly.FieldDropdown([
            ['MCP3208 (12-bit)', '3208'],
            ['MCP3008 (10-bit)', '3008']
          ]),
          'CHIP'
        )
        .appendField('channel')
        .appendField(
          new Blockly.FieldDropdown([
            ['0','0'],['1','1'],['2','2'],['3','3'],
            ['4','4'],['5','5'],['6','6'],['7','7']
          ]),
          'CH'
        );
    this.setOutput(true, 'Number');
    this.setColour('#0891b2');
    this.setTooltip(
      'อ่านค่า ADC จาก MCP3008 (0–1023) หรือ MCP3208 (0–4095)\n' +
      'channel 0–7'
    );
  }
};

// ── อ่านแรงดัน ADC (คืน float V) ─────────────────────────────
Blockly.Blocks['adc_voltage'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('แรงดัน ADC')
        .appendField(
          new Blockly.FieldDropdown([
            ['MCP3208 (12-bit)', '3208'],
            ['MCP3008 (10-bit)', '3008']
          ]),
          'CHIP'
        )
        .appendField('channel')
        .appendField(
          new Blockly.FieldDropdown([
            ['0','0'],['1','1'],['2','2'],['3','3'],
            ['4','4'],['5','5'],['6','6'],['7','7']
          ]),
          'CH'
        )
        .appendField('V');
    this.setOutput(true, 'Number');
    this.setColour('#0e7490');
    this.setTooltip(
      'อ่านแรงดัน ADC เป็น float (0.0–3.3V)\n' +
      'channel 0–7'
    );
  }
};

// ── ชดเชยแรงดันแบต (เลือกเปิด/ปิดได้) ────────────────────────
Blockly.Blocks['motor_volt_comp'] = {
  init: function() {
    this.appendDummyInput().appendField('เปิดชดเชยแรงดันแบต อ้างอิง');
    this.appendValueInput('VREF').setCheck('Number');
    this.appendDummyInput().appendField('V');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#c2410c');
    this.setTooltip(
      'ทำให้มอเตอร์รู้สึกเหมือนใช้ไฟคงที่ตามค่าที่ตั้ง\n' +
      'แบตเต็ม → ลด PWM ลง / แบตลด → เพิ่ม PWM ชดเชย\n' +
      'แนะนำ 7.0V (แบต 2S) เพื่อชดเชยได้เกือบเต็มช่วง\n' +
      'ไม่วางบล็อกนี้ = โหมดปกติ\n' +
      'ตั้งครั้งเดียวใน Setup → setMotorVoltage(vref);'
    );
  }
};

// ── อ่านแรงดันแบต (คืน float V) ──────────────────────────────
Blockly.Blocks['batt_voltage'] = {
  init: function() {
    this.appendDummyInput().appendField('แรงดันแบต (V)');
    this.setOutput(true, 'Number');
    this.setColour('#0e7490');
    this.setTooltip(
      'อ่านแรงดันแบตเตอรี่เป็น float (ผ่าน GP28/ADC2)\n' +
      'ใช้โชว์บน OLED หรือเช็คแบตอ่อนได้\n' +
      'Generate: battVoltage()'
    );
  }
};

// ══════════════════════════════════════════════════════════════
//  IMU / BNO055 Blocks
// ══════════════════════════════════════════════════════════════

// ── เลือกชนิด IMU (ใส่ใน Setup ก่อนคาลิเบรต) ─────────────────
Blockly.Blocks['imu_select'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🧭 เลือก IMU')
        .appendField(
          new Blockly.FieldDropdown([
            ['BNO055',          'IMU_BNO055'],
            ['BNO055 + เข็มทิศ', 'IMU_BNO055_MAG'],
            ['BNO055 ZUPT',     'IMU_BNO055_ZUPT'],
            ['MPU6050',         'IMU_MPU6050'],
            ['GY-91 (MPU9250)', 'IMU_GY91'],
            ['BNO085',          'IMU_BNO085'],
            ['BNO085 + เข็มทิศ', 'IMU_BNO085_MAG'],
            ['ICM-20948',       'IMU_ICM20948']
          ]),
          'IMU'
        );
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip(
      'เลือกเซนเซอร์ IMU ที่จะใช้\n' +
      'วางไว้บนสุดของ Setup ก่อนบล็อก "IMU คาริเบต"\n' +
      'ถ้าไม่ใส่บล็อกนี้ = ใช้ BNO055 (ค่าเริ่มต้น)\n' +
      'Generate: setIMU(IMU_xxx);'
    );
  }
};

// ── อ่านมุมปัจจุบัน ──────────────────────────────────────────
Blockly.Blocks['imu_get_yaw'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🧭 มุมปัจจุบัน');
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed');
    this.setTooltip(
      'อ่านมุม yaw ปัจจุบัน 0–360°\n' +
      'รวม offset จาก resetYaw / calibrateYawStart\n' +
      'Generate: getYaw()'
    );
  }
};

Blockly.Blocks['imu_get_yaw_raw'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🧭 มุมดิบ (raw)');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip(
      'อ่านมุม yaw ดิบจาก BNO055 ไม่มี offset\n' +
      'Generate: getYawRaw()'
    );
  }
};

// ── IMU คาริเบตทิศครั้งแรก ───────────────────────────────────
Blockly.Blocks['imu_calibrate'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔧 IMU คาริเบตทิศครั้งแรก');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip(
      'เริ่มต้น BNO055 และตั้งทิศหน้า = 0°\n' +
      'ใช้ใน Setup เท่านั้น\n' +
      'Generate: initIMU(); calibrateYawStart();'
    );
  }
};

// ── รีเซตทิศ ─────────────────────────────────────────────────
Blockly.Blocks['imu_reset_yaw'] = {
  init: function() {
    this.appendDummyInput().appendField('🔄 รีเซตทิศ  จำนวนรอบ');
    this.appendValueInput('SAMPLES').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip(
      'รีเซตทิศปัจจุบัน = 0°\n' +
      'รอบ=1 → ไวสุด ไม่ delay\n' +
      'รอบ=10 → เฉลี่ย ~20ms (แนะนำ)\n' +
      'รอบ=20 → แม่นสุด ~40ms\n' +
      'Generate: resetYaw(samples);'
    );
  }
};

// ── จูน Scale gyro (เฉพาะ ICM-20948) — block เดียว หมุนแล้วกดปุ่ม Go ──
Blockly.Blocks['imu_scale_cal'] = {
  init: function() {
    this.appendDummyInput().appendField('📐 จูน Scale (ICM20948)  จำนวนรอบ');
    this.appendValueInput('TURNS').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip(
      'จูน scale-factor ของ gyro (เฉพาะ ICM-20948) — บล็อกเดียวจบ:\n' +
      '① บี๊บ → ② หมุนหุ่นด้วยมือ N รอบเต็มกลับจุดเดิม → ③ กดปุ่ม Go (pin10) → ④ บี๊บ 2 ครั้ง เก็บ EEPROM\n' +
      'จูนครั้งเดียวพอ (ค่าอยู่ถาวร) — วางชั่วคราวแล้วเอาออก ไม่งั้นจะรอปุ่มทุกครั้งเปิดเครื่อง\n' +
      'Generate: icm_scaleCalibrate(turns);'
    );
  }
};

// ══════════════════════════════════════════════════════════════
//  IMU ไม่มี PID — Smooth (Proportional Remaining Angle)
// ══════════════════════════════════════════════════════════════

// ── หมุน หน้า=0° (dropdown) ──────────────────────────────────
// ── หมุน smooth (dropdown ทิศ + dropdown หน้า/หลัง) ─────────────
Blockly.Blocks['imu_spin_dir'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔄 หมุน')
        .appendField(new Blockly.FieldDropdown([
          ['หน้า', 'F'],
          ['หลัง', 'B']
        ]), 'DIR')
        .appendField('  ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('เร็วสุด');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('ช้าสุด');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('หยุดที่');
    this.appendValueInput('THR') .setCheck('Number');
    this.appendDummyInput().appendField('°  timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('หมุนในที่ ไม่มี PID — เลือก หน้า/หลัง และทิศด้วยลูกศร\nGenerate: spinTo_F / spinTo_B(yaw, max, min, threshold, timeout);');
  }
};

// ── หมุน smooth (ตัวแปร + dropdown หน้า/หลัง) ────────────────
Blockly.Blocks['imu_spin_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔄 หมุน')
        .appendField(new Blockly.FieldDropdown([
          ['หน้า', 'F'],
          ['หลัง', 'B']
        ]), 'DIR')
        .appendField('  ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('เร็วสุด');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('ช้าสุด');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('หยุดที่');
    this.appendValueInput('THR') .setCheck('Number');
    this.appendDummyInput().appendField('°  timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('หมุนในที่ ไม่มี PID — พิมพ์องศาเอง เลือก หน้า/หลัง\nGenerate: spinTo_F / spinTo_B(yaw, max, min, threshold, timeout);');
  }
};

// ── ดิฟหน้า smooth (dropdown) ────────────────────────────────
// ── ดิฟ smooth (dropdown ทิศ + dropdown หน้า/หลัง) ─────────────
Blockly.Blocks['imu_turns_dir'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('↩↪ ดิฟ')
        .appendField(new Blockly.FieldDropdown([
          ['หน้า', 'F'],
          ['หลัง', 'B']
        ]), 'DIR')
        .appendField('  ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('เร็วสุด');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('ช้าสุด');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('หยุดที่');
    this.appendValueInput('THR') .setCheck('Number');
    this.appendDummyInput().appendField('°  timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0d9488');
    this.setTooltip('ดิฟ ไม่มี PID — เลือก หน้า/หลัง และทิศด้วยลูกศร\nGenerate: TurnF_S / TurnB_S(yaw, max, min, threshold, timeout);');
  }
};

// ── ดิฟ smooth (ตัวแปร + dropdown หน้า/หลัง) ──────────────────
Blockly.Blocks['imu_turns_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('↩↪ ดิฟ')
        .appendField(new Blockly.FieldDropdown([
          ['หน้า', 'F'],
          ['หลัง', 'B']
        ]), 'DIR')
        .appendField('  ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('เร็วสุด');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('ช้าสุด');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('หยุดที่');
    this.appendValueInput('THR') .setCheck('Number');
    this.appendDummyInput().appendField('°  timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0f766e');
    this.setTooltip('ดิฟ ไม่มี PID — พิมพ์องศาเอง เลือก หน้า/หลัง\nGenerate: TurnF_S / TurnB_S(yaw, max, min, threshold, timeout);');
  }
};



// ── MOVE — เดินหน้า/ถอยหลัง PID ─────────────────────────────
Blockly.Blocks['imu_move'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🚀 MOVE')
        .appendField(new Blockly.FieldDropdown([
          ['เดินหน้า', '0'],
          ['ถอยหลัง', '1']
        ]), 'DIR')
        .appendField('ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('KI');
    this.appendValueInput('KI').setCheck('Number');
    this.appendDummyInput().appendField('KD');
    this.appendValueInput('KD').setCheck('Number');
    this.appendDummyInput().appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#d97706');
    this.setTooltip(
      'เดินหน้า/ถอยหลัง PID ยึดทิศ World Frame\n' +
      'ความเร็วต้น → ความเร็วเริ่มต้นตอนออกตัว (default=30)\n' +
      'เร่ง=0 → ออกตัวที่ความเร็วต้นเลย\n' +
      'ชะลอ=0 → หยุดทันที\n' +
      'Generate: MOVE(dir, yaw, speed, time, kp, ki, kd, rampUp, rampDown, startSpeed);'
    );
  }
};

// ── MOVE (พิมพ์องศาเอง / เสียบตัวแปรได้) ────────────────────
Blockly.Blocks['imu_move_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🚀 MOVE')
        .appendField(new Blockly.FieldDropdown([
          ['เดินหน้า', '0'],
          ['ถอยหลัง', '1']
        ]), 'DIR')
        .appendField('ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('°  ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('KI');
    this.appendValueInput('KI').setCheck('Number');
    this.appendDummyInput().appendField('KD');
    this.appendValueInput('KD').setCheck('Number');
    this.appendDummyInput().appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#d97706');
    this.setTooltip(
      'เดินหน้า/ถอยหลัง PID ยึดทิศ — พิมพ์องศาเองหรือเสียบตัวแปร\n' +
      'Generate: MOVE(dir, yaw, speed, time, kp, ki, kd, rampUp, rampDown, startSpeed);'
    );
  }
};

// ── ตั้งค่า spinTo ────────────────────────────────────────────
Blockly.Blocks['imu_spin_config'] = {
  init: function() {
    this.appendDummyInput().appendField('⚙️ ตั้งค่า spinTo  kp_fast');
    this.appendValueInput('KP_FAST').setCheck('Number');
    this.appendDummyInput().appendField('kp_mid');
    this.appendValueInput('KP_MID').setCheck('Number');
    this.appendDummyInput().appendField('kp_slow');
    this.appendValueInput('KP_SLOW').setCheck('Number');
    this.appendDummyInput().appendField('kd');
    this.appendValueInput('KD').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('ตั้งค่า spinTo ครั้งเดียวใน Setup\nGenerate: setSpinConfig(kp_fast, kp_mid, kp_slow, kd);');
  }
};

// ── spinTo (dropdown ลูกศร) ───────────────────────────────────
Blockly.Blocks['imu_spin_to_dir'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎯 spinTo  ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('error');
    this.appendValueInput('ERR').setCheck('Number');
    this.appendDummyInput().appendField('timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms  min');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('max');
    this.appendValueInput('SMAX').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('เลี้ยวแม่นสุด — ดีดกลับได้\nGenerate: spinTo(yaw, error, timeout, min, max);');
  }
};

// ── spinTo (พิมพ์องศาเอง) ─────────────────────────────────────
Blockly.Blocks['imu_spin_to_num'] = {
  init: function() {
    this.appendDummyInput().appendField('🎯 spinTo  ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('error');
    this.appendValueInput('ERR').setCheck('Number');
    this.appendDummyInput().appendField('timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms  min');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('max');
    this.appendValueInput('SMAX').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('เลี้ยวแม่นสุด — พิมพ์องศาเอง\nGenerate: spinTo(yaw, error, timeout, min, max);');
  }
};


// ══════════════════════════════════════════════════════════════
//  Servo Blocks
// ══════════════════════════════════════════════════════════════

// ── servo — หมุนนุ่ม ─────────────────────────────────────────
Blockly.Blocks['servo_move'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🦾 Servo  pin')
        .appendField(new Blockly.FieldDropdown([
          ['4','4'],['5','5'],['6','6'],['7','7'],['8','8']
        ]), 'PIN')
        .appendField('มุม');
    this.appendValueInput('ANGLE').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPEED').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0369a1');
    this.setTooltip(
      'หมุน servo นุ่มๆ\n' +
      'speed: หน่วง ms ต่อ 1° (1=เร็ว, 20=ช้า)\n' +
      'Generate: servo(pin, angle, speed);'
    );
  }
};

// ── servoFast — ยิงทันที ──────────────────────────────────────
Blockly.Blocks['servo_fast'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚡ ServoFast  pin')
        .appendField(new Blockly.FieldDropdown([
          ['4','4'],['5','5'],['6','6'],['7','7'],['8','8']
        ]), 'PIN')
        .appendField('มุม');
    this.appendValueInput('ANGLE').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0284c7');
    this.setTooltip(
      'ยิง servo ทันที ไม่ไล่มุม\n' +
      'Generate: servoFast(pin, angle);'
    );
  }
};

// ══════════════════════════════════════════════════════════════
//  Line Sensor Blocks
// ══════════════════════════════════════════════════════════════

// ── Auto Calibrate ────────────────────────────────────────────
Blockly.Blocks['line_calibrate'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎯 Calibrate Sensor')
        .appendField(new Blockly.FieldDropdown([
          ['MCP3208 (12-bit)', '12'],
          ['MCP3008 (10-bit)', '8']
        ]), 'CHIP')
        .appendField('เวลา');
    this.appendValueInput('DUR').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip(
      'Scan หาค่ากลาง sensor ทั้ง 8 ch\n' +
      'แสดงผล realtime บน OLED\n' +
      'บันทึกลง EEPROM อัตโนมัติ\n' +
      'Generate: autoScanSensor(chip, ms);'
    );
  }
};

// ── Load Calibration ──────────────────────────────────────────
Blockly.Blocks['line_load_cal'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📂 โหลด calibration Sensor');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip(
      'โหลดค่ากลาง sensor จาก EEPROM\n' +
      'ใช้ใน Setup ก่อนใช้งาน sensor\n' +
      'Generate: loadCalibration();'
    );
  }
};

// ── Get Ref Value ─────────────────────────────────────────────
Blockly.Blocks['line_get_ref'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📊 ref sensor')
        .appendField(new Blockly.FieldDropdown([
          ['A0','0'],['A1','1'],['A2','2'],['A3','3'],
          ['A4','4'],['A5','5'],['A6','6'],['A7','7']
        ]), 'CH');
    this.setOutput(true, 'Number');
    this.setColour('#92400e');
    this.setTooltip(
      'อ่านค่ากลาง (threshold) ของ sensor\n' +
      'ใช้เทียบกับค่าดิบจาก ADC\n' +
      'Generate: getRef(ch);'
    );
  }
};

// ══════════════════════════════════════════════════════════════
//  Line Sensor — อ่านค่า + ตำแหน่ง
// ══════════════════════════════════════════════════════════════

if (typeof _LINE_CH_OPT === 'undefined') {
  var _LINE_CH_OPT   = [['A0','0'],['A1','1'],['A2','2'],['A3','3'],
                        ['A4','4'],['A5','5'],['A6','6'],['A7','7']];
  var _LINE_TYPE_OPT = [['ดำ/พื้นขาว','0'],['ขาว/พื้นดำ','1']];
  var _LINE_ROW_OPT  = [['0','0'],['1','1'],['2','2'],['3','3'],['4','4'],['5','5']];
}

// ── เจอเส้น ───────────────────────────────────────────────────
Blockly.Blocks['line_on_line'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔍 เจอเส้น')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'CH')
        .appendField(new Blockly.FieldDropdown(_LINE_TYPE_OPT), 'TYPE');
    this.setOutput(true, 'Boolean');
    this.setColour('#92400e');
    this.setTooltip('คืน true ถ้า sensor เจอเส้น\nGenerate: sensorOnLine(ch, type);');
  }
};

// ── นับ sensor ────────────────────────────────────────────────
Blockly.Blocks['line_count'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔢 นับ sensor จาก')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'FROM')
        .appendField('ถึง')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'TO')
        .appendField(new Blockly.FieldDropdown(_LINE_TYPE_OPT), 'TYPE');
    this.setOutput(true, 'Number');
    this.setColour('#92400e');
    this.setTooltip('คืนจำนวน sensor ที่เจอเส้น (0-8)\nGenerate: countSensors(from, to, type);');
  }
};

// ── แสดง sensor OLED ──────────────────────────────────────────
Blockly.Blocks['line_show'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥️ แสดง sensor จาก')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'FROM')
        .appendField('ถึง')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'TO')
        .appendField('บรรทัด')
        .appendField(new Blockly.FieldDropdown(_LINE_ROW_OPT), 'ROW')
        .appendField(new Blockly.FieldDropdown(_LINE_TYPE_OPT), 'TYPE');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#92400e');
    this.setTooltip('แสดง ●○ บน OLED\nGenerate: showSensors(from, to, row, type);');
  }
};

// ── ตำแหน่งเส้น ───────────────────────────────────────────────
Blockly.Blocks['line_position'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📍 ตำแหน่งเส้น จาก')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'FROM')
        .appendField('ถึง')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'TO')
        .appendField(new Blockly.FieldDropdown(_LINE_TYPE_OPT), 'TYPE');
    this.setOutput(true, 'Number');
    this.setColour('#78350f');
    this.setTooltip('คืนตำแหน่งเส้น -100 ถึง +100\n0=กลาง  <0=ซ้าย  >0=ขวา\nGenerate: linePosition(from, to, type);');
  }
};

// ── ตั้งค่าเซนเซอร์หน้า (ใส่ใน Setup) ─────────────────────────
Blockly.Blocks['line_setup_front'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ตั้งค่าเซนเซอร์หน้า  สี')
        .appendField(new Blockly.FieldDropdown(_LINE_TYPE_OPT), 'TYPE')
        .appendField('ชุด A')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'FROM')
        .appendField('-A')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'TO');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#1d4ed8');
    this.setTooltip(
      'ตั้งค่าเซนเซอร์ชุดหน้า — ใส่ใน Setup ครั้งเดียว\n' +
      'ชุด = ช่วงเซนเซอร์หน้า (A0-A7=8ตัว, A0-A3=4ตัวหน้า)\n' +
      'ใช้คู่กับบล็อก "ตามเส้น PID หน้า"\n' +
      'Generate: setupLineFront(from, to, type);'
    );
  }
};

// ── ตั้งค่าเซนเซอร์หลัง (ใส่ใน Setup) ─────────────────────────
Blockly.Blocks['line_setup_back'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ตั้งค่าเซนเซอร์หลัง  สี')
        .appendField(new Blockly.FieldDropdown(_LINE_TYPE_OPT), 'TYPE')
        .appendField('ชุด A')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'FROM')
        .appendField('-A')
        .appendField(new Blockly.FieldDropdown(_LINE_CH_OPT), 'TO')
        .appendField('ถอยกลับทิศ')
        .appendField(new Blockly.FieldDropdown([['ปกติ','0'],['กลับซ้าย-ขวา','1']]), 'BFLIP');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#1e40af');
    this.setTooltip(
      'ตั้งค่าเซนเซอร์ชุดหลัง — ใส่ใน Setup ครั้งเดียว\n' +
      'ชุด = ช่วงเซนเซอร์หลัง (เช่น A4-A7)\n' +
      'ถอยกลับทิศ = ถ้าถอยแล้วแก้เส้นผิดทาง เลือก "กลับซ้าย-ขวา"\n' +
      'ใช้คู่กับบล็อก "ตามเส้น PID หลัง"\n' +
      'Generate: setupLineBack(from, to, type, backFlip);'
    );
  }
};

// ── ตามเส้น PID หน้า (1 รอบ — ใส่ใน loop เอง) ─────────────────
Blockly.Blocks['line_pid_front'] = {
  init: function() {
    this.appendDummyInput().appendField('ตามเส้น PID หน้า  speed');
    this.appendValueInput('SPEED').setCheck('Number');
    this.appendDummyInput().appendField('KP');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('KD');
    this.appendValueInput('KD').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip(
      'เดินหน้าตามเส้น PID 1 รอบ — ใส่ใน forever/loop เอง\n' +
      'ใช้เซนเซอร์ชุดหน้า + สีเส้น ที่ตั้งใน "ตั้งค่าเซนเซอร์ตามเส้น"\n' +
      'หลุดเส้นให้เช็ค "นับเซนเซอร์ = 0" แล้ว break เอง\n' +
      'Generate: linePID_front(speed, kp, kd);'
    );
  }
};

// ── ตามเส้น PID หลัง (ถอยหลัง 1 รอบ) ──────────────────────────
Blockly.Blocks['line_pid_back'] = {
  init: function() {
    this.appendDummyInput().appendField('ตามเส้น PID หลัง  speed');
    this.appendValueInput('SPEED').setCheck('Number');
    this.appendDummyInput().appendField('KP');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('KD');
    this.appendValueInput('KD').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#92400e');
    this.setTooltip(
      'ถอยหลังตามเส้น PID 1 รอบ — ใส่ใน forever/loop เอง\n' +
      'ใช้เซนเซอร์ชุดหลัง + สีเส้น ที่ตั้งใน "ตั้งค่าเซนเซอร์ตามเส้น"\n' +
      'ถ้าแก้เส้นผิดทาง → ตั้ง "ถอยกลับทิศ = กลับซ้าย-ขวา" ในบล็อกตั้งค่า\n' +
      'Generate: linePID_back(speed, kp, kd);'
    );
  }
};

// ══════════════════════════════════════════════════════════════
//  LINE_MOVE — ตามเส้น + ไจโรช่วย ในบล็อกเดียว (ผสม PID 2 ชุด)
// ══════════════════════════════════════════════════════════════

// ── ทิศแบบลูกศร ───────────────────────────────────────────────
Blockly.Blocks['line_move'] = {
  init: function() {
    var _YAW = [['↑','0'],['→','90'],['↓','180'],['←','270'],
                ['↗','45'],['↘','135'],['↙','225'],['↖','315']];
    this.appendDummyInput()
        .appendField('ตามเส้น+ไจโร')
        .appendField(new Blockly.FieldDropdown([
          ['เดินหน้า', '0'],
          ['ถอยหลัง', '1']
        ]), 'DIR')
        .appendField('ทิศ')
        .appendField(new Blockly.FieldDropdown(_YAW), 'YAW')
        .appendField('ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP เส้น');
    this.appendValueInput('KPLINE').setCheck('Number');
    this.appendDummyInput().appendField('KD เส้น');
    this.appendValueInput('KDLINE').setCheck('Number');
    this.appendDummyInput().appendField('KP ไจโร');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KD ไจโร');
    this.appendValueInput('KDYAW').setCheck('Number');
    this.appendDummyInput().appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#d97706');
    this.setTooltip(
      'เดินตามเส้น + ไจโรยึดทิศ ในฟังก์ชันเดียว (ผสม PID 2 ชุด)\n' +
      'ใช้เซนเซอร์หน้า/หลัง + สี ที่ตั้งใน "ตั้งค่าเซนเซอร์" (Setup)\n' +
      'KP/KD เส้น = คุมตามเส้น (error ตำแหน่ง -100..+100)\n' +
      'KP/KD ไจโร = ยึดทิศไม่ให้เป๋ (error องศา) — ทางโค้งให้ลด KP ไจโร\n' +
      'หลุดเส้น: เส้น error=0 ไจโรพาตรงไปต่อจนเจอเส้นใหม่\n' +
      'เร่ง=0 ออกตัวเลย, ชะลอ=0 หยุดทันที\n' +
      'Generate: LINE_MOVE(dir, yaw, speed, time, kpLine, kdLine, kpYaw, kdYaw, rampUp, rampDown, startSpeed);'
    );
  }
};

// ── ทิศพิมพ์องศาเอง / เสียบตัวแปร ─────────────────────────────
Blockly.Blocks['line_move_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ตามเส้น+ไจโร')
        .appendField(new Blockly.FieldDropdown([
          ['เดินหน้า', '0'],
          ['ถอยหลัง', '1']
        ]), 'DIR')
        .appendField('ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('°  ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP เส้น');
    this.appendValueInput('KPLINE').setCheck('Number');
    this.appendDummyInput().appendField('KD เส้น');
    this.appendValueInput('KDLINE').setCheck('Number');
    this.appendDummyInput().appendField('KP ไจโร');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KD ไจโร');
    this.appendValueInput('KDYAW').setCheck('Number');
    this.appendDummyInput().appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#d97706');
    this.setTooltip(
      'เดินตามเส้น + ไจโรยึดทิศ — พิมพ์องศาเองหรือเสียบตัวแปร\n' +
      'KP/KD เส้น คุมตามเส้น, KP/KD ไจโร ยึดทิศ (ทางโค้งลด KP ไจโร)\n' +
      'Generate: LINE_MOVE(dir, yaw, speed, time, kpLine, kdLine, kpYaw, kdYaw, rampUp, rampDown, startSpeed);'
    );
  }
};

// ══════════════════════════════════════════════════════════════
//  Ultrasonic Block
// ══════════════════════════════════════════════════════════════

Blockly.Blocks['ultrasonic_read'] = {
  init: function() {
    const _PINS = [['4','4'],['5','5'],['6','6'],['7','7'],['8','8'],['10','10']];
    this.appendDummyInput()
        .appendField('📏 วัดระยะ  TRIG')
        .appendField(new Blockly.FieldDropdown(_PINS), 'TRIG')
        .appendField('ECHO')
        .appendField(new Blockly.FieldDropdown(_PINS), 'ECHO');
    this.setOutput(true, 'Number');
    this.setColour('#0369a1');
    this.setTooltip(
      'วัดระยะด้วย HC-SR04\n' +
      'คืนค่า cm (float)\n' +
      'คืน -1 ถ้าไม่มีสัญญาณ (ไกลเกิน ~500cm)\n' +
      'Generate: sonarRead(trig, echo);'
    );
  }
};


// ── MOVE_LOOP_RESET ──────────────────────────────────────
Blockly.Blocks['imu_move_loop_reset'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔁 MOVE_LOOP reset');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#be185d');
    this.setTooltip('reset state ก่อนเริ่ม loop\nเรียกแค่ครั้งเดียวก่อน while\nGenerate: MOVE_LOOP_RESET();');
  }
};

// ── MOVE_LOOP ────────────────────────────────────────────
Blockly.Blocks['imu_move_loop'] = {
  init: function() {
    const _YAW = [['↑','0'],['→','90'],['↓','180'],['←','270'],
                  ['↗','45'],['↘','135'],['↙','225'],['↖','315']];
    this.appendDummyInput()
        .appendField('🚗 MOVE_LOOP')
        .appendField(new Blockly.FieldDropdown([
          ['เดินหน้า','0'],['ถอยหลัง','1']
        ]), 'DIR')
        .appendField('ทิศ')
        .appendField(new Blockly.FieldDropdown(_YAW), 'YAW')
        .appendField('ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('KP_yaw');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KD_yaw');
    this.appendValueInput('KDYAW').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#be185d');
    this.setTooltip(
      'BNO055 อย่างเดียว — เดิน 1 cycle (~4ms)\n' +
      'ไม่มี duration — วิ่งจนกว่าจะ break\n' +
      'KD_yaw=0 = P-only (ค่า default ปลอดภัย)\n' +
      'Generate: MOVE_LOOP(dir, yaw, speed, kp, kd, startSpeed);'
    );
  }
};

// ── MOVE_LOOP (พิมพ์องศาเอง / เสียบตัวแปรได้) ────────────────
Blockly.Blocks['imu_move_loop_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🚗 MOVE_LOOP')
        .appendField(new Blockly.FieldDropdown([
          ['เดินหน้า','0'],['ถอยหลัง','1']
        ]), 'DIR')
        .appendField('ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('°  ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('KP_yaw');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KD_yaw');
    this.appendValueInput('KDYAW').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#be185d');
    this.setTooltip(
      'BNO055 อย่างเดียว — เดิน 1 cycle (~4ms)\n' +
      'ทิศ: พิมพ์องศาเองหรือเสียบตัวแปรได้\n' +
      'KD_yaw=0 = P-only (ค่า default ปลอดภัย)\n' +
      'Generate: MOVE_LOOP(dir, yaw, speed, kp, kd, startSpeed);'
    );
  }
};

// ── setMotorOffset ────────────────────────────────────────────
Blockly.Blocks['motor_scale'] = {
  init: function() {
    this.appendDummyInput().appendField('⚙️ Motor Offset  ซ้าย');
    this.appendValueInput('SCALEL').setCheck('Number');
    this.appendDummyInput().appendField('ขวา');
    this.appendValueInput('SCALER').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#c2410c');
    this.setTooltip(
      'ชดเชยมอเตอร์ซ้าย/ขวาไม่เท่ากัน\n' +
      '+3 = เพิ่ม 3  (ถ้าช้ากว่า)\n' +
      '-3 = ลด 3    (ถ้าเร็วกว่า)\n' +
      'ตั้งครั้งเดียวใน Setup → ใช้ได้ทุกฟังก์ชัน\n' +
      'Generate: setMotorOffset(offsetL, offsetR);'
    );
  }
};

// ══════════════════════════════════════════════════════════════
//  Robot Menu — เมนูเลือกโปรแกรม ปุ่มเดียว (SW10)
//  Mutator: คลิก ⚙️ เพื่อเพิ่ม/ลบรายการ (2-8 รายการ)
// ══════════════════════════════════════════════════════════════

// ── Popup container (ใน mutator workspace) ──────────────────
Blockly.Blocks['robot_menu_container'] = {
  init: function() {
    this.appendDummyInput().appendField('📋 Robot Menu');
    this.appendStatementInput('STACK');
    this.setColour('#7c3aed');
    this.setTooltip('ลาก "รายการ" เข้า-ออก เพื่อเพิ่ม/ลบ (2-8 รายการ)');
    this.contextMenu = false;
  }
};

// ── Popup item block ─────────────────────────────────────────
Blockly.Blocks['robot_menu_item'] = {
  init: function() {
    this.appendDummyInput().appendField('  📌 รายการ');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('รายการในเมนู — ลากออกเพื่อลบ');
    this.contextMenu = false;
  }
};

// ── Main block ───────────────────────────────────────────────
Blockly.Blocks['robot_menu'] = {
  itemCount_: 4,

  init: function() {
    this.appendDummyInput('TITLE')
        .appendField('📋 Robot Menu')
        .appendField('   กด=เลือก  ค้าง=ถัดไป');
    this.updateShape_();
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour('#7c3aed');
    this.setTooltip(
      'เมนูเลือกโปรแกรมบน OLED ด้วยปุ่มเดียว (SW10)\n' +
      'กดสั้น = เลือก & รัน\n' +
      'กดค้าง ≥ 0.6s = เลื่อนถัดไป (วนกลับ)\n' +
      'OLED scrolling — รองรับสูงสุด 8 รายการ\n' +
      'คลิก ⚙️ เพื่อเพิ่ม/ลบรายการ'
    );
    // รองรับ Blockly v10 (MutatorIcon) และเก่ากว่า (Mutator)
    const MutClass = (Blockly.icons && Blockly.icons.MutatorIcon)
      ? Blockly.icons.MutatorIcon : Blockly.Mutator;
    this.setMutator(new MutClass(['robot_menu_item'], this));
  },

  mutationToDom: function() {
    const el = document.createElement('mutation');
    el.setAttribute('items', this.itemCount_);
    return el;
  },

  domToMutation: function(xmlElement) {
    this.itemCount_ = Math.max(2, Math.min(8,
      parseInt(xmlElement.getAttribute('items'), 10) || 4));
    this.updateShape_();
  },

  decompose: function(workspace) {
    const container = workspace.newBlock('robot_menu_container');
    container.initSvg();
    let conn = container.getInput('STACK').connection;
    for (let i = 0; i < this.itemCount_; i++) {
      const item = workspace.newBlock('robot_menu_item');
      item.initSvg();
      conn.connect(item.previousConnection);
      conn = item.nextConnection;
    }
    return container;
  },

  compose: function(containerBlock) {
    // เก็บ block ปัจจุบันก่อน rebuild
    let itemBlock = containerBlock.getInputTargetBlock('STACK');
    const savedBlocks = [];
    while (itemBlock && !itemBlock.isInsertionMarker()) {
      savedBlocks.push(itemBlock._menuSaved || null);
      itemBlock._menuSaved = null;
      itemBlock = itemBlock.nextConnection && itemBlock.nextConnection.targetBlock();
    }
    // ถอดต่อ input ที่จะถูกลบ
    const newCount = Math.max(2, Math.min(8, savedBlocks.length));
    for (let i = newCount; i < this.itemCount_; i++) {
      const inp = this.getInput('DO' + i);
      if (inp) { const tb = inp.connection.targetBlock(); if (tb) tb.unplug(false); }
    }
    this.itemCount_ = newCount;
    this.updateShape_();
    // ต่อ block กลับ
    for (let i = 0; i < savedBlocks.length; i++) {
      const blk = savedBlocks[i];
      const inp = this.getInput('DO' + i);
      if (blk && inp && blk.workspace && !blk.isDisposed()) {
        try { inp.connection.connect(blk.previousConnection); } catch(e) {}
      }
    }
  },

  saveConnections: function(containerBlock) {
    let itemBlock = containerBlock.getInputTargetBlock('STACK');
    let i = 0;
    while (itemBlock && !itemBlock.isInsertionMarker()) {
      const inp = this.getInput('DO' + i);
      itemBlock._menuSaved = inp && inp.connection.targetBlock();
      i++;
      itemBlock = itemBlock.nextConnection && itemBlock.nextConnection.targetBlock();
    }
  },

  updateShape_: function() {
    // บันทึกชื่อที่มีอยู่ก่อน rebuild
    const savedNames = [];
    let k = 0;
    while (this.getInput('LABEL' + k)) {
      savedNames[k] = this.getFieldValue('NAME' + k) || ('Mode ' + (k + 1));
      k++;
    }
    // ลบ input เก่า
    let i = 0;
    while (this.getInput('LABEL' + i)) {
      this.removeInput('LABEL' + i);
      this.removeInput('DO' + i);
      i++;
    }
    // สร้าง input ใหม่
    for (let j = 0; j < this.itemCount_; j++) {
      const defName = savedNames[j] || ('Mode ' + (j + 1));
      const corner  = j === 0 ? '┌' : (j === this.itemCount_ - 1 ? '└' : '├');
      this.appendDummyInput('LABEL' + j)
          .appendField('  ' + corner + ' รายการ ' + (j + 1) + ' :')
          .appendField(new Blockly.FieldTextInput(defName), 'NAME' + j);
      this.appendStatementInput('DO' + j).setCheck(null);
    }
  }
};

// ══════════════════════════════════════════════════════════════
//  Color Sensor (TCS34725) — อ่านสีพื้น
// ══════════════════════════════════════════════════════════════

if (typeof _COLOR_OPT === 'undefined') {
  // สีมาตรฐานจุดปล่อย: slot 0-5 (value = เลขช่อง)
  var _COLOR_OPT = [
    ['⬜ ขาว','0'], ['🟥 แดง','1'], ['🟩 เขียว','2'],
    ['🟦 น้ำเงิน','3'], ['🟨 เหลือง','4'], ['⬛ ดำ','5']
  ];
  var _COLOR_GAIN_OPT = [
    ['1x','0'], ['4x (แนะนำ)','1'], ['16x','2'], ['60x (พื้นมืด)','3']
  ];
}

// ── เริ่มเซนเซอร์ (ใส่ใน Setup) ───────────────────────────────
Blockly.Blocks['color_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎨 เริ่มเซนเซอร์สี gain')
        .appendField(new Blockly.FieldDropdown(_COLOR_GAIN_OPT), 'GAIN');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0ea5e9');
    this.setTooltip('เริ่มต้น TCS34725 บน Wire1 (GP26/27)\nใส่ใน Setup หลัง razors4()\nGenerate: tcs_begin(0xEB, gain);');
  }
};

// ── สอนสี (วางบนสีจริง แล้วเรียก) ─────────────────────────────
Blockly.Blocks['color_teach'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🧠 สอนสี')
        .appendField(new Blockly.FieldDropdown(_COLOR_OPT), 'COLOR');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0ea5e9');
    this.setTooltip('เก็บค่าสีปัจจุบันเข้าช่องที่เลือก\nวางเซนเซอร์บนสีจริงก่อนเรียก\n' +
                    '⚠ สอน ⬜ ขาว (ช่อง 0) ก่อนเสมอ — ใช้เป็นค่าอ้างอิงแสง (แยกขาว/ดำ)\n' +
                    'Generate: tcs_teach(slot, "NAME");');
  }
};

// ── สีพื้นคือ ... ? (Boolean) ─────────────────────────────────
Blockly.Blocks['color_is'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔍 สีพื้นคือ')
        .appendField(new Blockly.FieldDropdown(_COLOR_OPT), 'COLOR');
    this.setOutput(true, 'Boolean');
    this.setColour('#0284c7');
    this.setTooltip('คืน true ถ้าสีพื้นตรงกับที่เลือก\nGenerate: (tcs_readColor() == slot)');
  }
};

// ── อ่านสี → เลขช่อง (Number, -1=ไม่รู้จัก) ───────────────────
Blockly.Blocks['color_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎯 อ่านสี (เลขช่อง)');
    this.setOutput(true, 'Number');
    this.setColour('#0284c7');
    this.setTooltip('คืนเลขช่องสีที่ใกล้สุด (-1=ไม่รู้จัก)\nGenerate: tcs_readColor()');
  }
};

// ── ชื่อสีที่อ่านได้ (String) ─────────────────────────────────
Blockly.Blocks['color_name'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🏷️ ชื่อสีที่อ่านได้');
    this.setOutput(true, 'String');
    this.setColour('#0284c7');
    this.setTooltip('คืนชื่อสีที่อ่านได้ (ไว้โชว์บน OLED)\nGenerate: tcs_colorName(tcs_readColor())');
  }
};

// ── ค่าดิบ Hue / Sat / Clear (Number, debug) ──────────────────
Blockly.Blocks['color_value'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📊 ค่าสี')
        .appendField(new Blockly.FieldDropdown([
          ['R (แดง 0-255)','tcs_r'],
          ['G (เขียว 0-255)','tcs_g'],
          ['B (น้ำเงิน 0-255)','tcs_b'],
          ['Lux (ความสว่าง)','tcs_lux'],
          ['Hue (สี 0-360)','tcs_hue'],
          ['Sat (ความสด 0-100)','tcs_sat'],
          ['Clear (ความสว่างดิบ)','tcs_clear']
        ]), 'KIND');
    this.setOutput(true, 'Number');
    this.setColour('#0284c7');
    this.setTooltip('อ่านค่าเดี่ยวไว้ทำเงื่อนไขเอง / debug\n' +
                    'R,G,B = 0-255 (สอนขาวก่อน ขาวจะ=255) · Lux=ความสว่าง\n' +
                    'Hue/Sat/Clear = ค่าดิบ HSV');
  }
};

// ── ปรับความเข้มงวด reject (Setup) ────────────────────────────
Blockly.Blocks['color_reject'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚙️ ความเข้มงวดสี');
    this.appendValueInput('D').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0ea5e9');
    this.setTooltip('ระยะตัดสิน "ไม่รู้จักสี" 0.0-2.0 เล็ก=เข้มงวด (เริ่มต้น 0.35)\nGenerate: tcs_setReject(d);');
  }
};


// ── Color Sensor: EEPROM + โหมดสอน/แข่ง ───────────────────────
// ลำดับสอน: ขาว→แดง→เขียว→น้ำเงิน→เหลือง→ดำ (slot 0-5)
// ตัวแรก = ค่า default ของ dropdown → ตั้งเป็น 6 เพื่อให้สอน "ดำ" ด้วย
if (typeof _COLOR_CNT_OPT === 'undefined') {
  var _COLOR_CNT_OPT = [['6 สี (รวมดำ)','6'],['5 สี','5'],['4 สี','4'],['3 สี','3']];
}

// 🎓 สอนสีทั้งชุด + บันทึก (ใช้ในโหมดสอน/ซ้อม)
Blockly.Blocks['color_teach_all'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎓 สอนสีทั้งชุด + บันทึก')
        .appendField(new Blockly.FieldDropdown(_COLOR_CNT_OPT), 'CNT');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('วางเซนเซอร์บนแต่ละสี กด SW10 ทีละสี แล้วบันทึกลง EEPROM\n' +
                    'ลำดับ: ขาว→แดง→เขียว→น้ำเงิน→เหลือง→ดำ (ต้องเริ่มที่ขาวเสมอ)\n' +
                    'Generate: tcs_teachAll(count);');
  }
};

// 💾 บันทึกสีลง EEPROM
Blockly.Blocks['color_save'] = {
  init: function() {
    this.appendDummyInput().appendField('💾 บันทึกสีลง EEPROM');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('บันทึกค่าสีที่สอนไว้ลง EEPROM (ออฟเซ็ต 64 ไม่ชนเซนเซอร์อื่น)\nGenerate: tcs_saveCal();');
  }
};

// 📂 โหลดสีจาก EEPROM
Blockly.Blocks['color_load'] = {
  init: function() {
    this.appendDummyInput().appendField('📂 โหลดสีจาก EEPROM');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('โหลดค่าสีที่บันทึกไว้มาใช้ (ใส่ใน Setup โหมดแข่ง)\nGenerate: tcs_loadCal();');
  }
};

// 💾 มีสีบันทึกใน EEPROM?
Blockly.Blocks['color_has'] = {
  init: function() {
    this.appendDummyInput().appendField('💾 มีสีบันทึกใน EEPROM?');
    this.setOutput(true, 'Boolean');
    this.setColour('#0e7490');
    this.setTooltip('คืน true ถ้าเคยบันทึกสีไว้แล้ว\nGenerate: tcs_hasCal()');
  }
};

// 🔘 กดปุ่มค้างตอนเปิด?
Blockly.Blocks['color_boot_held'] = {
  init: function() {
    this.appendDummyInput().appendField('🔘 กดปุ่มค้างตอนเปิด?');
    this.setOutput(true, 'Boolean');
    this.setColour('#0e7490');
    this.setTooltip('true ถ้ากด SW10 ค้างตอนเปิดเครื่อง (ใช้แยกเข้าโหมดสอนสี)\n' +
                    'คนละจังหวะกับปุ่มเริ่มแข่ง (แตะครั้งเดียวหลังเปิด)\nGenerate: tcs_bootHeld()');
  }
};


// ── Color: บล็อกคาลิเบรตเดียวจบ (สอน+EEPROM / โหลด) ───────────
Blockly.Blocks['color_calibrate'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎓 คาลิเบรตสอนสี + EEPROM')
        .appendField(new Blockly.FieldDropdown(_COLOR_CNT_OPT), 'CNT');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('ใส่ใน Setup (บล็อกเดียวจบ)\n' +
                    '• กดปุ่ม SW10 ค้างตอนเปิด = สอนสีทุกสี + เซฟ EEPROM (ตอนทดสอบสนาม)\n' +
                    '• เปิดเครื่องปกติ = โหลดสีที่เซฟไว้มาใช้ (ตอนแข่ง)\n' +
                    'Generate: tcs_calibrate(count);');
  }
};
