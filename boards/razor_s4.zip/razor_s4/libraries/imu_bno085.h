#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_bno085.h — ตัวอ่านเซนเซอร์ BNO085 (เซนเซอร์ล้วน)
//  ใช้คู่กับ razors4_imu.h | ฟังก์ชันขึ้นต้น bno085_
//
//  ★ ไลบรารี SparkFun BNO08x (เหมาะบอร์ดม่วงจีน)
//  ★ เลือกได้ 2 โหมด (ตั้งจาก dropdown "เลือก IMU"):
//      • ไม่ใช้ mag → GIRV (gyro-integrated) latency ต่ำ ทนมอเตอร์กวน [default]
//      • ใช้ mag    → RotationVector (9 แกนเต็ม) ได้ทิศเหนือสัมบูรณ์ ไม่ดริฟต์
//                     gyro ในฟิวชันช่วยพยุงตอน mag โดนกวนชั่วคราว
//  ★ เช็คนิ่งก่อนคาริเบต (กันคาริเบตพลาด)
//
//  I2C addr 0x4B (บอร์ดม่วงที่ใช้อยู่)  ⚠️ ถ้าหาไม่เจอลองเปลี่ยน 0x4A
//  Wire1 (SDA=GP26, SCL=GP27)
//  ⚠️ เลี้ยวกลับด้าน → เปลี่ยน BNO085_YAW_SIGN เป็น -1.0f
// ══════════════════════════════════════════════════════════════

#include "SparkFun_BNO08x_Arduino_Library.h"

#define BNO085_ADDR       0x4B       // บอร์ดม่วงนี้ = 0x4B | ถ้าไม่เจอลอง 0x4A
#define BNO085_YAW_SIGN   (-1.0f)   // หมุนขวา = เลขเพิ่ม (ตรงกับ BNO055)
#define BNO085_RATE_MS    10         // อัตราส่งข้อมูล (10=100Hz)

bool _bno085_useMag = false;         // ← dispatcher ตั้งค่านี้ก่อน init (default ไม่ใช้)

inline BNO08x& _bno085Dev() {
  static BNO08x dev;
  return dev;
}
static float _bno085_yaw = 0;        // เก็บค่าล่าสุด

// อ่าน quaternion → yaw 0–360 (getQuat* ใช้ได้ทั้ง GIRV และ RotationVector)
inline float bno085_getYawRaw() {
  if (_bno085Dev().getSensorEvent()) {
    float qr = _bno085Dev().getQuatReal();
    float qi = _bno085Dev().getQuatI();
    float qj = _bno085Dev().getQuatJ();
    float qk = _bno085Dev().getQuatK();
    float yaw = atan2(2.0f * (qr*qk + qi*qj),
                      1.0f - 2.0f * (qj*qj + qk*qk)) * 57.2958f;
    yaw *= BNO085_YAW_SIGN;
    if (yaw < 0)    yaw += 360;
    if (yaw >= 360) yaw -= 360;
    _bno085_yaw = yaw;
  }
  return _bno085_yaw;
}

// รอจนค่านิ่งจริงก่อน (กันคาริเบตพลาดตอนหุ่นยังขยับ/มือจับ)
inline void _bno085_waitStable() {
  float last = bno085_getYawRaw();
  int stable = 0;
  unsigned long t0 = millis();
  while (stable < 30) {
    float now = bno085_getYawRaw();
    if (fabs(now - last) < 0.3f) stable++;
    else                          stable = 0;
    last = now;
    delay(20);
    if (millis() - t0 > 5000) break;   // กันค้างเกิน 5 วิ
  }
}

inline void bno085_initIMU() {
  if (!_bno085Dev().begin(BNO085_ADDR, Wire1)) {
    Serial.println("BNO085 not detected (ลองเปลี่ยน BNO085_ADDR เป็น 0x4A)");
    while (1);
  }
  if (_bno085_useMag) {
    // RotationVector = ฟิวชัน 9 แกน (accel+gyro+mag) ได้ทิศเหนือสัมบูรณ์
    _bno085Dev().enableRotationVector(BNO085_RATE_MS);
  } else {
    // GIRV = gyro-integrated (ไม่ใช้ mag, latency ต่ำ) [default ปลอดภัย]
    _bno085Dev().enableGyroIntegratedRotationVector(BNO085_RATE_MS);
  }
  delay(200);              // ให้ fusion เริ่มทำงาน
  _bno085_waitStable();    // ⭐ รอจนนิ่งจริงก่อนปล่อยให้ dispatcher คาริเบต
}

// (เสริม) ค่าความมั่นใจ mag: 0=แย่ 1=ต่ำ 2=กลาง 3=ดีเยี่ยม
//   ใช้เช็คว่าสนามนี้ mag เชื่อถือได้ไหม (ใช้ได้เฉพาะโหมด mag)
inline int bno085_getMagAccuracy() { return _bno085Dev().getMagAccuracy(); }
