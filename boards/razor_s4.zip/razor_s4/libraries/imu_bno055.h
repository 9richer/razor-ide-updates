#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_bno055.h — ตัวอ่านเซนเซอร์ BNO055 (เซนเซอร์ล้วน)
//  ใช้คู่กับ razors4_imu.h (ตัวสลับ IMU) | ฟังก์ชันขึ้นต้น bno_
//
//  ★ เลือกได้ 2 โหมด (ตั้งจาก dropdown "เลือก IMU"):
//      • ไม่ใช้ mag → IMUPLUS (6 แกน) ทนมอเตอร์กวน [default]
//      • ใช้ mag    → NDOF (9 แกนเต็ม) ได้ทิศเหนือสัมบูรณ์ ไม่ดริฟต์
//
//  I2C addr 0x29 | Wire1 (SDA=GP26, SCL=GP27)
// ══════════════════════════════════════════════════════════════

#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>

bool _bno_useMag = false;          // ← dispatcher ตั้งค่านี้ก่อน init (default ไม่ใช้)

inline Adafruit_BNO055& _bnoDev() {                 // object เดียว สร้างครั้งแรกที่เรียก
  static Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x29, &Wire1);
  return bno;
}

inline void bno_initIMU() {
  // NDOF = 9 แกน (ใช้ mag) | IMUPLUS = 6 แกน (ไม่ใช้ mag, default)
  adafruit_bno055_opmode_t mode = _bno_useMag ? OPERATION_MODE_NDOF
                                              : OPERATION_MODE_IMUPLUS;
  if (!_bnoDev().begin(mode)) {
    Serial.println("BNO055 not detected");
    while (1);
  }
  _bnoDev().setExtCrystalUse(true);
}

inline float bno_getYawRaw() {
  imu::Vector<3> euler = _bnoDev().getVector(Adafruit_BNO055::VECTOR_EULER);
  return euler.x();                                 // 0–360
}

// (เสริม) ค่าความมั่นใจ mag: 0=แย่ ถึง 3=ดีเยี่ยม (ใช้เช็คเฉพาะโหมด NDOF)
inline int bno_getMagAccuracy() {
  uint8_t sys, gyro, accel, mag;
  _bnoDev().getCalibration(&sys, &gyro, &accel, &mag);
  return mag;
}
