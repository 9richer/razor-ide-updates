#pragma once
#include <Arduino.h>
#include <SPI.h>

// ══════════════════════════════════════════════════════════════
//  MCP3008 / MCP3208 — SPI ADC Library สำหรับ RazorS4 (RP2040)
//
//  Pin (ต่อตรงตาม schematic):
//    CLK  → GP18   (SPI0 SCK)
//    MISO → GP16   (SPI0 RX / DOUT)
//    MOSI → GP19   (SPI0 TX / DIN)
//    CS   → GP17
//
//  ใช้งาน:
//    analog3008(0)      → อ่าน CH0  คืน 0–1023  (10-bit)
//    analog3208(0)      → อ่าน CH0  คืน 0–4095  (12-bit)
//    analogVolt3008(0)  → แรงดัน CH0  0.0–3.3V  (10-bit)
//    analogVolt3208(0)  → แรงดัน CH0  0.0–3.3V  (12-bit)
// ══════════════════════════════════════════════════════════════

#define MCP_CS_PIN   17   // CS#/SHDN → GP17
#define MCP_CLK_PIN  18   // CLK      → GP18
#define MCP_MISO_PIN 16   // DOUT     → GP16
#define MCP_MOSI_PIN 19   // DIN      → GP19

// ── init SPI0 ────────────────────────────────────────────────
// เรียกครั้งเดียวใน setup() — razors4_mcp_begin()
// (ถูกเรียกอัตโนมัติครั้งแรกที่ใช้งาน)

static bool _mcp_initialized = false;

inline void _mcp_begin() {
  if (_mcp_initialized) return;
  pinMode(MCP_CS_PIN, OUTPUT);
  digitalWrite(MCP_CS_PIN, HIGH);
  SPI.setRX(MCP_MISO_PIN);    // GP16 ← DOUT  (SPI0)
  SPI.setTX(MCP_MOSI_PIN);    // GP19 → DIN   (SPI0)
  SPI.setSCK(MCP_CLK_PIN);    // GP18 → CLK   (SPI0)
  SPI.begin();
  _mcp_initialized = true;
}

// ══════════════════════════════════════════════════════════════
//  MCP3008  — 10-bit (0–1023)
// ══════════════════════════════════════════════════════════════

inline int analog3008(int channel) {
  if (channel < 0 || channel > 7) return -1;
  _mcp_begin();

  byte command[3];
  command[0] = 0x01;                   // start bit
  command[1] = 0x80 | (channel << 4); // single-ended + channel
  command[2] = 0x00;

  digitalWrite(MCP_CS_PIN, LOW);
  SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));

  SPI.transfer(command[0]);
  byte highByte = SPI.transfer(command[1]);
  byte lowByte  = SPI.transfer(command[2]);

  SPI.endTransaction();
  digitalWrite(MCP_CS_PIN, HIGH);

  return ((highByte & 0x03) << 8) | lowByte;  // 10-bit result
}

inline float analogVolt3008(int channel) {
  int val = analog3008(channel);
  if (val < 0) return -1.0;
  return (val * 3.3f) / 1023.0f;
}

// ══════════════════════════════════════════════════════════════
//  MCP3208  — 12-bit (0–4095)
// ══════════════════════════════════════════════════════════════

inline int analog3208(int channel) {
  if (channel < 0 || channel > 7) return -1;
  _mcp_begin();

  // MCP3208 command: start(1) + SGL(1) + D2 D1 D0 + padding
  byte command[3];
  command[0] = 0x06 | (channel >> 2);        // 0000 0110 | D2
  command[1] = (channel & 0x03) << 6;        // D1 D0 + 6 zeros
  command[2] = 0x00;

  digitalWrite(MCP_CS_PIN, LOW);
  SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));

  SPI.transfer(command[0]);
  byte highByte = SPI.transfer(command[1]);
  byte lowByte  = SPI.transfer(command[2]);

  SPI.endTransaction();
  digitalWrite(MCP_CS_PIN, HIGH);

  return ((highByte & 0x0F) << 8) | lowByte;  // 12-bit result
}

inline float analogVolt3208(int channel) {
  int val = analog3208(channel);
  if (val < 0) return -1.0;
  return (val * 3.3f) / 4095.0f;
}
