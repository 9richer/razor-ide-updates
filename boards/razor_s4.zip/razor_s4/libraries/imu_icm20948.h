#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_icm20948.h — ICM-20948 "Competition Grade" (open-loop heading)
//  ใช้คู่กับ razors4_imu.h | ฟังก์ชันขึ้นต้น icm_
//
//  ออกแบบสำหรับ: คาลิเบตทิศครั้งเดียว → อิงทิศเดิมตลอดสนาม (ไม่รีเซต)
//  วิ่งเร็ว เลี้ยว ~200ms (peak ~1400°/s) — เน้น drift ต่ำสุดตลอด 2-3 นาที
//
//  เทคนิค (port + ปรับจาก imu_mpu6050.h — ICM lib คืนค่าเป็น °/s อยู่แล้ว):
//    A) gyro ±2000 dps (กัน saturate ตอน overshoot) + DLPF ~119Hz (กรองสั่น)
//       + ODR 220Hz + แก้บั๊ก dt (clamp ไม่ทิ้งมุม)
//    B) Adaptive ZUPT (วัด noise floor) + 1D Kalman bias + Motor gating
//    C) Thermal bias compensation (ใช้ temp sensor ในตัว)
//    D) Scale-factor correction + เก็บถาวรใน EEPROM
//
//  ★ ไลบรารี SparkFun ICM-20948 | gyro ดิบ + ZUPT (ไม่แตะ DMP)
//  I2C addr 0x69 (default) หรือ 0x68 (AD0=GND) | Wire1 (GP26/27)
//  ⚠️ เลี้ยวกลับด้าน → เปลี่ยน ICM_YAW_SIGN เป็น -1.0f
// ══════════════════════════════════════════════════════════════

#include "ICM_20948.h"
#include <EEPROM.h>

// ── ★ ปรับจูนหลัก ─────────────────────────────────────────────
#define ICM_YAW_SIGN     (-1.0f)                 // เลี้ยวกลับด้าน → -1.0f
#define ICM_DLPF_CFG     gyr_d119bw5_n154bw3     // 0x02 ~119Hz (สั่นมาก→gyr_d51bw2_n73bw3, มุมขาด→gyr_d151bw8_n187bw6)
#define ICM_SMPLRT_DIV   4                        // ODR = 1100/(1+div) = 220Hz
#define ICM_WARMUP_MS    0                        // วอร์มอัพก่อนคาลิเบต (0=ปิด) — ลด thermal drift

#define ICM_STILL_ACC    0.06f    // นิ่งเมื่อ |accel-1g| < ค่านี้ (g)
#define ICM_STILL_HOLD   8        // นิ่งติดกันกี่รอบจึงอัปเดต bias
#define ICM_GATE_HOLD    3        // หลัง ao() (มอเตอร์หยุด) นับแค่ 3 รอบก็ ZUPT

// ── Adaptive ZUPT (วัด noise floor จริงตอน init) ──────────────
#define ICM_STILL_SIGMA  4.0f     // threshold = noise_floor × 4σ (≈99.99%)
#define ICM_STILL_MIN    0.8f     // clamp ล่าง (°/s)
#define ICM_STILL_MAX    3.0f     // clamp บน  (°/s)

// ── 1D Kalman Bias ───────────────────────────────────────────
#define ICM_KALMAN_Q     0.0001f  // process noise: bias เปลี่ยนช้ามาก
#define ICM_KALMAN_R     0.05f     // measurement noise (°/s)² — tune ถ้า bias สั่น

// ── Thermal Compensation ─────────────────────────────────────
#define ICM_THERMAL_ENABLE  1
#define ICM_THERMAL_COEFF   0.0f   // °/s ต่อ °C — วัดชิปจริงด้วย icm_thermalProbe() แล้วใส่

// ── Saturation ───────────────────────────────────────────────
#define ICM_SAT_LIMIT    1950.0f   // เตือนเมื่อ |gyro| ใกล้ ±2000 (°/s)

// ── Scale-factor EEPROM (addr 32 — line sensor ใช้ 0..19) ─────
#define ICM_EEPROM_SIZE  256  // ⚠ ต้องเท่ากับ EEPROM_SIZE / TCS_EE_SIZE (กัน commit ลบกัน)
#define ICM_SCALE_ADDR   32
#define ICM_SCALE_MAGIC  0x5A3C

ICM_20948_I2C _icmDev;

static double        _icm_yawAccum   = 0.0;
static float         _icm_bias       = 0.0f;   // °/s
static float         _icm_prevRate   = 0.0f;
static unsigned long _icm_lastUs     = 0;
static int           _icm_stillCnt   = 0;
static bool          _icm_stationary = false;
static bool          _icm_firstRead  = true;
static float         _icm_tempC      = 25.0f;  // อุณหภูมิล่าสุด (°C)
static float         _icm_tempRef    = 25.0f;  // อุณหภูมิตอนคาลิเบต

// IIR filter — ใช้กับ still-detection เท่านั้น (integration ใช้ raw)
static float         _icm_rateFilt   = 0.0f;
// Motor gating
static bool          _icm_gateFlag   = false;
// Adaptive ZUPT threshold (°/s) — ตั้งตอน init จาก noise floor จริง
static float         _icm_stillThresh = ICM_STILL_MIN;
// Kalman covariance
static float         _icm_kalmanP    = 1.0f;
// Saturation flag (debug)
static bool          _icm_saturated  = false;
// Scale-factor
static float         _icm_scale         = 1.0f;
static bool          _icm_scaleCalActive = false;

struct _IcmScaleEE { uint16_t magic; float scale; };

// ── EEPROM: โหลด/บันทึก scale ────────────────────────────────
static inline void _icm_loadScale() {
  _IcmScaleEE d;
  EEPROM.begin(ICM_EEPROM_SIZE);
  EEPROM.get(ICM_SCALE_ADDR, d);
  EEPROM.end();
  if (d.magic == ICM_SCALE_MAGIC && d.scale >= 0.9f && d.scale <= 1.1f) _icm_scale = d.scale;
  else                                                                   _icm_scale = 1.0f;
}
static inline void _icm_saveScale() {
  _IcmScaleEE d; d.magic = ICM_SCALE_MAGIC; d.scale = _icm_scale;
  EEPROM.begin(ICM_EEPROM_SIZE);
  EEPROM.put(ICM_SCALE_ADDR, d);
  EEPROM.commit();
  EEPROM.end();
}

// อ่าน accel(g) + gyro(°/s) + temp(°C) — false ถ้ายังไม่มีข้อมูลใหม่
static inline bool _icm_read(float &ax, float &ay, float &az,
                             float &gx, float &gy, float &gz) {
  if (!_icmDev.dataReady()) return false;
  _icmDev.getAGMT();
  ax = _icmDev.accX() / 1000.0f;   // mg → g
  ay = _icmDev.accY() / 1000.0f;
  az = _icmDev.accZ() / 1000.0f;
  gx = _icmDev.gyrX();             // °/s
  gy = _icmDev.gyrY();
  gz = _icmDev.gyrZ();
  _icm_tempC = _icmDev.temp();     // °C
  return true;
}

static inline float _icm_wrappedYaw() {
  double y = fmod(_icm_yawAccum, 360.0);
  if (y < 0) y += 360.0;
  return (float)y;
}

// วัด bias (mean) + noise floor (stddev → adaptive ZUPT threshold) + tempRef
static inline void _icm_calibrateBias(int samples = 1000) {
  // ① วัด bias
  double sum = 0; int got = 0;
  unsigned long t0 = millis();
  while (got < samples && millis() - t0 < 4000) {
    float ax, ay, az, gx, gy, gz;
    if (_icm_read(ax, ay, az, gx, gy, gz)) { sum += gz; got++; }
  }
  if (got > 0) _icm_bias = (float)(sum / got);

  // ② วัด noise floor → Adaptive ZUPT threshold (หน่วย °/s ตรง ไม่หาร LSB)
  double sumSq = 0; int n = 0;
  t0 = millis();
  while (n < 200 && millis() - t0 < 2000) {
    float ax, ay, az, gx, gy, gz;
    if (_icm_read(ax, ay, az, gx, gy, gz)) {
      float e = gz - _icm_bias;
      sumSq += (double)e * e; n++;
    }
  }
  float stddev = (n > 0) ? sqrtf((float)(sumSq / n)) : ICM_STILL_MIN;
  _icm_stillThresh = constrain(stddev * ICM_STILL_SIGMA, ICM_STILL_MIN, ICM_STILL_MAX);

  // ③ reset Kalman + บันทึก temp อ้างอิง
  _icm_kalmanP = 1.0f;
  _icm_tempRef = _icm_tempC;
}

static inline void _icm_waitStable() {
  int stable = 0;
  unsigned long t0 = millis();
  while (stable < 30) {
    float ax, ay, az, gx, gy, gz;
    if (_icm_read(ax, ay, az, gx, gy, gz)) {
      float accMag = sqrt(ax*ax + ay*ay + az*az);
      bool still = (fabs(gx) < ICM_STILL_MAX) && (fabs(gy) < ICM_STILL_MAX) &&
                   (fabs(gz) < ICM_STILL_MAX) && (fabs(accMag - 1.0f) < ICM_STILL_ACC);
      if (still) stable++; else stable = 0;
    }
    delay(10);
    if (millis() - t0 > 6000) break;     // กันค้าง 6 วิ
  }
}

// ── Motor Activity Gating — ao() (motor_razors4.h) set _motor_ao_called ──
//   เรียกตรงได้เพราะ RazorS4.h include motor_razors4.h ก่อน razors4_imu.h
inline void icm_notifyStop() { _icm_gateFlag = true; }

inline void icm_initIMU() {
  // เปิด Wire1 บน GP26/27 เผื่อยังไม่ถูกเปิด (เช่น ไม่ได้ใช้บล็อก OLED)
  Wire1.setSDA(26);
  Wire1.setSCL(27);
  Wire1.begin();

  // ลองที่อยู่ 0x69 (ad0=1) ก่อน แล้ว 0x68 (ad0=0)
  bool ok = false;
  for (int i = 0; i < 5 && !ok; i++) {
    if (_icmDev.begin(Wire1, 1) == ICM_20948_Stat_Ok) ok = true;
    else if (_icmDev.begin(Wire1, 0) == ICM_20948_Stat_Ok) ok = true;
    else delay(50);
  }
  if (!ok) {
    Serial.println("ICM-20948 not detected");
    pinMode(9, OUTPUT);
    while (1) { tone(9, 2000); delay(100); noTone(9); delay(100); }
  }

  _icmDev.swReset();  delay(250);
  _icmDev.sleep(false);
  _icmDev.lowPower(false);

  // ── A) gyro ±2000 dps (กัน saturate) + accel ±2g ──
  ICM_20948_fss_t fss;
  fss.a = gpm2;
  fss.g = dps2000;
  _icmDev.setFullScale((ICM_20948_Internal_Acc | ICM_20948_Internal_Gyr), fss);

  // ── A) DLPF — กรองสั่นมอเตอร์ (ไม่เฉือนยอดมุมเลี้ยวเร็ว) ──
  ICM_20948_dlpcfg_t dlp;
  dlp.a = acc_d111bw4_n136bw;
  dlp.g = ICM_DLPF_CFG;
  _icmDev.setDLPFcfg((ICM_20948_Internal_Acc | ICM_20948_Internal_Gyr), dlp);
  _icmDev.enableDLPF(ICM_20948_Internal_Gyr, true);
  _icmDev.enableDLPF(ICM_20948_Internal_Acc, true);

  // ── A) Sample rate / ODR 220Hz (integration ละเอียด) ──
  ICM_20948_smplrt_t smplrt;
  smplrt.g = ICM_SMPLRT_DIV;
  smplrt.a = ICM_SMPLRT_DIV;
  _icmDev.setSampleRate((ICM_20948_Internal_Acc | ICM_20948_Internal_Gyr), smplrt);

  _icmDev.setSampleMode((ICM_20948_Internal_Acc | ICM_20948_Internal_Gyr),
                        ICM_20948_Sample_Mode_Continuous);
  delay(50);

  // ── D) โหลด scale-factor จาก EEPROM ──
  _icm_loadScale();

  // ── C) วอร์มอัพก่อนคาลิเบต (option) — ลด thermal drift ──
#if ICM_WARMUP_MS > 0
  { unsigned long tw = millis();
    while (millis() - tw < ICM_WARMUP_MS) { float a,b,c,d,e,f; _icm_read(a,b,c,d,e,f); delay(5); } }
#endif

  _icm_waitStable();          // ⭐ รอจนนิ่งจริงก่อนคาริเบต
  _icm_calibrateBias(1000);   // ★ วัด bias + noise floor + tempRef ตอนนิ่ง
  _icm_yawAccum  = 0.0;
  _icm_prevRate  = 0.0f;
  _icm_stillCnt  = 0;
  _icm_gateFlag  = false;
  _icm_firstRead = true;
  _icm_lastUs    = micros();
}

inline float icm_getYawRaw() {
  // ── B) Motor Gating — รับ flag จาก ao() ──
  if (_motor_ao_called) {
    _motor_ao_called = false;
    _icm_gateFlag    = true;
  }

  float ax, ay, az, gx, gy, gz;
  if (!_icm_read(ax, ay, az, gx, gy, gz)) return _icm_wrappedYaw();   // ไม่มีข้อมูลใหม่

  // ── A) dt + clamp (แก้บั๊กเดิมที่ทิ้งมุมทั้งก้อน) ──
  unsigned long now = micros();
  float dt = (now - _icm_lastUs) / 1000000.0f;
  _icm_lastUs = now;
  if (dt < 0)     dt = 0;
  if (dt > 0.05f) dt = 0.05f;
  if (_icm_firstRead) { dt = 0; _icm_firstRead = false; }

  // ── C) Thermal drift compensation (หักก่อนเข้า Kalman) ──
  float thermalOffset = 0.0f;
#if ICM_THERMAL_ENABLE
  thermalOffset = (_icm_tempC - _icm_tempRef) * ICM_THERMAL_COEFF;
#endif

  float errZ = gz - _icm_bias - thermalOffset;   // °/s

  // ── Saturation detect (dps2000 → แทบไม่เกิด แต่เตือนไว้) ──
  _icm_saturated = (fabsf(gz) > ICM_SAT_LIMIT);

  // ── B) IIR filter บน errZ — ใช้เฉพาะ still-detection ──
  _icm_rateFilt = 0.65f * _icm_rateFilt + 0.35f * errZ;

  // ── B) Still detection (filtered) ──
  float accMag = sqrtf(ax*ax + ay*ay + az*az);
  bool still = (fabsf(gx)            < _icm_stillThresh) &&
               (fabsf(gy)            < _icm_stillThresh) &&
               (fabsf(_icm_rateFilt) < _icm_stillThresh) &&
               (fabsf(accMag - 1.0f) < ICM_STILL_ACC);
  if (_icm_scaleCalActive) still = false;   // ปิด ZUPT ระหว่างจูน scale (กันมุมหายตอนหมุนช้า)

  // ── B) Motor Gating — เร่ง ZUPT หลังมอเตอร์หยุด ──
  int holdNeeded = _icm_gateFlag ? ICM_GATE_HOLD : ICM_STILL_HOLD;
  if (still) { if (_icm_stillCnt < 100000) _icm_stillCnt++; }
  else       { _icm_stillCnt = 0; _icm_gateFlag = false; }
  _icm_stationary = (_icm_stillCnt >= holdNeeded);
  if (_icm_stationary && _icm_gateFlag) _icm_gateFlag = false;

  // ── B) 1D Kalman Bias Update ──
  float rateZ = errZ;
  if (_icm_stationary) {
    float K = _icm_kalmanP / (_icm_kalmanP + ICM_KALMAN_R);
    _icm_bias   += K * errZ;
    _icm_kalmanP = (1.0f - K) * _icm_kalmanP + ICM_KALMAN_Q;
    rateZ = 0.0f;   // บังคับ rate=0 ขณะนิ่ง กันนอยส์รั่ว
  } else {
    _icm_kalmanP += ICM_KALMAN_Q;
  }

  // ── D) Scale-factor (ปิดชั่วคราวตอนจูน scale เพื่อวัด raw) ──
  float effScale = _icm_scaleCalActive ? 1.0f : _icm_scale;
  float rate = rateZ * effScale * ICM_YAW_SIGN;

  // ── A) Trapezoidal integration (raw rate — ไม่มี lag) ──
  _icm_yawAccum += (double)(0.5f * (rate + _icm_prevRate)) * dt;
  _icm_prevRate  = rate;

  return _icm_wrappedYaw();
}

// ── D) Scale-factor calibration (block เดียว: หมุนหุ่นด้วยมือ N รอบ → กดปุ่ม Go) ──
//   ground truth = N×360° (หุ่นหมุนเองวัดไม่ได้เพราะ circular)
//   ฟังก์ชันนี้ "นับมุมเอง" ในลูป จนกว่าจะกดปุ่ม Go (pin 10) — ต้องนับมุมต่อเนื่อง
//   ตอนหมุน ดังนั้นรวมเป็น block เดียวที่ blocking (wait_go/delay ไม่อ่านมุมให้)
//   วางชั่วคราวจูนครั้งเดียว แล้วเอา block ออก (ค่าอยู่ EEPROM ถาวร)
inline float icm_scaleCalibrate(int turns) {
  pinMode(9, OUTPUT);
  pinMode(10, INPUT_PULLUP);          // ปุ่ม Go (กด = LOW) — ตรงกับ sw_go()

  tone(9, 1500); delay(200); noTone(9);   // 🔔 บี๊บเริ่ม — เริ่มหมุนหุ่นได้

  _icm_yawAccum       = 0.0;
  _icm_prevRate       = 0.0f;
  _icm_firstRead      = true;
  _icm_lastUs         = micros();
  _icm_scaleCalActive = true;         // ปิด ZUPT + integrate ด้วย scale=1.0

  // หมุนหุ่นด้วยมือ N รอบ — ลูปอ่านมุมต่อเนื่องจนกดปุ่ม Go
  while (digitalRead(10) == HIGH) { icm_getYawRaw(); delay(2); }
  delay(50);                                                        // debounce
  while (digitalRead(10) == LOW)  { icm_getYawRaw(); delay(2); }    // รอปล่อยปุ่ม (ยังนับมุม)

  _icm_scaleCalActive = false;
  double measured = fabs(_icm_yawAccum);
  if (measured > 10.0 && turns > 0) {
    _icm_scale = constrain((float)(turns * 360.0 / measured), 0.9f, 1.1f);
    _icm_saveScale();                 // เก็บถาวร EEPROM
  }
  _icm_yawAccum = 0.0;                 // เริ่มนับทิศใหม่หลังจูน
  _icm_prevRate = 0.0f;

  tone(9, 2000); delay(120); noTone(9); delay(80);    // 🔔 บี๊บจบ 2 ครั้ง
  tone(9, 2000); delay(120); noTone(9);
  return _icm_scale;
}

// ── Debug / OLED helpers ─────────────────────────────────────
inline float icm_getTemp()       { return _icm_tempC; }       // °C
inline float icm_getBias()       { return _icm_bias; }        // °/s
inline float icm_getScale()      { return _icm_scale; }
inline float icm_getStillThresh(){ return _icm_stillThresh; } // °/s
inline bool  icm_isStationary()  { return _icm_stationary; }
inline bool  icm_isSaturated()   { return _icm_saturated; }   // เตือน: ต้องขยาย full-scale?

// วัด thermal coefficient: เรียกตอนเย็น → วิ่งให้ร้อน → เรียกตอนร้อน (นิ่งทั้งคู่)
//   พิมพ์ค่า coeff ออก Serial เอาไปใส่ ICM_THERMAL_COEFF
inline void icm_thermalProbe() {
  static bool  haveFirst = false;
  static float t0 = 0, b0 = 0;
  float bias = _icm_bias, t = _icm_tempC;
  if (!haveFirst) {
    t0 = t; b0 = bias; haveFirst = true;
    Serial.print("[thermalProbe] จุดที่ 1  T="); Serial.print(t);
    Serial.print("  bias="); Serial.println(bias, 4);
  } else {
    float dT = t - t0;
    float coeff = (fabsf(dT) > 0.5f) ? (bias - b0) / dT : 0.0f;
    Serial.print("[thermalProbe] จุดที่ 2  T="); Serial.print(t);
    Serial.print("  bias="); Serial.print(bias, 4);
    Serial.print("  → ICM_THERMAL_COEFF="); Serial.println(coeff, 5);
    haveFirst = false;
  }
}
