
#pragma once

#include "Adafruit_GFX.h"
#include "Adafruit_SSD1306.h"

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C

static Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire1,
  -1
);



// =========================
// Razor S4 OLED Begin
// =========================

void razors4()
{
  Wire1.setSDA(26);
  Wire1.setSCL(27);

  Wire1.begin();

  display.begin(
      SSD1306_SWITCHCAPVCC,
      OLED_ADDR);

  display.clearDisplay();

  display.setTextColor(
      SSD1306_WHITE);

  display.display();
}



// =========================
// OLED Clear
// =========================

void oled_clear()
{
  display.clearDisplay();
}



// =========================
// OLED Update
// =========================

void oled_update()
{
  display.display();
}



// =========================
// OLED Show
// ใช้ได้ทั้ง:
// oled(1,"Hello");
// oled(2,analogRead(A0));
// oled(3,"A0",analogRead(A0));
// =========================

template<typename T>
void oled(
    int line,
    T value,
    int size = 1)
{
  int y =
      (line - 1) *
      (size * 10);

  display.setTextSize(size);

  display.setCursor(0, y);

  display.println(value);
}



template<typename T>
void oled(
    int line,
    String label,
    T value,
    int size = 1)
{
  int y =
      (line - 1) *
      (size * 10);

  display.setTextSize(size);

  display.setCursor(0, y);

  display.print(label);

  display.print(": ");

  display.println(value);
}


// =========================
// OLED Draw Line
// วาดเส้นตรงจากจุด (x1,y1) ถึง (x2,y2)
// =========================

void oled_line(int x1, int y1, int x2, int y2) {
  display.drawLine(x1, y1, x2, y2, SSD1306_WHITE);
}



// =========================
// OLED Draw Rectangle
// วาดกรอบสี่เหลี่ยมที่ตำแหน่ง (x,y) ขนาด w x h
// =========================

void oled_rect(int x, int y, int w, int h) {
  display.drawRect(x, y, w, h, SSD1306_WHITE);
}



// =========================
// OLED Fill Rectangle
// วาดสี่เหลี่ยมทึบที่ตำแหน่ง (x,y) ขนาด w x h
// =========================

void oled_fill_rect(int x, int y, int w, int h) {
  display.fillRect(x, y, w, h, SSD1306_WHITE);
}



// =========================
// OLED Draw Circle
// วาดวงกลมที่จุดกึ่งกลาง (x,y) รัศมี r
// =========================

void oled_circle(int x, int y, int r) {
  display.drawCircle(x, y, r, SSD1306_WHITE);
}



// =========================
// OLED Fill Circle
// วาดวงกลมทึบที่จุดกึ่งกลาง (x,y) รัศมี r
// =========================

void oled_fill_circle(int x, int y, int r) {
  display.fillCircle(x, y, r, SSD1306_WHITE);
}



// =========================
// OLED Print at XY
// พิมพ์ข้อความหรือค่าที่ตำแหน่ง pixel (x,y)
// ใช้เมื่อต้องการควบคุม position เองแบบ precise
// =========================

template<typename T>
void oled_xy(int x, int y, T value, int size = 1) {
  display.setTextSize(size);
  display.setCursor(x, y);
  display.print(value);
}



// =========================
// OLED Invert Display
// กลับสี: พื้นขาว-ตัวอักษรดำ / พื้นดำ-ตัวอักษรขาว
// invert = true → กลับสี, false → ปกติ
// =========================

void oled_invert(bool invert) {
  display.invertDisplay(invert);
}



// =========================
// OLED Dim
// ลดความสว่างจอ
// dim = true → หรี่แสง, false → สว่างปกติ
// =========================

void oled_dim(bool dim) {
  display.dim(dim);
}



// =========================
// OLED Progress Bar
// วาด progress bar ที่ตำแหน่ง (x,y) ขนาด w x h
// value = 0-100 (เปอร์เซ็นต์)
// ตัวอย่าง: oled_progress(0, 50, 128, 10, 75)
//           → bar กว้าง 128 สูง 10 เต็ม 75%
// =========================

void oled_progress(int x, int y, int w, int h, int value) {
  // จำกัดค่า 0-100
  if (value < 0)   value = 0;
  if (value > 100) value = 100;

  // วาดกรอบ
  display.drawRect(x, y, w, h, SSD1306_WHITE);

  // วาด bar ข้างใน (เว้น 1px border)
  int fillW = (int)((w - 2) * value / 100.0);
  if (fillW > 0) {
    display.fillRect(x + 1, y + 1, fillW, h - 2, SSD1306_WHITE);
  }
}
