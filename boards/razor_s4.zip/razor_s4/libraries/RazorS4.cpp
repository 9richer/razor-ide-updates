// RazorS4.cpp
// ฟังก์ชันทั้งหมดถูกนิยามเป็น inline ใน RazorS4.h และ motor_razors4.h แล้ว
// ไฟล์นี้จำเป็นต้องมีเพื่อให้ arduino-cli ตรวจพบ library
// แต่ไม่ include ซ้ำ — ไม่เช่นนั้นจะเกิด multiple definition
