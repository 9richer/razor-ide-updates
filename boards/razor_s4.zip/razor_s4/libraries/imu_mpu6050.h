#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_mpu6050.h — MPU6050 "Competition Grade"
//
//  Phase 1:
//    ① Gated ZUPT  — 3-axis gyro + accel≈1g → reset bias อัตโนมัติ
//    ② IIR Rate Filter — smooth still-detection โดยไม่เพิ่ม lag integration
//    ③ Motor Activity Gating — ao() → ZUPT ทันที ไม่รอ 100ms
//    ④ Trapezoidal integration + dt clamp
//
//  Phase 2:
//    ⑤ Adaptive ZUPT Threshold — วัด noise floor จริงตอน init
//    ⑥ 1D Kalman Bias — แทน fixed-gain → self-tuning ตามความไม่แน่นอน
//
//  Phase 3:
//    ⑦ Thermal Drift Compensation — track อุณหภูมิ แก้ drift ตาม ΔT
//       (ต้องเปิด MPU_THERMAL_ENABLE=1 และ tune MPU_THERMAL_COEFF ก่อน)
//
//  I2C addr 0x68 | Wire1 (SDA=GP26, SCL=GP27)
//  ⚠️ เลี้ยวกลับด้าน → เปลี่ยน MPU_YAW_SIGN เป็น -1.0f
// ══════════════════════════════════════════════════════════════

#include <Wire.h>

#define MPU_ADDR      0x68
#define MPU_WIRE      Wire1
#define MPU_SDA       26
#define MPU_SCL       27
#define MPU_YAW_SIGN  (-1.0f)    // หมุนขวา = เลขเพิ่ม (ตรงกับ BNO055)

// ── ★ ปรับจูนหลัก ─────────────────────────────────────────────
#define MPU_GYRO_FS       1000    // ช่วงวัด: 250/500/1000/2000 °/s
#define MPU_DLPF          0x04   // 0x03≈44Hz  0x04≈21Hz  0x05≈10Hz
#define MPU_STILL_GYRO    1.2f   // threshold เริ่มต้น (deg/s) — จะถูกแทนด้วยค่า adaptive
#define MPU_STILL_ACC     0.06f  // นิ่งเมื่อ |accel-1g| < ค่านี้ (g)
#define MPU_STILL_HOLD    8      // ② Motor Gating: ลดจาก 25 → 8 รอบ (หลัง notifyStop ลดอีก)
#define MPU_GATE_HOLD     3      // ③ หลัง notifyStop() นับแค่ 3 รอบก็ ZUPT

// ── ⑤ Adaptive ZUPT ─────────────────────────────────────────
#define MPU_STILL_SIGMA   4.0f   // threshold = noise_floor × sigma นี้ (4σ ≈ 99.99%)

// ── ⑥ Kalman Bias ────────────────────────────────────────────
#define MPU_KALMAN_Q      0.0001f  // process noise: bias เปลี่ยนช้ามาก
#define MPU_KALMAN_R      100.0f   // measurement noise (LSB²) — tune ถ้า bias สั่น

// ── ⑦ Thermal Compensation ───────────────────────────────────
#define MPU_THERMAL_ENABLE  0       // 0=ปิด  1=เปิด (tune MPU_THERMAL_COEFF ก่อน!)
#define MPU_THERMAL_COEFF   0.05f   // dps/°C — ค่า default, วัดชิปจริงแล้วใส่ตรงนี้

// แปลงช่วง gyro → ค่า register + LSB/(deg/s)
#if   MPU_GYRO_FS == 250
  #define _MPU_GYRO_REG  0x00
  static const float _MPU_LSB_DPS = 131.0f;
#elif MPU_GYRO_FS == 500
  #define _MPU_GYRO_REG  0x08
  static const float _MPU_LSB_DPS = 65.5f;
#elif MPU_GYRO_FS == 1000
  #define _MPU_GYRO_REG  0x10
  static const float _MPU_LSB_DPS = 32.8f;
#else  // 2000
  #define _MPU_GYRO_REG  0x18
  static const float _MPU_LSB_DPS = 16.4f;
#endif
static const float _MPU_LSB_G   = 16384.0f;   // ±2 g

static double        _mpu_yawAccum   = 0.0;
static float         _mpu_gyroZbias  = 0.0f;
static float         _mpu_prevRate   = 0.0f;
static unsigned long _mpu_lastUs     = 0;
static int           _mpu_stillCnt   = 0;
static bool          _mpu_stationary = false;
static float         _mpu_tempC      = 0.0f;

// ② IIR filter state — ใช้กับ still-detection เท่านั้น (integration ใช้ raw)
static float         _mpu_rateFilt   = 0.0f;

// ③ Motor Gating
static bool          _mpu_gateFlag   = false;   // ao() set → เร่ง ZUPT

// ⑤ Adaptive ZUPT threshold (deg/s) — ตั้งตอน init จาก noise floor จริง
static float         _mpu_stillThresh = MPU_STILL_GYRO;

// ⑥ Kalman Bias
static float         _mpu_kalmanP    = 1.0f;   // error covariance

// ⑦ Thermal
static float         _mpu_tempRef    = 25.0f;  // อุณหภูมิตอน calibrate

static inline void _mpu_write(uint8_t reg, uint8_t val) {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(reg); MPU_WIRE.write(val);
  MPU_WIRE.endTransmission();
}

// อ่านรวด accel(3)+temp+gyro(3) = 14 ไบต์ ใน transaction เดียว (เร็ว)
static inline void _mpu_readAll(float &ax, float &ay, float &az,
                                float &gx, float &gy, float &gz) {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(0x3B);                          // ACCEL_XOUT_H
  MPU_WIRE.endTransmission(false);
  uint8_t got = MPU_WIRE.requestFrom((int)MPU_ADDR, 14);
  if (got < 14) {                              // I2C error — คืนค่า "นิ่ง" ทั้งหมด
    ax = 0; ay = 0; az = 1.0f;                // accel ≈ 1g (นิ่ง)
    gx = 0; gy = 0; gz = 0;
    while (MPU_WIRE.available()) MPU_WIRE.read(); // flush
    return;
  }
  int16_t rax = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t ray = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t raz = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t rt  = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t rgx = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t rgy = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t rgz = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  ax = rax / _MPU_LSB_G;  ay = ray / _MPU_LSB_G;  az = raz / _MPU_LSB_G;
  gx = rgx / _MPU_LSB_DPS; gy = rgy / _MPU_LSB_DPS; gz = (float)rgz;  // gz ยังเป็น LSB
  _mpu_tempC = rt / 340.0f + 36.53f;
}

static inline void _mpu_calibrateBias(int samples = 700) {
  // ── ①+⑤ วัด bias (mean) + noise floor (stddev) ในลูปเดียว ────
  //  single-pass: เก็บ sum กับ sumSq พร้อมกัน → ได้ทั้ง mean และ
  //  variance จากชุดตัวอย่างชุดเดียว
  //  • เดิม: 2 ลูปแยก (2000 + 200) + delay(1) ≈ 2.6 วินาที
  //  • ใหม่: 1 ลูป 700 ตัวอย่าง ≈ 0.7 วินาที
  //  ลด sample ได้เพราะ (1) DLPF 21Hz ทำให้ตัวอย่างติดกัน correlate
  //  → 2000 ตัวให้ค่าอิสระจริงแค่ ~250, (2) ZUPT+Kalman จูน bias ต่อ
  //  ตอนวิ่งอยู่แล้ว ค่านี้เป็นแค่ค่าตั้งต้น
  double sum   = 0;
  double sumSq = 0;
  for (int i = 0; i < samples; i++) {
    MPU_WIRE.beginTransmission(MPU_ADDR);
    MPU_WIRE.write(0x47); MPU_WIRE.endTransmission(false);
    MPU_WIRE.requestFrom((int)MPU_ADDR, 2);
    int16_t z = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
    sum   += z;
    sumSq += (double)z * z;
    delay(1);
  }
  double mean = sum / samples;
  _mpu_gyroZbias = (float)mean;
  _mpu_kalmanP   = 1.0f;   // reset Kalman covariance หลัง calibrate

  // ── ⑤ noise floor → ตั้ง Adaptive ZUPT threshold ────────────
  //  variance = E[z²] − (E[z])²  (คำนวณจากชุดเดียวกับ bias)
  double var = sumSq / samples - mean * mean;
  if (var < 0) var = 0;                       // กันปัดเศษ double ติดลบเล็กน้อย
  float stddev_dps = sqrtf((float)var) / _MPU_LSB_DPS;
  // threshold = clamp(noise_floor × 4σ, 0.8, 3.0)
  // cap 3.0 กัน: ถ้าตอน calibrate มีสั่น stddev พุ่ง → threshold สูงเกิน → ZUPT ไม่ fire
  _mpu_stillThresh = constrain(stddev_dps * MPU_STILL_SIGMA, 0.8f, 3.0f);

  // ── ⑦ บันทึก temp อ้างอิงตอน calibrate ──────────────────────
  _mpu_tempRef = _mpu_tempC;
}

// รอจนหุ่นนิ่งจริงก่อนคาริเบต (กันคาริเบตพลาดตอนเปิดเครื่องแล้วหุ่นยังขยับ/มือจับ)
//   เงื่อนไข: gyro ทุกแกนเล็ก + ความเร่ง ≈ 1g  ติดกัน ~600ms
//   มี timeout 6 วิ กันค้าง (เผื่อหุ่นสั่นตลอด)
static inline void _mpu_waitStable() {
  const float STILL_G = 3.0f;     // dps (เผื่อ bias ที่ยังไม่หัก)
  const float STILL_A = 0.08f;    // g
  int stable = 0;
  unsigned long t0 = millis();
  while (stable < 15) {           // 15 รอบ × 20ms ≈ 300ms (ลดจาก 30)
    float ax, ay, az, gx, gy, gzRaw;
    _mpu_readAll(ax, ay, az, gx, gy, gzRaw);
    float gz = gzRaw / _MPU_LSB_DPS;
    float accMag = sqrt(ax*ax + ay*ay + az*az);
    bool still = (fabs(gx) < STILL_G) && (fabs(gy) < STILL_G) &&
                 (fabs(gz) < STILL_G) && (fabs(accMag - 1.0f) < STILL_A);
    if (still) stable++;
    else       stable = 0;
    delay(20);
    if (millis() - t0 > 6000) break;   // กันค้างเกิน 6 วิ
  }
}

// ── ③ Motor Activity Gating ──────────────────────────────────
//  ao() ใน motor_razors4.h set _motor_ao_called = true
//  mpu_getYawRaw() อ่าน flag นี้แล้ว clear → trigger ZUPT เร็ว
//  ไม่ต้อง include IMU header ใน motor_razors4.h (กัน include-order bug)
inline void mpu_notifyStop() { _mpu_gateFlag = true; }  // ยังใช้ได้ call ตรง

inline void mpu_initIMU() {
  MPU_WIRE.setSDA(MPU_SDA);                       // ลบ 3 บรรทัดได้ถ้าเฟรมเวิร์กเปิด Wire1 แล้ว
  MPU_WIRE.setSCL(MPU_SCL);
  MPU_WIRE.begin();
  MPU_WIRE.setClock(400000);

  MPU_WIRE.beginTransmission(MPU_ADDR);           // WHO_AM_I: 6050=0x68 6500=0x70 9250=0x71
  MPU_WIRE.write(0x75); MPU_WIRE.endTransmission(false);
  MPU_WIRE.requestFrom((int)MPU_ADDR, 1);
  uint8_t who = MPU_WIRE.read();
  if (who != 0x68 && who != 0x70 && who != 0x71) {
    // IMU ไม่เจอ — แจ้งเตือน + Beep ซ้ำ ไม่ค้างเงียบ
    Serial.println("MPU6050/9250 not detected");
    pinMode(9, OUTPUT);
    while (1) {
      tone(9, 2000); delay(100); noTone(9); delay(100);   // Beep แจ้ง error
    }
  }

  _mpu_write(0x6B, 0x01);     // ปลุก + PLL gyro-X (นิ่งกว่า internal osc)
  delay(50);
  _mpu_write(0x1A, MPU_DLPF); // DLPF กรองนอยส์มอเตอร์
  _mpu_write(0x19, 0x00);     // SMPLRT 1kHz
  _mpu_write(0x1B, _MPU_GYRO_REG); // gyro full-scale ตาม MPU_GYRO_FS
  _mpu_write(0x1C, 0x00);     // accel ±2 g
  delay(50);

  _mpu_waitStable();          // ⭐ รอจนหุ่นนิ่งจริงก่อน (กันเปิดมาแล้วมุมมั่ว) ~0.3s
  _mpu_calibrateBias(700);    // ★ วัด bias ตอนนิ่งสนิท (single-pass ~0.7s)
  _mpu_yawAccum  = 0.0;
  _mpu_prevRate  = 0.0;
  _mpu_stillCnt  = 0;
  _mpu_lastUs    = micros();
}

inline float mpu_getYawRaw() {
  unsigned long now = micros();
  float dt = (now - _mpu_lastUs) / 1000000.0f;
  _mpu_lastUs = now;
  if (dt < 0)     dt = 0;
  if (dt > 0.05f) dt = 0.05f;   // clamp ไม่ทิ้ง integration

  // ── ③ Motor Gating — รับ flag จาก ao() ─────────────────────────
  if (_motor_ao_called) {
    _motor_ao_called = false;   // clear flag
    _mpu_gateFlag    = true;    // trigger ZUPT เร็ว
  }

  float ax, ay, az, gx, gy, gzRaw;
  _mpu_readAll(ax, ay, az, gx, gy, gzRaw);

  // ── ⑦ Thermal drift compensation ─────────────────────────────
  //    ปรับ effective bias ตาม ΔT (ไม่แก้ _mpu_gyroZbias ตรง ๆ กัน Kalman ชน)
  float thermalOffset = 0.0f;
#if MPU_THERMAL_ENABLE
  thermalOffset = (_mpu_tempC - _mpu_tempRef) * MPU_THERMAL_COEFF * _MPU_LSB_DPS;
#endif

  float errZ  = gzRaw - _mpu_gyroZbias - thermalOffset;   // LSB
  float rateZ = errZ / _MPU_LSB_DPS;                      // deg/s (raw — ใช้ integration)

  // ── ② IIR filter บน rateZ — ใช้เฉพาะ still-detection, ไม่ใช้ integration ──
  //    α=0.65 → lag ~2 samples (~8ms) ยอมรับได้สำหรับ detect นิ่ง
  _mpu_rateFilt = 0.65f * _mpu_rateFilt + 0.35f * rateZ;

  // ── ① Still detection ด้วย filtered rate (stable กว่า raw) ──────
  float accMag = sqrtf(ax*ax + ay*ay + az*az);
  bool still = (fabsf(gx)          < _mpu_stillThresh) &&   // gx in deg/s
               (fabsf(gy)          < _mpu_stillThresh) &&   // gy in deg/s
               (fabsf(_mpu_rateFilt) < _mpu_stillThresh) && // filtered gz
               (fabsf(accMag - 1.0f) < MPU_STILL_ACC);

  // ── ③ Motor Gating — ao() set flag → เร่ง ZUPT ─────────────────
  int holdNeeded = _mpu_gateFlag ? MPU_GATE_HOLD : MPU_STILL_HOLD;

  if (still) {
    if (_mpu_stillCnt < 100000) _mpu_stillCnt++;
  } else {
    _mpu_stillCnt = 0;
    _mpu_gateFlag = false;   // รีเซต gate เมื่อตรวจพบยังขยับ
  }
  _mpu_stationary = (_mpu_stillCnt >= holdNeeded);

  if (_mpu_stationary && _mpu_gateFlag) _mpu_gateFlag = false;  // clear หลัง ZUPT สำเร็จ

  // ── ⑥ Kalman Bias Update ─────────────────────────────────────
  //    นิ่ง  → update (observation = gzRaw ควรเป็น bias ถ้าหยุด)
  //    ขยับ → predict only (P โต → K จะใหญ่ขึ้นรอบหน้า)
  if (_mpu_stationary) {
    float K = _mpu_kalmanP / (_mpu_kalmanP + MPU_KALMAN_R);   // Kalman gain
    _mpu_gyroZbias += K * errZ;                                // update
    _mpu_kalmanP    = (1.0f - K) * _mpu_kalmanP + MPU_KALMAN_Q;  // covariance update
    rateZ = 0.0f;   // บังคับ rate=0 ขณะนิ่ง กันนอยส์รั่ว
  } else {
    _mpu_kalmanP += MPU_KALMAN_Q;   // predict — P โตขึ้นเรื่อย ๆ ขณะเคลื่อน
  }

  float rate = rateZ * MPU_YAW_SIGN;

  // ── ④ Trapezoidal integration (raw rate — ไม่มี lag) ────────────
  _mpu_yawAccum += (double)(0.5f * (rate + _mpu_prevRate)) * dt;
  _mpu_prevRate  = rate;

  double y = fmod(_mpu_yawAccum, 360.0);
  if (y < 0) y += 360.0;
  return (float)y;
}

// ── Debug / OLED helpers ─────────────────────────────────────
inline bool  mpu_isStationary()  { return _mpu_stationary; }
inline float mpu_getBias()       { return _mpu_gyroZbias / _MPU_LSB_DPS; }  // deg/s
inline float mpu_getTemp()       { return _mpu_tempC; }                      // °C
inline float mpu_getKalmanP()    { return _mpu_kalmanP; }    // covariance (debug)
inline float mpu_getStillThresh(){ return _mpu_stillThresh; } // adaptive threshold (deg/s)
inline bool  mpu_isGated()       { return _mpu_gateFlag; }   // gate flag active?

// โบนัส: roll/pitch จาก accel (ไม่ดริฟต์) — yaw ใช้ไม่ได้
inline void mpu_getRollPitch(float &roll, float &pitch) {
  float ax, ay, az, gx, gy, gz;
  _mpu_readAll(ax, ay, az, gx, gy, gz);
  roll  = atan2(ay, az) * 57.2958f;
  pitch = atan2(-ax, sqrt(ay*ay + az*az)) * 57.2958f;
}