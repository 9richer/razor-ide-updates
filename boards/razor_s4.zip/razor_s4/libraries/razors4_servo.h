#pragma once
#include <Servo.h>

// ══════════════════════════════════════════════════════════════
//  RazorS4 — Servo Library
//
//  Pin ที่ใช้ได้: 4, 5, 6, 7, 8
//  รองรับ servo สูงสุด 10 ตัวพร้อมกัน
//
//  ใช้งาน:
//    servo(pin, angle, speed)  → หมุนนุ่ม ปรับความเร็วได้
//    servoFast(pin, angle)     → ยิงทันที
// ══════════════════════════════════════════════════════════════

#define MAX_SERVO 10

static Servo _servoList[MAX_SERVO];
static int   _attachedPin[MAX_SERVO];
static int   _currentAngle[MAX_SERVO];
static int   _servoCount = 0;

// ── หา index จาก pin ─────────────────────────────────────────
inline int _findServoIndex(int pin) {
  for (int i = 0; i < _servoCount; i++) {
    if (_attachedPin[i] == pin) return i;
  }
  return -1;
}

// ── init servo ถ้ายังไม่เคยใช้ ───────────────────────────────
inline int _initServo(int pin) {
  int index = _findServoIndex(pin);
  if (index == -1) {
    if (_servoCount >= MAX_SERVO) return -1;
    _servoList[_servoCount].attach(pin);
    _attachedPin[_servoCount]  = pin;
    _currentAngle[_servoCount] = 90;
    _servoList[_servoCount].write(90);
    index = _servoCount++;
  }
  return index;
}

// ══════════════════════════════════════════════════════════════
//  servo — หมุนนุ่ม ปรับความเร็วได้
//
//  pin        : ขา GPIO (4-8)
//  angle      : มุมเป้าหมาย 0–180
//  speedDelay : หน่วง ms ต่อ 1° (1=เร็ว, 20=ช้า)  default=10
// ══════════════════════════════════════════════════════════════
inline void servo(int pin, int angle, int speedDelay = 10) {
  int index = _initServo(pin);
  if (index == -1) return;

  angle      = constrain(angle, 0, 180);
  speedDelay = constrain(speedDelay, 1, 50);

  int angleNow = _currentAngle[index];

  if (angleNow < angle) {
    for (int a = angleNow; a <= angle; a++) {
      _servoList[index].write(a);
      delay(speedDelay);
    }
  } else {
    for (int a = angleNow; a >= angle; a--) {
      _servoList[index].write(a);
      delay(speedDelay);
    }
  }
  _currentAngle[index] = angle;
}

// ══════════════════════════════════════════════════════════════
//  servoFast — ยิงทันที ไม่ไล่มุม
//
//  pin   : ขา GPIO (4-8)
//  angle : มุมเป้าหมาย 0–180
// ══════════════════════════════════════════════════════════════
inline void servoFast(int pin, int angle) {
  int index = _initServo(pin);
  if (index == -1) return;

  angle = constrain(angle, 0, 180);
  _servoList[index].write(angle);
  _currentAngle[index] = angle;
}
