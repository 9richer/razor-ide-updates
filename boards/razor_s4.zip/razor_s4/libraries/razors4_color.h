#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <EEPROM.h>

// ══════════════════════════════════════════════════════════════
//  RazorS4 — TCS34725 Color Sensor (อ่านสีพื้น)
//
//  ต่อสาย (ใช้บัส I2C เดียวกับ OLED = Wire1):
//    SDA → GP26
//    SCL → GP27
//    VIN → 3V3 (หรือ 5V ก็ได้ บอร์ด Adafruit มี regulator)
//    GND → GND
//    LED → ปล่อยลอย = ไฟขาวติดตลอด (ดีสำหรับอ่านพื้น)
//          ถ้าอยากปิดไฟ ต่อ LED ลง GND
//
//  I2C address 0x29  (ไม่ชนกับ OLED 0x3C / IMU 0x68)
//
//  วิธีใช้:
//    tcs_begin();                     // ใน setup() หลัง razors4()
//    tcs_readRaw(r,g,b,c);            // อ่านค่าดิบ 16-bit
//    tcs_readHSV(h,s,v);              // h:0-360  s,v:0-100
//    tcs_teach(slot, "RED");          // สอนสีเข้าช่อง 0-7
//    int id = tcs_readColor();        // คืน slot ที่ใกล้สุด / -1=ไม่รู้จัก
//    tcs_colorName(id);               // คืนชื่อสีที่สอนไว้
// ══════════════════════════════════════════════════════════════

#define TCS_WIRE      Wire1
#define TCS_SDA       26
#define TCS_SCL       27
#define TCS_ADDR      0x29

// ── register ───────────────────────────────────────────────
#define TCS_CMD       0x80      // command bit
#define TCS_AUTOINC   0x20      // auto-increment (อ่านหลาย reg รวด)
#define TCS_ENABLE    0x00
#define   TCS_PON     0x01      // power on
#define   TCS_AEN     0x02      // ADC enable
#define TCS_ATIME     0x01      // integration time
#define TCS_CONTROL   0x0F      // gain
#define TCS_ID        0x12
#define TCS_CDATAL    0x14      // Clear low byte (R,G,B ตามมา)

// ── distance threshold สำหรับ "ไม่รู้จักสี" ────────────────
// ถ้าสีที่อ่านได้ห่างจากทุกสีที่สอนไว้เกินค่านี้ → คืน -1
// ระยะวัดใน space 4 มิติ: chromaticity(rf,gf,bf) + luminance(L)
// (ปรับบนหุ่นจริง: เล็ก=เข้มงวด · ใหญ่=ยอมรับง่าย)
static float _tcsRejectDist = 0.35f;   // 0.0-2.0 (ปรับได้)

// น้ำหนักของแกนความสว่าง L ในการวัดระยะ
//   chromaticity ทนแสง (แยกสีมีสี) · L ใช้แยก ขาว/ดำ/เทา ที่ chromaticity แยกไม่ได้
#define TCS_LUM_WEIGHT  1.0f

// ── ตารางสีที่สอนไว้ ───────────────────────────────────────
//   r,g,b : chromaticity = ช่อง/(R+G+B)   (0-1, ทนแสง)
//   L     : ความสว่างเทียบขาว = Clear/Clear-ของขาว (0-~1.27, ใช้แยกขาว/ดำ)
struct TcsColor {
  bool   used;
  float  r, g, b;       // chromaticity normalize ด้วย (R+G+B)
  float  L;             // luminance ratio เทียบ white reference
  char   name[10];
};
static TcsColor _tcsTable[8];

// ── white reference (ค่าของพื้น "ขาว") ─────────────────────────
//   ตั้งค่าตอนสอน slot 0 (WHITE); ก่อนสอน = เต็มสเกล ADC (ค่า default)
//   C ใช้เป็นตัวหารของ L · R/G/B ใช้สเกล tcs_r()/g()/b() ให้ขาว≈255
static uint16_t _tcsWhiteC   = 21504;   // Clear ของพื้นขาว
static uint16_t _tcsWhiteR   = 21504;   // R ของพื้นขาว
static uint16_t _tcsWhiteG   = 21504;   // G ของพื้นขาว
static uint16_t _tcsWhiteB   = 21504;   // B ของพื้นขาว
static uint16_t _tcsFullScale = 21504;  // เต็มสเกล ADC ตาม integration time

// ── คิด luminance ratio (clamp ให้เก็บเป็น uint8 ×200 ได้) ──
static inline float _tcsLum(uint16_t c) {
  uint16_t ref = (_tcsWhiteC < 1) ? 1 : _tcsWhiteC;
  float x = (float)c / (float)ref;
  return (x > 1.27f) ? 1.27f : x;
}

// ── เขียน register ─────────────────────────────────────────
inline void _tcsWrite(uint8_t reg, uint8_t val) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | reg);
  TCS_WIRE.write(val);
  TCS_WIRE.endTransmission();
}

inline uint8_t _tcsRead8(uint8_t reg) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | reg);
  TCS_WIRE.endTransmission();
  TCS_WIRE.requestFrom(TCS_ADDR, 1);
  return TCS_WIRE.read();
}

// ══════════════════════════════════════════════════════════════
//  เริ่มต้นเซนเซอร์ — เรียกใน setup() หลัง razors4()
//  คืน true ถ้าเจอเซนเซอร์
//
//  integ : integration time 0-255 (มาก=ไวแสง+ช้า)
//          ค่าจริง = (256-integ)*2.4ms   เช่น 0xEB = 50ms (แนะนำ)
//  gain  : 0=1x  1=4x  2=16x  3=60x   (พื้นมืดใช้ gain สูง)
// ══════════════════════════════════════════════════════════════
inline bool tcs_begin(uint8_t integ = 0xEB, uint8_t gain = 0x01) {
  TCS_WIRE.setSDA(TCS_SDA);
  TCS_WIRE.setSCL(TCS_SCL);
  TCS_WIRE.begin();

  // เช็ค ID (0x44=TCS34725, 0x4D=TCS34727)
  uint8_t id = _tcsRead8(TCS_ID);
  if (id != 0x44 && id != 0x4D && id != 0x10) return false;

  _tcsWrite(TCS_ATIME, integ);
  _tcsWrite(TCS_CONTROL, gain);
  _tcsWrite(TCS_ENABLE, TCS_PON);
  delay(3);
  _tcsWrite(TCS_ENABLE, TCS_PON | TCS_AEN);
  delay(50);

  // เต็มสเกล Clear ตาม integration time = (256-integ)*1024 (สูงสุด 65535)
  uint32_t fs = (uint32_t)(256 - integ) * 1024UL;
  if (fs > 65535UL) fs = 65535UL;
  if (fs < 1UL)     fs = 1UL;
  _tcsFullScale = (uint16_t)fs;
  _tcsWhiteC = _tcsWhiteR = _tcsWhiteG = _tcsWhiteB = (uint16_t)fs;  // default จนกว่าจะสอน WHITE

  for (int i = 0; i < 8; i++) _tcsTable[i].used = false;
  return true;
}

// ══════════════════════════════════════════════════════════════
//  อ่านค่าดิบ 16-bit (r,g,b,c)
// ══════════════════════════════════════════════════════════════
inline void tcs_readRaw(uint16_t &r, uint16_t &g, uint16_t &b, uint16_t &c) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | TCS_AUTOINC | TCS_CDATAL);
  TCS_WIRE.endTransmission();
  TCS_WIRE.requestFrom(TCS_ADDR, 8);

  // อ่านลงตัวแปรชั่วคราวก่อน — ห้าม read()|(read()<<8) ในบรรทัดเดียว
  // เพราะลำดับเรียก read() สองตัวใน C++ ไม่ถูกกำหนด (อาจสลับ low/high byte)
  uint8_t cl = TCS_WIRE.read(), ch = TCS_WIRE.read();
  uint8_t rl = TCS_WIRE.read(), rh = TCS_WIRE.read();
  uint8_t gl = TCS_WIRE.read(), gh = TCS_WIRE.read();
  uint8_t bl = TCS_WIRE.read(), bh = TCS_WIRE.read();
  c = (uint16_t)cl | ((uint16_t)ch << 8);   // TCS34725 ส่ง low byte ก่อน
  r = (uint16_t)rl | ((uint16_t)rh << 8);
  g = (uint16_t)gl | ((uint16_t)gh << 8);
  b = (uint16_t)bl | ((uint16_t)bh << 8);
}

// ── อ่านแบบเฉลี่ยหลายครั้ง (กันค่าแกว่งตอนหุ่นสั่น) ────────
inline void tcs_readAvg(uint16_t &r, uint16_t &g, uint16_t &b, uint16_t &c, int n = 5) {
  uint32_t sr = 0, sg = 0, sb = 0, sc = 0;
  uint16_t tr, tg, tb, tc;
  for (int i = 0; i < n; i++) {
    tcs_readRaw(tr, tg, tb, tc);
    sr += tr; sg += tg; sb += tb; sc += tc;
    delay(2);
  }
  r = sr / n; g = sg / n; b = sb / n; c = sc / n;
}

// ══════════════════════════════════════════════════════════════
//  แปลงเป็น HSV
//    h : 0-360   s : 0-100   v : 0-100
//  ใช้ Hue แยกสี / Saturation เช็คขาว(ต่ำ) / Value เช็คดำ(ต่ำ)
// ══════════════════════════════════════════════════════════════
inline void tcs_readHSV(float &h, float &s, float &v, int n = 5) {
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, n);

  // normalize ด้วย Clear เพื่อตัดผลของความสว่าง
  float rf = (c > 0) ? (float)r / c : 0;
  float gf = (c > 0) ? (float)g / c : 0;
  float bf = (c > 0) ? (float)b / c : 0;

  float mx = max(rf, max(gf, bf));
  float mn = min(rf, min(gf, bf));
  float d  = mx - mn;

  // Hue
  if (d < 1e-6f)        h = 0;
  else if (mx == rf)    h = 60.0f * fmodf((gf - bf) / d, 6.0f);
  else if (mx == gf)    h = 60.0f * (((bf - rf) / d) + 2.0f);
  else                  h = 60.0f * (((rf - gf) / d) + 4.0f);
  if (h < 0) h += 360.0f;

  // Saturation
  s = (mx <= 0) ? 0 : (d / mx) * 100.0f;

  // Value — ใช้ Clear เทียบกับ "ขาว" เป็นความสว่าง 0-100 (ยิ่งดำยิ่งต่ำ)
  //   ขาว ~100 · ดำ ~0  (white reference ตั้งตอนสอน slot 0)
  v = constrain((float)c / (float)((_tcsWhiteC < 1) ? 1 : _tcsWhiteC) * 100.0f,
                0.0f, 100.0f);
}

// ══════════════════════════════════════════════════════════════
//  TEACH — สอนสีหน้างาน (วางเซนเซอร์บนสีจริง แล้วเรียก)
//    slot : 0-7   name : ชื่อสั้นๆ <=9 ตัวอักษร เช่น "RED"
//  ⚠ ต้องสอน slot 0 = WHITE ก่อนเสมอ — ใช้เป็นค่าอ้างอิงแสง (L)
//    ถ้าไม่สอนขาว จะใช้เต็มสเกล ADC แทน (แยกขาว/ดำได้หยาบกว่า)
// ══════════════════════════════════════════════════════════════
inline void tcs_teach(int slot, const char *name) {
  if (slot < 0 || slot > 7) return;
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, 10);

  // slot 0 = WHITE → ตั้งเป็น white reference สำหรับแกนความสว่าง L
  // ถ้าสอนสีอื่นไว้ก่อนแล้วค่อยสอนขาว → rescale L เก่าให้อิง reference ใหม่
  // (ลบความขึ้นกับ "ลำดับการสอน" เวลาใช้บล็อก สอนสี ทีละช่อง)
  if (slot == 0) {
    uint16_t oldRef = (_tcsWhiteC < 1) ? 1 : _tcsWhiteC;
    _tcsWhiteC = (c < 1) ? 1 : c;
    _tcsWhiteR = (r < 1) ? 1 : r;     // เก็บ R/G/B ของขาว ไว้สเกล tcs_r/g/b → 0-255
    _tcsWhiteG = (g < 1) ? 1 : g;
    _tcsWhiteB = (b < 1) ? 1 : b;
    for (int k = 1; k < 8; k++) {
      if (!_tcsTable[k].used) continue;
      float Lr = _tcsTable[k].L * ((float)oldRef / (float)_tcsWhiteC);
      _tcsTable[k].L = (Lr > 1.27f) ? 1.27f : Lr;
    }
  }

  float sum = r + g + b;
  if (sum < 1) sum = 1;
  _tcsTable[slot].used = true;
  _tcsTable[slot].r = r / sum;
  _tcsTable[slot].g = g / sum;
  _tcsTable[slot].b = b / sum;
  _tcsTable[slot].L = _tcsLum(c);
  strncpy(_tcsTable[slot].name, name, 9);
  _tcsTable[slot].name[9] = '\0';
}

// ══════════════════════════════════════════════════════════════
//  อ่านสีปัจจุบัน → คืน slot ที่ใกล้ที่สุด (-1 = ไม่รู้จัก)
//  เทียบใน space 4 มิติ: chromaticity(rf,gf,bf) + luminance(L)
//    chromaticity → แยกสีมีสี (ทนแสง)
//    L            → แยก ขาว/ดำ/เทา ที่ chromaticity ทับกันสนิท
// ══════════════════════════════════════════════════════════════
inline int tcs_readColor() {
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, 5);

  float sum = r + g + b;
  if (sum < 1) sum = 1;
  float rf = r / sum, gf = g / sum, bf = b / sum;
  float L  = _tcsLum(c);

  int   best = -1;
  float bestD = 1e9;
  for (int i = 0; i < 8; i++) {
    if (!_tcsTable[i].used) continue;
    float dr = rf - _tcsTable[i].r;
    float dg = gf - _tcsTable[i].g;
    float db = bf - _tcsTable[i].b;
    float dl = L  - _tcsTable[i].L;
    float dist = sqrtf(dr * dr + dg * dg + db * db + TCS_LUM_WEIGHT * dl * dl);
    if (dist < bestD) { bestD = dist; best = i; }
  }

  if (bestD > _tcsRejectDist) return -1;   // ไกลเกินไป = ไม่รู้จัก
  return best;
}

// ── คืนชื่อสีจาก slot ────────────────────────────────────────
inline const char* tcs_colorName(int slot) {
  if (slot < 0 || slot > 7 || !_tcsTable[slot].used) return "?";
  return _tcsTable[slot].name;
}

// ── ปรับความเข้มงวดในการตัดสิน (เล็ก=เข้มงวด) ──────────────
inline void tcs_setReject(float d) { _tcsRejectDist = d; }

// ══════════════════════════════════════════════════════════════
//  ฟังก์ชันอ่านค่าเดี่ยว (ไว้ทำบล็อกค่า / debug บน OLED)
// ══════════════════════════════════════════════════════════════
inline int tcs_hue() { float h, s, v; tcs_readHSV(h, s, v, 3); return (int)h; }
inline int tcs_sat() { float h, s, v; tcs_readHSV(h, s, v, 3); return (int)s; }
inline int tcs_clear() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return c; }

// ── R/G/B สเกล 0-255 (เทียบกับพื้นขาว: ขาว≈255 ดำ≈0 แดง≈255,น้อย,น้อย) ──
//   สอน WHITE (slot 0) ก่อน เพื่อให้ขาว = 255 จริง · ถ้ายังไม่สอน เทียบกับเต็มสเกล ADC
static inline int _tcsScale255(uint16_t v, uint16_t wref) {
  if (wref < 1) wref = 1;
  long s = (long)v * 255L / (long)wref;
  if (s < 0)   s = 0;
  if (s > 255) s = 255;
  return (int)s;
}
inline int tcs_r() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return _tcsScale255(r, _tcsWhiteR); }
inline int tcs_g() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return _tcsScale255(g, _tcsWhiteG); }
inline int tcs_b() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return _tcsScale255(b, _tcsWhiteB); }

// ── Lux (ความสว่างโดยประมาณ) — สูตร Adafruit จากค่าดิบ R,G,B ──
//   เป็นค่าเชิงเปรียบเทียบ (ไม่ใช่ลักซ์คาลิเบรตเป๊ะ) · มาก=สว่าง
inline int tcs_lux() {
  uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3);
  float lux = (-0.32466f * r) + (1.57837f * g) + (-0.73191f * b);
  return (lux < 0) ? 0 : (int)lux;
}

// ══════════════════════════════════════════════════════════════
//  EEPROM — บันทึก/โหลดค่าสี (ไม่ชนกับเซนเซอร์อื่นของบอร์ด)
//
//  แผนผัง EEPROM ของบอร์ด (ทุกตัวต้องใช้ size เดียวกัน = 256):
//    0  – 31  : Line sensor  (CalibrationData)
//    32 – 63  : IMU scale    (_IcmScaleEE)
//    64 – 127 : Color sensor (TcsCalEE)  ← ของเรา
//
//  ⚠ RP2040: commit() ลบทั้ง sector แล้วเขียนกลับแค่ size ไบต์
//     จึงต้องตั้ง EEPROM size = 256 ให้ตรงกันทั้ง line/imu/color
//     (แก้ใน razors4_linesensor.h และ imu_icm20948.h เป็น 256 แล้ว)
// ══════════════════════════════════════════════════════════════
#define TCS_EE_SIZE   256
#define TCS_EE_ADDR   64          // ออฟเซ็ตของบล็อกสี (ไม่ชน line 0-31 / imu 32-37)
#define TCS_EE_MAGIC  0xC01C      // sentinel (รูปแบบ v3: +white R/G/B สำหรับ tcs_r/g/b)

// เก็บแบบกะทัดรัด: chromaticity r,g,b → uint8 (×255) · L → uint8 (×200)
//   + white reference C,R,G,B (uint16) รวม 50 ไบต์ (64..113 ไม่ชนเซนเซอร์อื่น)
struct TcsCalEE {
  uint16_t magic;
  uint16_t cwhite;          // white reference Clear (ตัวหารของ L)
  uint16_t wr, wg, wb;      // white reference R/G/B (ตัวสเกลของ tcs_r/g/b → 0-255)
  uint8_t  used[8];
  uint8_t  r[8], g[8], b[8];
  uint8_t  L[8];
};

// ชื่อสีมาตรฐานตาม slot (ตรงกับ dropdown ในบล็อก)
static const char* _TCS_STD_NAME[8] =
  { "WHITE","RED","GREEN","BLUE","YELLOW","BLACK","C6","C7" };

// ── บันทึกค่าสีปัจจุบันลง EEPROM ──────────────────────────────
inline void tcs_saveCal() {
  TcsCalEE ee;
  ee.magic  = TCS_EE_MAGIC;
  ee.cwhite = _tcsWhiteC;
  ee.wr = _tcsWhiteR; ee.wg = _tcsWhiteG; ee.wb = _tcsWhiteB;
  for (int i = 0; i < 8; i++) {
    ee.used[i] = _tcsTable[i].used ? 1 : 0;
    ee.r[i] = (uint8_t)constrain(_tcsTable[i].r * 255.0f, 0, 255);
    ee.g[i] = (uint8_t)constrain(_tcsTable[i].g * 255.0f, 0, 255);
    ee.b[i] = (uint8_t)constrain(_tcsTable[i].b * 255.0f, 0, 255);
    ee.L[i] = (uint8_t)constrain(_tcsTable[i].L * 200.0f, 0, 255);
  }
  EEPROM.begin(TCS_EE_SIZE);     // อ่านทั้ง sector เข้า buffer (กันลบของ line/imu)
  EEPROM.put(TCS_EE_ADDR, ee);
  EEPROM.commit();
  EEPROM.end();
}

// ── โหลดค่าสีจาก EEPROM → คืน true ถ้ามีค่าบันทึกไว้ ──────────
inline bool tcs_loadCal() {
  TcsCalEE ee;
  EEPROM.begin(TCS_EE_SIZE);
  EEPROM.get(TCS_EE_ADDR, ee);
  EEPROM.end();

  if (ee.magic != TCS_EE_MAGIC) return false;   // ยังไม่เคยบันทึก (หรือรูปแบบเก่า)

  _tcsWhiteC = (ee.cwhite < 1) ? _tcsFullScale : ee.cwhite;
  _tcsWhiteR = (ee.wr < 1) ? _tcsFullScale : ee.wr;
  _tcsWhiteG = (ee.wg < 1) ? _tcsFullScale : ee.wg;
  _tcsWhiteB = (ee.wb < 1) ? _tcsFullScale : ee.wb;
  for (int i = 0; i < 8; i++) {
    _tcsTable[i].used = ee.used[i] != 0;
    _tcsTable[i].r = ee.r[i] / 255.0f;
    _tcsTable[i].g = ee.g[i] / 255.0f;
    _tcsTable[i].b = ee.b[i] / 255.0f;
    _tcsTable[i].L = ee.L[i] / 200.0f;
    strncpy(_tcsTable[i].name, _TCS_STD_NAME[i], 9);
    _tcsTable[i].name[9] = '\0';
  }
  return true;
}

// ── มีค่าสีบันทึกใน EEPROM ไหม (ไม่โหลด) ──────────────────────
inline bool tcs_hasCal() {
  TcsCalEE ee;
  EEPROM.begin(TCS_EE_SIZE);
  EEPROM.get(TCS_EE_ADDR, ee);
  EEPROM.end();
  return ee.magic == TCS_EE_MAGIC;
}

// ══════════════════════════════════════════════════════════════
//  Boot-hold — ตรวจว่ากดปุ่ม SW10 "ค้าง" ตอนเปิดเครื่องไหม
//  ใช้แยกโหมด: กดค้างตอนเปิด = เข้าโหมดสอนสี (ทำตอนซ้อม)
//             ไม่กด = โหมดแข่ง (โหลด EEPROM แล้วรอกดเริ่มครั้งเดียว)
//  *** ปุ่มเริ่มแข่งเป็นการ "แตะครั้งเดียวหลังเปิด" คนละจังหวะกัน ***
// ══════════════════════════════════════════════════════════════
inline bool tcs_bootHeld(int holdMs = 1200) {
  pinMode(10, INPUT_PULLUP);
  if (digitalRead(10) != LOW) return false;      // ไม่ได้กดตอนเปิด
  unsigned long t = millis();
  while (digitalRead(10) == LOW) {               // ต้องกดค้างครบเวลา
    if (millis() - t >= (unsigned long)holdMs) return true;
  }
  return false;                                  // ปล่อยก่อน = ไม่นับ
}

// ══════════════════════════════════════════════════════════════
//  teachAll — สอนสีทั้งชุด + บันทึก EEPROM (ใช้ในโหมดสอน/ซ้อม)
//  วางเซนเซอร์บนแต่ละสี แล้วกด SW10 ทีละสี (WHITE→RED→GREEN→...)
//  count : จำนวนสีที่จะสอน (เริ่ม 5 = ขาว/แดง/เขียว/น้ำเงิน/เหลือง)
//  ต้องมี display (OLED) จาก myoled.h พร้อมใช้
// ══════════════════════════════════════════════════════════════
inline void tcs_teachAll(int count = 6) {
  if (count < 1) count = 1; if (count > 8) count = 8;
  pinMode(10, INPUT_PULLUP);
  pinMode(9, OUTPUT);

  for (int i = 0; i < count; i++) {
    display.clearDisplay();
    display.setTextSize(1); display.setCursor(0, 0);
    display.println("TEACH MODE");
    display.setCursor(0, 16); display.print("Put on: ");
    display.setTextSize(2); display.setCursor(0, 28);
    display.println(_TCS_STD_NAME[i]);
    display.setTextSize(1); display.setCursor(0, 52);
    display.println("press SW10...");
    display.display();

    while (digitalRead(10) != LOW) delay(8);     // รอกดปุ่ม
    delay(150);
    tcs_teach(i, _TCS_STD_NAME[i]);              // เก็บสีนี้
    tone(9, 1000); delay(120); noTone(9);

    display.clearDisplay(); display.setCursor(20, 24);
    display.println("Saved!"); display.display();
    delay(300);
    while (digitalRead(10) == LOW) delay(8);     // รอปล่อยปุ่ม
  }

  tcs_saveCal();                                 // บันทึกลง EEPROM
  display.clearDisplay(); display.setCursor(0, 20);
  display.println("TEACH DONE -> SAVED"); display.setCursor(0, 36);
  display.println("Power cycle to RUN"); display.display();
  tone(9, 1500); delay(150); noTone(9); delay(100);
  tone(9, 1500); delay(150); noTone(9);
  while (true) delay(100);                       // หยุด ไม่ให้วิ่งต่อโดยบังเอิญ
}

// ══════════════════════════════════════════════════════════════
//  คาลิเบรตสี (บล็อกเดียวจบ) — ใส่ใน Setup
//    • กดปุ่ม SW10 "ค้าง" ตอนเปิด = สอนสีทุกสี + เซฟ EEPROM (ตอนทดสอบสนาม)
//    • เปิดเครื่องปกติ          = โหลดสีที่เซฟไว้มาใช้ (ตอนแข่ง)
//  วันแข่งจึงแค่เปิดเครื่อง โหลดเอง แล้วกดเริ่มครั้งเดียว ไม่มีสอนคั่น
// ══════════════════════════════════════════════════════════════
inline void tcs_calibrate(int count = 6) {
  if (tcs_bootHeld()) {
    tcs_teachAll(count);                      // กดค้าง = สอน + เซฟ + หยุด
  } else if (!tcs_loadCal()) {
    // โหลดไม่สำเร็จ = ยังไม่เคยสอน หรืออัปเดตเฟิร์มแวร์แล้วรูปแบบ EEPROM เปลี่ยน
    // เตือนให้รู้ตัว — ไม่งั้น tcs_readColor() จะคืน -1 ตลอดแบบเงียบๆ
    display.clearDisplay(); display.setTextSize(1); display.setCursor(0, 8);
    display.println("NO COLOR CAL!");
    display.setCursor(0, 26); display.println("Hold SW10 at boot");
    display.setCursor(0, 38); display.println("to TEACH colors");
    display.display();
    pinMode(9, OUTPUT);
    tone(9, 400); delay(200); noTone(9); delay(120);
    tone(9, 400); delay(200); noTone(9);
    delay(1500);                               // ให้เห็นข้อความ แล้วค่อยวิ่งต่อ
  }
}
