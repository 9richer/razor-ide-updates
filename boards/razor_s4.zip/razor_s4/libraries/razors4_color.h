#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <EEPROM.h>

// ══════════════════════════════════════════════════════════════
//  RazorS4 — TCS34725 Color Sensor (อ่านสีพื้น)
//
//  ต่อสาย (ใช้บัส I2C เดียวกับ OLED = Wire1):
//    SDA → GP26
//    SCL → GP27
//    VIN → 3V3 (หรือ 5V ก็ได้ บอร์ด Adafruit มี regulator)
//    GND → GND
//    LED → ปล่อยลอย = ไฟขาวติดตลอด (ดีสำหรับอ่านพื้น)
//          ถ้าอยากปิดไฟ ต่อ LED ลง GND
//
//  I2C address 0x29  (ไม่ชนกับ OLED 0x3C / IMU 0x68)
//
//  วิธีใช้:
//    tcs_begin();                     // ใน setup() หลัง razors4()
//    tcs_readRaw(r,g,b,c);            // อ่านค่าดิบ 16-bit
//    tcs_readHSV(h,s,v);              // h:0-360  s,v:0-100
//    tcs_teach(slot, "RED");          // สอนสีเข้าช่อง 0-7
//    int id = tcs_readColor();        // คืน slot ที่ใกล้สุด / -1=ไม่รู้จัก
//    tcs_colorName(id);               // คืนชื่อสีที่สอนไว้
// ══════════════════════════════════════════════════════════════

#define TCS_WIRE      Wire1
#define TCS_SDA       26
#define TCS_SCL       27
#define TCS_ADDR      0x29

// ── register ───────────────────────────────────────────────
#define TCS_CMD       0x80      // command bit
#define TCS_AUTOINC   0x20      // auto-increment (อ่านหลาย reg รวด)
#define TCS_ENABLE    0x00
#define   TCS_PON     0x01      // power on
#define   TCS_AEN     0x02      // ADC enable
#define TCS_ATIME     0x01      // integration time
#define TCS_CONTROL   0x0F      // gain
#define TCS_ID        0x12
#define TCS_CDATAL    0x14      // Clear low byte (R,G,B ตามมา)

// ── distance threshold สำหรับ "ไม่รู้จักสี" ────────────────
// ถ้าสีที่อ่านได้ห่างจากทุกสีที่สอนไว้เกินค่านี้ → คืน -1
static float _tcsRejectDist = 0.20f;   // 0.0-1.0 (ปรับได้)

// ── ตารางสีที่สอนไว้ (normalize r,g,b 0.0-1.0) ─────────────
struct TcsColor {
  bool   used;
  float  r, g, b;       // normalize ด้วย (R+G+B)
  char   name[10];
};
static TcsColor _tcsTable[8];

// ── เขียน register ─────────────────────────────────────────
inline void _tcsWrite(uint8_t reg, uint8_t val) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | reg);
  TCS_WIRE.write(val);
  TCS_WIRE.endTransmission();
}

inline uint8_t _tcsRead8(uint8_t reg) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | reg);
  TCS_WIRE.endTransmission();
  TCS_WIRE.requestFrom(TCS_ADDR, 1);
  return TCS_WIRE.read();
}

// ══════════════════════════════════════════════════════════════
//  เริ่มต้นเซนเซอร์ — เรียกใน setup() หลัง razors4()
//  คืน true ถ้าเจอเซนเซอร์
//
//  integ : integration time 0-255 (มาก=ไวแสง+ช้า)
//          ค่าจริง = (256-integ)*2.4ms   เช่น 0xEB = 50ms (แนะนำ)
//  gain  : 0=1x  1=4x  2=16x  3=60x   (พื้นมืดใช้ gain สูง)
// ══════════════════════════════════════════════════════════════
inline bool tcs_begin(uint8_t integ = 0xEB, uint8_t gain = 0x01) {
  TCS_WIRE.setSDA(TCS_SDA);
  TCS_WIRE.setSCL(TCS_SCL);
  TCS_WIRE.begin();

  // เช็ค ID (0x44=TCS34725, 0x4D=TCS34727)
  uint8_t id = _tcsRead8(TCS_ID);
  if (id != 0x44 && id != 0x4D && id != 0x10) return false;

  _tcsWrite(TCS_ATIME, integ);
  _tcsWrite(TCS_CONTROL, gain);
  _tcsWrite(TCS_ENABLE, TCS_PON);
  delay(3);
  _tcsWrite(TCS_ENABLE, TCS_PON | TCS_AEN);
  delay(50);

  for (int i = 0; i < 8; i++) _tcsTable[i].used = false;
  return true;
}

// ══════════════════════════════════════════════════════════════
//  อ่านค่าดิบ 16-bit (r,g,b,c)
// ══════════════════════════════════════════════════════════════
inline void tcs_readRaw(uint16_t &r, uint16_t &g, uint16_t &b, uint16_t &c) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | TCS_AUTOINC | TCS_CDATAL);
  TCS_WIRE.endTransmission();
  TCS_WIRE.requestFrom(TCS_ADDR, 8);

  c = TCS_WIRE.read() | (TCS_WIRE.read() << 8);
  r = TCS_WIRE.read() | (TCS_WIRE.read() << 8);
  g = TCS_WIRE.read() | (TCS_WIRE.read() << 8);
  b = TCS_WIRE.read() | (TCS_WIRE.read() << 8);
}

// ── อ่านแบบเฉลี่ยหลายครั้ง (กันค่าแกว่งตอนหุ่นสั่น) ────────
inline void tcs_readAvg(uint16_t &r, uint16_t &g, uint16_t &b, uint16_t &c, int n = 5) {
  uint32_t sr = 0, sg = 0, sb = 0, sc = 0;
  uint16_t tr, tg, tb, tc;
  for (int i = 0; i < n; i++) {
    tcs_readRaw(tr, tg, tb, tc);
    sr += tr; sg += tg; sb += tb; sc += tc;
    delay(2);
  }
  r = sr / n; g = sg / n; b = sb / n; c = sc / n;
}

// ══════════════════════════════════════════════════════════════
//  แปลงเป็น HSV
//    h : 0-360   s : 0-100   v : 0-100
//  ใช้ Hue แยกสี / Saturation เช็คขาว(ต่ำ) / Value เช็คดำ(ต่ำ)
// ══════════════════════════════════════════════════════════════
inline void tcs_readHSV(float &h, float &s, float &v, int n = 5) {
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, n);

  // normalize ด้วย Clear เพื่อตัดผลของความสว่าง
  float rf = (c > 0) ? (float)r / c : 0;
  float gf = (c > 0) ? (float)g / c : 0;
  float bf = (c > 0) ? (float)b / c : 0;

  float mx = max(rf, max(gf, bf));
  float mn = min(rf, min(gf, bf));
  float d  = mx - mn;

  // Hue
  if (d < 1e-6f)        h = 0;
  else if (mx == rf)    h = 60.0f * fmodf((gf - bf) / d, 6.0f);
  else if (mx == gf)    h = 60.0f * (((bf - rf) / d) + 2.0f);
  else                  h = 60.0f * (((rf - gf) / d) + 4.0f);
  if (h < 0) h += 360.0f;

  // Saturation
  s = (mx <= 0) ? 0 : (d / mx) * 100.0f;

  // Value — ใช้ Clear เทียบเป็นความสว่าง (ยิ่งดำยิ่งต่ำ)
  // อิงค่า clear สูงสุดของ integration 50ms ~ 65535; map คร่าวๆ
  v = constrain((float)c / 200.0f, 0.0f, 100.0f);
}

// ══════════════════════════════════════════════════════════════
//  TEACH — สอนสีหน้างาน (วางเซนเซอร์บนสีจริง แล้วเรียก)
//    slot : 0-7   name : ชื่อสั้นๆ <=9 ตัวอักษร เช่น "RED"
// ══════════════════════════════════════════════════════════════
inline void tcs_teach(int slot, const char *name) {
  if (slot < 0 || slot > 7) return;
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, 10);

  float sum = r + g + b;
  if (sum < 1) sum = 1;
  _tcsTable[slot].used = true;
  _tcsTable[slot].r = r / sum;
  _tcsTable[slot].g = g / sum;
  _tcsTable[slot].b = b / sum;
  strncpy(_tcsTable[slot].name, name, 9);
  _tcsTable[slot].name[9] = '\0';
}

// ══════════════════════════════════════════════════════════════
//  อ่านสีปัจจุบัน → คืน slot ที่ใกล้ที่สุด (-1 = ไม่รู้จัก)
//  เทียบด้วยระยะใน normalize-RGB space (nearest neighbor)
// ══════════════════════════════════════════════════════════════
inline int tcs_readColor() {
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, 5);

  float sum = r + g + b;
  if (sum < 1) sum = 1;
  float rf = r / sum, gf = g / sum, bf = b / sum;

  int   best = -1;
  float bestD = 1e9;
  for (int i = 0; i < 8; i++) {
    if (!_tcsTable[i].used) continue;
    float dr = rf - _tcsTable[i].r;
    float dg = gf - _tcsTable[i].g;
    float db = bf - _tcsTable[i].b;
    float dist = sqrtf(dr * dr + dg * dg + db * db);
    if (dist < bestD) { bestD = dist; best = i; }
  }

  if (bestD > _tcsRejectDist) return -1;   // ไกลเกินไป = ไม่รู้จัก
  return best;
}

// ── คืนชื่อสีจาก slot ────────────────────────────────────────
inline const char* tcs_colorName(int slot) {
  if (slot < 0 || slot > 7 || !_tcsTable[slot].used) return "?";
  return _tcsTable[slot].name;
}

// ── ปรับความเข้มงวดในการตัดสิน (เล็ก=เข้มงวด) ──────────────
inline void tcs_setReject(float d) { _tcsRejectDist = d; }

// ══════════════════════════════════════════════════════════════
//  ฟังก์ชันอ่านค่าเดี่ยว (ไว้ทำบล็อกค่า / debug บน OLED)
// ══════════════════════════════════════════════════════════════
inline int tcs_hue() { float h, s, v; tcs_readHSV(h, s, v, 3); return (int)h; }
inline int tcs_sat() { float h, s, v; tcs_readHSV(h, s, v, 3); return (int)s; }
inline int tcs_clear() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return c; }

// ══════════════════════════════════════════════════════════════
//  EEPROM — บันทึก/โหลดค่าสี (ไม่ชนกับเซนเซอร์อื่นของบอร์ด)
//
//  แผนผัง EEPROM ของบอร์ด (ทุกตัวต้องใช้ size เดียวกัน = 256):
//    0  – 31  : Line sensor  (CalibrationData)
//    32 – 63  : IMU scale    (_IcmScaleEE)
//    64 – 127 : Color sensor (TcsCalEE)  ← ของเรา
//
//  ⚠ RP2040: commit() ลบทั้ง sector แล้วเขียนกลับแค่ size ไบต์
//     จึงต้องตั้ง EEPROM size = 256 ให้ตรงกันทั้ง line/imu/color
//     (แก้ใน razors4_linesensor.h และ imu_icm20948.h เป็น 256 แล้ว)
// ══════════════════════════════════════════════════════════════
#define TCS_EE_SIZE   256
#define TCS_EE_ADDR   64          // ออฟเซ็ตของบล็อกสี (ไม่ชน line/imu)
#define TCS_EE_MAGIC  0xC01A      // sentinel = "มีค่าสีบันทึกไว้"

// เก็บแบบกะทัดรัด: normalize r,g,b → uint8 (0-255)  รวม 34 ไบต์
struct TcsCalEE {
  uint16_t magic;
  uint8_t  used[8];
  uint8_t  r[8], g[8], b[8];
};

// ชื่อสีมาตรฐานตาม slot (ตรงกับ dropdown ในบล็อก)
static const char* _TCS_STD_NAME[8] =
  { "WHITE","RED","GREEN","BLUE","YELLOW","BLACK","C6","C7" };

// ── บันทึกค่าสีปัจจุบันลง EEPROM ──────────────────────────────
inline void tcs_saveCal() {
  TcsCalEE ee;
  ee.magic = TCS_EE_MAGIC;
  for (int i = 0; i < 8; i++) {
    ee.used[i] = _tcsTable[i].used ? 1 : 0;
    ee.r[i] = (uint8_t)constrain(_tcsTable[i].r * 255.0f, 0, 255);
    ee.g[i] = (uint8_t)constrain(_tcsTable[i].g * 255.0f, 0, 255);
    ee.b[i] = (uint8_t)constrain(_tcsTable[i].b * 255.0f, 0, 255);
  }
  EEPROM.begin(TCS_EE_SIZE);     // อ่านทั้ง sector เข้า buffer (กันลบของ line/imu)
  EEPROM.put(TCS_EE_ADDR, ee);
  EEPROM.commit();
  EEPROM.end();
}

// ── โหลดค่าสีจาก EEPROM → คืน true ถ้ามีค่าบันทึกไว้ ──────────
inline bool tcs_loadCal() {
  TcsCalEE ee;
  EEPROM.begin(TCS_EE_SIZE);
  EEPROM.get(TCS_EE_ADDR, ee);
  EEPROM.end();

  if (ee.magic != TCS_EE_MAGIC) return false;   // ยังไม่เคยบันทึก

  for (int i = 0; i < 8; i++) {
    _tcsTable[i].used = ee.used[i] != 0;
    _tcsTable[i].r = ee.r[i] / 255.0f;
    _tcsTable[i].g = ee.g[i] / 255.0f;
    _tcsTable[i].b = ee.b[i] / 255.0f;
    strncpy(_tcsTable[i].name, _TCS_STD_NAME[i], 9);
    _tcsTable[i].name[9] = '\0';
  }
  return true;
}

// ── มีค่าสีบันทึกใน EEPROM ไหม (ไม่โหลด) ──────────────────────
inline bool tcs_hasCal() {
  TcsCalEE ee;
  EEPROM.begin(TCS_EE_SIZE);
  EEPROM.get(TCS_EE_ADDR, ee);
  EEPROM.end();
  return ee.magic == TCS_EE_MAGIC;
}

// ══════════════════════════════════════════════════════════════
//  Boot-hold — ตรวจว่ากดปุ่ม SW10 "ค้าง" ตอนเปิดเครื่องไหม
//  ใช้แยกโหมด: กดค้างตอนเปิด = เข้าโหมดสอนสี (ทำตอนซ้อม)
//             ไม่กด = โหมดแข่ง (โหลด EEPROM แล้วรอกดเริ่มครั้งเดียว)
//  *** ปุ่มเริ่มแข่งเป็นการ "แตะครั้งเดียวหลังเปิด" คนละจังหวะกัน ***
// ══════════════════════════════════════════════════════════════
inline bool tcs_bootHeld(int holdMs = 1200) {
  pinMode(10, INPUT_PULLUP);
  if (digitalRead(10) != LOW) return false;      // ไม่ได้กดตอนเปิด
  unsigned long t = millis();
  while (digitalRead(10) == LOW) {               // ต้องกดค้างครบเวลา
    if (millis() - t >= (unsigned long)holdMs) return true;
  }
  return false;                                  // ปล่อยก่อน = ไม่นับ
}

// ══════════════════════════════════════════════════════════════
//  teachAll — สอนสีทั้งชุด + บันทึก EEPROM (ใช้ในโหมดสอน/ซ้อม)
//  วางเซนเซอร์บนแต่ละสี แล้วกด SW10 ทีละสี (WHITE→RED→GREEN→...)
//  count : จำนวนสีที่จะสอน (เริ่ม 5 = ขาว/แดง/เขียว/น้ำเงิน/เหลือง)
//  ต้องมี display (OLED) จาก myoled.h พร้อมใช้
// ══════════════════════════════════════════════════════════════
inline void tcs_teachAll(int count = 5) {
  if (count < 1) count = 1; if (count > 8) count = 8;
  pinMode(10, INPUT_PULLUP);
  pinMode(9, OUTPUT);

  for (int i = 0; i < count; i++) {
    display.clearDisplay();
    display.setTextSize(1); display.setCursor(0, 0);
    display.println("TEACH MODE");
    display.setCursor(0, 16); display.print("Put on: ");
    display.setTextSize(2); display.setCursor(0, 28);
    display.println(_TCS_STD_NAME[i]);
    display.setTextSize(1); display.setCursor(0, 52);
    display.println("press SW10...");
    display.display();

    while (digitalRead(10) != LOW) delay(8);     // รอกดปุ่ม
    delay(150);
    tcs_teach(i, _TCS_STD_NAME[i]);              // เก็บสีนี้
    tone(9, 1000); delay(120); noTone(9);

    display.clearDisplay(); display.setCursor(20, 24);
    display.println("Saved!"); display.display();
    delay(300);
    while (digitalRead(10) == LOW) delay(8);     // รอปล่อยปุ่ม
  }

  tcs_saveCal();                                 // บันทึกลง EEPROM
  display.clearDisplay(); display.setCursor(0, 20);
  display.println("TEACH DONE -> SAVED"); display.setCursor(0, 36);
  display.println("Power cycle to RUN"); display.display();
  tone(9, 1500); delay(150); noTone(9); delay(100);
  tone(9, 1500); delay(150); noTone(9);
  while (true) delay(100);                       // หยุด ไม่ให้วิ่งต่อโดยบังเอิญ
}

// ══════════════════════════════════════════════════════════════
//  คาลิเบรตสี (บล็อกเดียวจบ) — ใส่ใน Setup
//    • กดปุ่ม SW10 "ค้าง" ตอนเปิด = สอนสีทุกสี + เซฟ EEPROM (ตอนทดสอบสนาม)
//    • เปิดเครื่องปกติ          = โหลดสีที่เซฟไว้มาใช้ (ตอนแข่ง)
//  วันแข่งจึงแค่เปิดเครื่อง โหลดเอง แล้วกดเริ่มครั้งเดียว ไม่มีสอนคั่น
// ══════════════════════════════════════════════════════════════
inline void tcs_calibrate(int count = 5) {
  if (tcs_bootHeld()) tcs_teachAll(count);   // กดค้าง = สอน + เซฟ + หยุด
  else                tcs_loadCal();          // ปกติ = โหลดของเดิมมาใช้
}
