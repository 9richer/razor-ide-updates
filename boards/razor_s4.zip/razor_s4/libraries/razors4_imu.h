#pragma once
// ══════════════════════════════════════════════════════════════
//  razors4_imu.h — ตัวสลับ IMU (เลือก BNO055 หรือ MPU6050 ตอนรัน)
//
//  ★ ใช้แทน razors4_bno055.h (RazorS4.h include ไฟล์นี้แทน)
//
//  เลือก IMU ได้ 2 ทาง:
//    1) บล็อก "เลือก IMU" ใน Setup  → setIMU(IMU_MPU6050);  (ก่อนคาลิเบรต)
//    2) แก้ค่า default ด้านล่าง (ตัวแปร imuType)
//
//  ฟังก์ชันที่ปล่อยออก (เหมือน BNO เดิมเป๊ะ — โค้ดเก่าใช้ต่อได้ทันที):
//    initIMU() getYawRaw() getYaw() calibrateYawStart() resetYaw()
//    + ฟังก์ชันเลี้ยว/เดินทั้งหมด (spinTo, MOVE, TurnF_PID, ...)
// ══════════════════════════════════════════════════════════════

#include "imu_bno055.h"
#include "imu_bno055_zupt.h"
#include "imu_mpu6050.h"
#include "imu_bno085.h"
#include "imu_icm20948.h"

// ── ชนิด IMU ──────────────────────────────────────────────────
#define IMU_BNO055      0
#define IMU_MPU6050     1
#define IMU_BNO085      2
#define IMU_BNO085_MAG  3
#define IMU_BNO055_MAG  4
#define IMU_GY91         5   // MPU9250 — register เหมือน 6050 ใช้ไดรเวอร์เดียวกัน
#define IMU_ICM20948     6
#define IMU_BNO055_ZUPT  7   // BNO055 อ่าน gyro ดิบ + ZUPT (ข้าม fusion)

uint8_t imuType = IMU_BNO055;     // ← ค่าเริ่มต้น (เปลี่ยนได้ หรือใช้บล็อก setIMU)
float   offsetYaw = 0;            // ชื่อเดียวกับของเดิม

inline void setIMU(uint8_t t) { imuType = t; }     // บล็อก "เลือก IMU" เรียกตัวนี้

// ── ตัวสลับ — ปล่อยฟังก์ชันชื่อเดียวกับ BNO เดิม ────────────────
inline void initIMU() {
  if      (imuType == IMU_MPU6050) mpu_initIMU();
  else if (imuType == IMU_GY91)    mpu_initIMU();      // MPU9250 ใช้ไดรเวอร์เดียวกัน
  else if (imuType == IMU_ICM20948)                        icm_initIMU();
  else if (imuType == IMU_BNO055_ZUPT)                     bnoz_initIMU();
  else if (imuType == IMU_BNO085)     { _bno085_useMag = false; bno085_initIMU(); }
  else if (imuType == IMU_BNO085_MAG) { _bno085_useMag = true;  bno085_initIMU(); }
  else if (imuType == IMU_BNO055_MAG) { _bno_useMag = true;     bno_initIMU(); }
  else                             { _bno_useMag = false;        bno_initIMU(); }
}

inline float getYawRaw() {
  if      (imuType == IMU_MPU6050 || imuType == IMU_GY91) return mpu_getYawRaw();
  else if (imuType == IMU_ICM20948)                        return icm_getYawRaw();
  else if (imuType == IMU_BNO055_ZUPT)                     return bnoz_getYawRaw();
  else if (imuType == IMU_BNO085 || imuType == IMU_BNO085_MAG) return bno085_getYawRaw();
  else                             return bno_getYawRaw();
}

inline float getYaw() {
  float yaw = getYawRaw();
  yaw -= offsetYaw;
  if (yaw < 0)    yaw += 360;
  if (yaw >= 360) yaw -= 360;
  return yaw;
}

inline void calibrateYawStart() {
  // รอให้ ZUPT ทำงาน (bias settle) ก่อน capture offset
  // หุ่นต้องนิ่งอยู่แล้วตอนนี้ → รอแค่ 200ms พอ
  unsigned long t0 = millis();
  while (millis() - t0 < 200) { getYawRaw(); delay(4); }
  // เฉลี่ย 20 ครั้ง → offsetYaw
  float sum = 0;
  for (int i = 0; i < 20; i++) { sum += getYawRaw(); delay(2); }
  offsetYaw = sum / 20.0f;
}

inline void resetYaw(int samples = 10) {
  if (samples <= 1) { offsetYaw = getYawRaw(); return; }
  float sum = 0;
  for (int i = 0; i < samples; i++) { sum += getYawRaw(); delay(2); }
  offsetYaw = sum / (float)samples;
}

inline void recalibrateAxisFast() { offsetYaw = getYawRaw(); }


// ══════════════════════════════════════════════════════════════
//  ↓↓↓ ฟังก์ชัน Math + Turn/Move เดิม (ไม่ขึ้นกับชนิด IMU) ↓↓↓
//      ทุกตัวเรียก getYaw()/getYawRaw() → ทำงานกับ IMU ที่เลือกไว้
// ══════════════════════════════════════════════════════════════

inline float normalizeAngle(float angle) {
  while (angle > 180)  angle -= 360;
  while (angle <= -180) angle += 360;
  return angle;
}

inline float shortestAngle(float currentAngle, float targetAngle) {
  return fmod((targetAngle - currentAngle + 540), 360) - 180;
}


// ══════════════════════════════════════════════════════════════
//  Turn functions
// ══════════════════════════════════════════════════════════════

// เลี้ยวตามองศา PD — เลี้ยวแล้วไม่กลับมา
inline void turnByAngle(float angle, float kp, float kd, int speedMin, int speedMax) {
  float startYaw  = getYaw();
  float targetYaw = startYaw + angle;
  if (targetYaw >= 360) targetYaw -= 360;
  if (targetYaw < 0)    targetYaw += 360;

  float prevError = 0;
  unsigned long lastTime = millis();

  while (1) {
    float currentYaw = getYaw();
    float error = normalizeAngle(targetYaw - currentYaw);
    if (abs(error) < 1.5) break;

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0, 0.001);
    lastTime = now;

    float derivative = (error - prevError) / dt;
    prevError = error;

    float output = kp * error + kd * derivative;
    int speed = constrain(abs(output), speedMin, speedMax);

    if (output > 0) { motorL(speed);  motorR(-speed); }   // เลี้ยวขวา
    else            { motorL(-speed); motorR(speed);  }   // เลี้ยวซ้าย
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  spinTo config — ตั้งครั้งเดียวใน setup()
// ══════════════════════════════════════════════════════════════

struct SpinConfig {
  float kp_fast = 6.0;
  float kp_mid  = 3.5;
  float kp_slow = 1.5;
  float kd      = 0.3;
} _spinCfg;

inline void setSpinConfig(float kp_fast, float kp_mid, float kp_slow, float kd) {
  _spinCfg.kp_fast = kp_fast;
  _spinCfg.kp_mid  = kp_mid;
  _spinCfg.kp_slow = kp_slow;
  _spinCfg.kd      = kd;
}

// ══════════════════════════════════════════════════════════════
//  spinTo — เลี้ยวไปทิศที่กำหนด แม่นสุด (World Frame)
//
//  targetYaw      : ทิศเป้าหมาย (องศา)
//  errorThreshold : หยุดเมื่อ error < ค่านี้  default=1.5
//  timeout_ms     : เวลาสูงสุด ms  default=200 (ป้องกันติด loop)
//  spdMin         : ความเร็วต่ำสุด  default=40
//  spdMax         : ความเร็วสูงสุด  default=70
//
//  adaptive kp: error>30 → kp_fast, error>10 → kp_mid, อื่น → kp_slow
//  settle: ต้องนิ่ง 5 รอบติดต่อกัน (~20ms) ถึงหยุด
// ══════════════════════════════════════════════════════════════

inline void spinTo(float targetYaw,
                   float errorThreshold = 1.5,
                   int timeout_ms = 200,
                   int spdMin = 40,
                   int spdMax = 70) {

  float prevError  = 0;
  float dFilt      = 0;
  int   settleCount = 0;

  unsigned long lastTime  = millis();
  unsigned long startTime = millis();

  while (1) {

    // timeout — ป้องกันติด loop
    if ((millis() - startTime) > (unsigned long)timeout_ms) break;

    float currentYaw = getYaw();   // World Frame
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0f, 0.001f);
    lastTime = now;

    // Derivative + low-pass filter
    float derivative = (error - prevError) / dt;
    derivative = constrain(derivative, -200, 200);
    dFilt      = dFilt * 0.7 + derivative * 0.3;
    prevError  = error;

    // Adaptive kp
    float kp;
    if      (abs(error) > 30) kp = _spinCfg.kp_fast;
    else if (abs(error) > 10) kp = _spinCfg.kp_mid;
    else                      kp = _spinCfg.kp_slow;

    float output = kp * error + _spinCfg.kd * dFilt;
    int speed = constrain((int)abs(output), spdMin, spdMax);

    if (output > 0) { motorL(speed);  motorR(-speed); }
    else            { motorL(-speed); motorR(speed);  }

    // Settle counter — ต้องนิ่ง 5 รอบติดต่อกัน
    if (abs(error) < errorThreshold && abs(dFilt) < 3) {
      if (++settleCount >= 5) break;
    } else {
      settleCount = 0;
    }

    delay(4);
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  spinToB — สปินไปทิศที่กำหนด (ใช้คู่กับ calibrate หลัง=0°)
//
//  ใช้เมื่อ calibrate โดยหันหลังให้ทิศ 0° → getYaw() วัดทิศของหลัง robot
//  motor logic เหมือน spinTo ทุกอย่าง (ล้อหนึ่งหน้า ล้อหนึ่งหลัง สปินในที่)
//
//  targetYaw      : ทิศเป้าหมาย (องศา)
//  errorThreshold : หยุดเมื่อ error < ค่านี้  default=1.5
//  timeout_ms     : เวลาสูงสุด ms  default=200
//  spdMin         : ความเร็วต่ำสุด  default=40
//  spdMax         : ความเร็วสูงสุด  default=70
// ══════════════════════════════════════════════════════════════

inline void spinToB(float targetYaw,
                    float errorThreshold = 1.5,
                    int timeout_ms = 200,
                    int spdMin = 40,
                    int spdMax = 70) {

  float prevError   = 0;
  float dFilt       = 0;
  int   settleCount = 0;

  unsigned long lastTime  = millis();
  unsigned long startTime = millis();

  while (1) {

    // timeout — ป้องกันติด loop
    if ((millis() - startTime) > (unsigned long)timeout_ms) break;

    float currentYaw = getYaw();   // World Frame
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0f, 0.001f);
    lastTime = now;

    // Derivative + low-pass filter
    float derivative = (error - prevError) / dt;
    derivative = constrain(derivative, -200, 200);
    dFilt     = dFilt * 0.7 + derivative * 0.3;
    prevError = error;

    // Adaptive kp
    float kp;
    if      (abs(error) > 30) kp = _spinCfg.kp_fast;
    else if (abs(error) > 10) kp = _spinCfg.kp_mid;
    else                      kp = _spinCfg.kp_slow;

    float output = kp * error + _spinCfg.kd * dFilt;
    int speed = constrain((int)abs(output), spdMin, spdMax);

    // ล้อหนึ่งหน้า ล้อหนึ่งหลัง — สปินในที่ (เหมือน spinTo)
    // calibrate หลัง=0° → getYaw() วัดทิศหลัง → motor logic เหมือนกันเป๊ะ
    if (output > 0) { motorL(speed);  motorR(-speed); }   // CW
    else            { motorL(-speed); motorR(speed);  }   // CCW

    // Settle counter — ต้องนิ่ง 5 รอบติดต่อกัน
    if (abs(error) < errorThreshold && abs(dFilt) < 3) {
      if (++settleCount >= 5) break;
    } else {
      settleCount = 0;
    }

    delay(4);
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  TurnF_PID — ดิฟหน้า (pivot หน้า)
//  ล้อซ้ายดัน ล้อขวาหยุด → หมุนรอบล้อขวา
//
//  targetYaw      : ทิศเป้าหมาย (องศา)
//  speedMin       : ความเร็วต่ำสุด
//  speedMax       : ความเร็วสูงสุด
//  kp, kd         : PD gains
//  errorThreshold : หยุดเมื่อ error < ค่านี้ (องศา) default=5.0
//                   ค่ามาก → หยุดเร็ว/หยาบ  ค่าน้อย → แม่นแต่อาจแกว่ง
// ══════════════════════════════════════════════════════════════
inline void TurnF_PID(float targetYaw, int speedMin, int speedMax,
                      float kp, float kd, float errorThreshold = 5.0,
                      int timeout_ms = 2000) {
  float prevError = 0;
  unsigned long lastTime  = millis();
  unsigned long startTime = millis();

  while (1) {
    if ((millis() - startTime) > (unsigned long)timeout_ms) break;

    float currentYaw = getYaw();   // ← World Frame (มี offset)
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0, 0.001);
    lastTime = now;

    float derivative = (error - prevError) / dt;
    float output = kp * error + kd * derivative;
    prevError = error;

    int speed = constrain(abs(output), speedMin, speedMax);

    if (output > 0) { motorL(speed); motorR(5);     }   // หมุนขวา
    else            { motorL(5);     motorR(speed); }   // หมุนซ้าย

    if (abs(error) < errorThreshold) break;
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  TurnB_PID — ดิฟหลัง (pivot หลัง)
//  ล้อซ้ายถอย ล้อขวาหยุด → ท้ายสวิงออก
//
//  targetYaw      : ทิศเป้าหมาย (องศา)
//  speedMin       : ความเร็วต่ำสุด
//  speedMax       : ความเร็วสูงสุด
//  kp, kd         : PD gains
//  errorThreshold : หยุดเมื่อ error < ค่านี้ (องศา) default=5.0
// ══════════════════════════════════════════════════════════════
inline void TurnB_PID(float targetYaw, int speedMin, int speedMax,
                      float kp, float kd, float errorThreshold = 5.0,
                      int timeout_ms = 2000) {
  float prevError = 0;
  unsigned long lastTime  = millis();
  unsigned long startTime = millis();

  while (1) {
    if ((millis() - startTime) > (unsigned long)timeout_ms) break;

    float currentYaw = getYaw();   // ← World Frame (มี offset)
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0, 0.001);
    lastTime = now;

    float derivative = (error - prevError) / dt;
    float output = kp * error + kd * derivative;
    prevError = error;

    int speed = constrain(abs(output), speedMin, speedMax);

    if (output > 0) { motorL(-5);     motorR(-speed); }  // หมุนขวาถอย
    else            { motorL(-speed); motorR(-5);     }  // หมุนซ้ายถอย

    if (abs(error) < errorThreshold) break;
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  spinTo_F — หมุนในที่ ไม่มี PID  (calibrate หน้า = 0°)
//  spinTo_B — หมุนในที่ ไม่มี PID  (calibrate หลัง = 0°)
//
//  ความเร็วลดหน่ายตามมุมที่เหลือ (Proportional Remaining Angle)
//  ยิ่งใกล้เป้า → ยิ่งช้า → หยุดทันทีเมื่อถึง threshold ไม่มี loop แก้
//
//  targetYaw  : ทิศเป้าหมาย (องศา)
//  maxSpeed   : ความเร็วสูงสุด (ตอนเริ่ม)
//  minSpeed   : ความเร็วต่ำสุด (ตอนใกล้ถึง)
//  threshold  : หยุดเมื่อ error < ค่านี้ (องศา)  default=3.0
//  timeout_ms : เวลาสูงสุด ms  default=2000
// ══════════════════════════════════════════════════════════════

inline void spinTo_F(float targetYaw, int maxSpeed, int minSpeed,
                     float threshold = 3.0, int timeout_ms = 2000) {

  float startErr = abs(normalizeAngle(targetYaw - getYaw()));
  if (startErr < threshold) return;

  unsigned long startTime = millis();
  while (1) {
    if ((millis() - startTime) > (unsigned long)timeout_ms) break;

    float error     = normalizeAngle(targetYaw - getYaw());
    float remaining = abs(error);
    if (remaining < threshold) break;

    // ความเร็วแปรผันตามมุมที่เหลือ
    float ratio = min(remaining / max(startErr, 1.0f), 1.0f);
    int   speed = constrain((int)(minSpeed + (maxSpeed - minSpeed) * ratio),
                            minSpeed, maxSpeed);

    if (error > 0) { motorL(speed);  motorR(-speed); }  // CW
    else           { motorL(-speed); motorR(speed);  }  // CCW
  }
  ao(); delay(50); ao();
}

// spinTo_B — motor logic เหมือน spinTo_F ทุกอย่าง
// (calibrate หลัง=0° → getYaw() วัดทิศหลัง → error/motor ถูกต้องอยู่แล้ว)
inline void spinTo_B(float targetYaw, int maxSpeed, int minSpeed,
                     float threshold = 3.0, int timeout_ms = 2000) {
  spinTo_F(targetYaw, maxSpeed, minSpeed, threshold, timeout_ms);
}


// ══════════════════════════════════════════════════════════════
//  TurnF_S — ดิฟหน้า ไม่มี PID  (Proportional Remaining Angle)
//  ล้อซ้ายขับ ล้อขวาแตะ → pivot หน้า
// ══════════════════════════════════════════════════════════════

inline void TurnF_S(float targetYaw, int maxSpeed, int minSpeed,
                    float threshold = 3.0, int timeout_ms = 2000) {

  float startErr = abs(normalizeAngle(targetYaw - getYaw()));
  if (startErr < threshold) return;

  unsigned long startTime = millis();
  while (1) {
    if ((millis() - startTime) > (unsigned long)timeout_ms) break;

    float error     = normalizeAngle(targetYaw - getYaw());
    float remaining = abs(error);
    if (remaining < threshold) break;

    float ratio = min(remaining / max(startErr, 1.0f), 1.0f);
    int   speed = constrain((int)(minSpeed + (maxSpeed - minSpeed) * ratio),
                            minSpeed, maxSpeed);

    if (error > 0) { motorL(speed); motorR(-10); }   // หน้า-ขวา
    else           { motorL(-10); motorR(speed); }   // หน้า-ซ้าย
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  TurnB_S — ดิฟหลัง ไม่มี PID  (Proportional Remaining Angle)
//  ล้อซ้ายถอย ล้อขวาแตะ → pivot หลัง
// ══════════════════════════════════════════════════════════════

inline void TurnB_S(float targetYaw, int maxSpeed, int minSpeed,
                    float threshold = 3.0, int timeout_ms = 2000) {

  float startErr = abs(normalizeAngle(targetYaw - getYaw()));
  if (startErr < threshold) return;

  unsigned long startTime = millis();
  while (1) {
    if ((millis() - startTime) > (unsigned long)timeout_ms) break;

    float error     = normalizeAngle(targetYaw - getYaw());
    float remaining = abs(error);
    if (remaining < threshold) break;

    float ratio = min(remaining / max(startErr, 1.0f), 1.0f);
    int   speed = constrain((int)(minSpeed + (maxSpeed - minSpeed) * ratio),
                            minSpeed, maxSpeed);

    if (error > 0) { motorL(10); motorR(-speed); }  // หลัง-ขวา
    else           { motorL(-speed); motorR(10); }  // หลัง-ซ้าย
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  fd_pidNEW01 — เดินหน้า/หลัง PID v1
//
//  Movedirection : 0=หน้า  1=หลัง
//  targetYaw     : ทิศที่ต้องการ (องศา)
//  speedBase     : ความเร็วหลัก 0–100
//  duration      : เวลา ms
//  kp, ki, kd    : PID gains
//  Slow          : 1=ชะลอก่อนหยุด  0=ไม่ชะลอ
// ══════════════════════════════════════════════════════════════

inline void fd_pidNEW01(int Movedirection, float targetYaw, int speedBase,
                        float duration, float kp, float ki, float kd, int Slow) {
  unsigned long lastTime = millis();
  unsigned long endTime  = lastTime + (unsigned long)duration;

  float integral  = 0;
  float prevError = 0;

  while (millis() < endTime) {
    float currentYaw = getYaw();
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0, 0.001);
    lastTime = now;

    integral += error * dt;
    integral  = constrain(integral, -40, 40);

    float derivative = (error - prevError) / dt;
    derivative = constrain(derivative, -200, 200);

    float output = kp * error + ki * integral + kd * derivative;
    prevError = error;

    float maxTurn = speedBase * 0.6;
    output = constrain(output, -maxTurn, maxTurn);

    int base = speedBase;
    if (Slow == 1) {
      long remain = endTime - now;
      if (remain < 300 && remain > 0)
        base = map(remain, 0, 80, 10, speedBase);
    }

    int minSpd      = max(10, (int)(speedBase * 0.4));
    int rightSpeed  = constrain((int)(base - output), minSpd, 100);
    int leftSpeed   = constrain((int)(base + output), minSpd, 100);

    if (Movedirection == 0) { motorL(leftSpeed);   motorR(rightSpeed);  }
    else                    { motorL(-rightSpeed);  motorR(-leftSpeed); }

    delay(5);
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  MOVE — เดินหน้า/ถอยหลัง PID พร้อม ramp up/down
//
//  direction   : 0=เดินหน้า  1=ถอยหลัง
//  targetYaw   : ทิศเป้าหมาย (World Frame องศา)
//  speedBase   : ความเร็วหลัก 0–100
//  duration    : เวลา ms
//  kp, ki, kd  : PID gains
//  rampUp_ms   : เร่งความเร็ว ms (0=พุ่งเลย)   default=0
//  rampDown_ms : ชะลอความเร็ว ms (0=หยุดทันที) default=0
// ══════════════════════════════════════════════════════════════

inline void MOVE(int direction, float targetYaw, int speedBase,
                 float duration, float kp, float ki, float kd,
                 int rampUp_ms = 0, int rampDown_ms = 0, int startSpeed = 30) {

  unsigned long startTime = millis();
  unsigned long lastPID   = millis();
  unsigned long endTime   = startTime + (unsigned long)duration;

  float integral  = 0;
  float prevError = 0;
  float dFilt     = 0;

  while (millis() < endTime) {
    float currentYaw = getYaw();
    float error = shortestAngle(currentYaw, targetYaw);

    unsigned long now = millis();
    float dt = (now - lastPID) / 1000.0;
    if (dt <= 0) dt = 0.001;
    lastPID = now;

    // PID
    integral += error * dt;
    integral  = constrain(integral, -40, 40);
    if (abs(error) < 0.5) integral = 0;

    float derivative = (error - prevError) / dt;
    derivative = constrain(derivative, -200, 200);
    dFilt      = dFilt * 0.7 + derivative * 0.3;
    prevError  = error;

    float output = kp * error + ki * integral + kd * dFilt;
    float maxTurn = speedBase * 0.7;
    output = constrain(output, -maxTurn, maxTurn);

    // Base speed
    float base = speedBase;
    unsigned long elapsed = now - startTime;
    long remain = endTime - now;

    // Ramp up — เร่งจาก startSpeed → speedBase
    if (rampUp_ms > 0 && elapsed < (unsigned long)rampUp_ms) {
      float ramp = (float)elapsed / (float)rampUp_ms;
      base = startSpeed + (speedBase - startSpeed) * ramp;
    }

    // Ramp down
    if (rampDown_ms > 0 && remain < rampDown_ms && remain > 0) {
      float rampDown = constrain((float)remain / (float)rampDown_ms, 0.0, 1.0);
      base = 10 + (speedBase - 10) * rampDown;
    }

    int rightSpeed = constrain((int)(base - output), 0, 100);
    int leftSpeed  = constrain((int)(base + output), 0, 100);

    if (direction == 0) { motorL(leftSpeed);   motorR(rightSpeed);  }
    else                { motorL(-rightSpeed); motorR(-leftSpeed);  }

    delay(4);
  }
  ao();
}

// ══════════════════════════════════════════════════════════════
//  LINE_MOVE — เดินตามเส้น + ไจโรช่วยยึดทิศ ในฟังก์ชันเดียว
//              (ผสม PID 2 ชุด: เส้น + ไจโร) พร้อม ramp up/down + time
//
//  direction    : 0=เดินหน้า(เซนเซอร์หน้า)  1=ถอยหลัง(เซนเซอร์หลัง)
//  targetYaw    : ทิศที่ไจโรยึด (World Frame องศา)
//  speedBase    : ความเร็วหลัก 0–100
//  duration     : เวลา ms
//  kpLine,kdLine: PD ของเส้น   (error = ตำแหน่งเส้น -100..+100)
//  kpYaw, kdYaw : PD ของไจโร   (error = องศา)
//  rampUp_ms    : เร่งความเร็ว ms (0=พุ่งเลย)
//  rampDown_ms  : ชะลอความเร็ว ms (0=หยุดทันที)
//  startSpeed   : ความเร็วออกตัว
//
//  ⚠ ต้อง setupLineFront()/setupLineBack() + calibrate ใน Setup ก่อน
//  ⚠ ทางโค้ง: ลด kpYaw ไม่งั้นไจโรจะต้านเส้น (เส้นสั่งเลี้ยว ไจโรดึงตรง)
//  ✔ หลุดเส้น (ไม่เจอ sensor เลย): เส้น error→0 ไจโรพาตรงไปต่ออัตโนมัติ
//  หมายเหตุ: derivative ของเส้น "ไม่หาร dt" → ตั้ง kdLine แบบเดียวกับ
//            บล็อก "ตามเส้น PID" เดิม (default 2.0) ได้เลย
// ══════════════════════════════════════════════════════════════
inline void LINE_MOVE(int direction, float targetYaw, int speedBase,
                      float duration, float kpLine, float kdLine,
                      float kpYaw, float kdYaw,
                      int rampUp_ms = 0, int rampDown_ms = 0,
                      int startSpeed = 30) {

  unsigned long startTime = millis();
  unsigned long lastPID   = millis();
  unsigned long endTime   = startTime + (unsigned long)duration;

  float prevErrLine = 0;
  float prevErrYaw  = 0;
  float dFiltYaw    = 0;

  // เลือกชุดเซนเซอร์ตามทิศเดิน (หน้า/หลัง ที่ตั้งใน Setup)
  int lnFrom = (direction == 0) ? _lnFrontFrom : _lnBackFrom;
  int lnTo   = (direction == 0) ? _lnFrontTo   : _lnBackTo;
  int lnType = (direction == 0) ? _lnFrontType : _lnBackType;

  while (millis() < endTime) {
    unsigned long now = millis();
    float dt = (now - lastPID) / 1000.0;
    if (dt <= 0) dt = 0.001;
    lastPID = now;

    // ── PID เส้น (error = ตำแหน่ง -100..+100) ──
    float errLine = linePosition(lnFrom, lnTo, lnType);
    if (direction == 1 && _lnBackFlip) errLine = -errLine;  // ถอย: กลับซ้าย-ขวา ถ้าตั้งไว้
    float outLine = kpLine * errLine + kdLine * (errLine - prevErrLine);
    prevErrLine   = errLine;

    // ── PID ไจโร (error = องศา) — กรอง derivative เหมือน MOVE ──
    float errYaw = shortestAngle(getYaw(), targetYaw);
    float dYaw   = constrain((errYaw - prevErrYaw) / dt, -200.0, 200.0);
    dFiltYaw     = dFiltYaw * 0.7 + dYaw * 0.3;
    prevErrYaw   = errYaw;
    float outYaw = kpYaw * errYaw + kdYaw * dFiltYaw;

    // ── ผสมเส้น + ไจโร แล้วจำกัดการเลี้ยว ──
    //    output > 0 → ล้อซ้ายเร็วกว่าล้อขวา (L-R>0) คงทิศเดียวทั้งหน้า/ถอย
    float output  = outLine + outYaw;
    float maxTurn = speedBase;
    output = constrain(output, -maxTurn, maxTurn);

    // ── Base speed + ramp up/down (เหมือน MOVE) ──
    float base = speedBase;
    unsigned long elapsed = now - startTime;
    long remain = (long)(endTime - now);
    if (rampUp_ms > 0 && elapsed < (unsigned long)rampUp_ms) {
      base = startSpeed + (speedBase - startSpeed) * ((float)elapsed / (float)rampUp_ms);
    }
    if (rampDown_ms > 0 && remain < rampDown_ms && remain > 0) {
      float r = constrain((float)remain / (float)rampDown_ms, 0.0, 1.0);
      base = 10 + (speedBase - 10) * r;
    }

    int leftSpeed  = constrain((int)(base + output), 0, 100);
    int rightSpeed = constrain((int)(base - output), 0, 100);

    if (direction == 0) { motorL(leftSpeed);   motorR(rightSpeed); }
    else                { motorL(-rightSpeed); motorR(-leftSpeed); }

    delay(4);
  }
  ao();
}

// ══════════════════════════════════════════════════════════════
//  MOVE_LOOP / MOVE_WALL_LOOP
//  เดินตลอดจนกว่าจะ break จากข้างนอก
//  ไม่มี duration — วิ่งไปเรื่อยๆ 1 cycle (~4ms) ต่อการเรียก
//
//  MOVE_LOOP      → BNO055 อย่างเดียว
//  MOVE_WALL_LOOP → BNO055 + Sonar รักษาระยะกำแพง
//
//  ใช้งาน:
//    MOVE_LOOP_RESET();
//    while(true) {
//      if(เงื่อนไข) { ao(); break; }
//      MOVE_LOOP(...);        หรือ MOVE_WALL_LOOP(...)
//    }
// ══════════════════════════════════════════════════════════════

static unsigned long _tick_lastPID   = 0;
static unsigned long _tick_startTime = 0;
static float _tick_integral  = 0;
static float _tick_prevError = 0;
static float _tick_dFilt     = 0;

inline void MOVE_LOOP_RESET() {
  _tick_startTime = millis();
  _tick_lastPID   = millis();
  _tick_integral  = 0;
  _tick_prevError = 0;
  _tick_dFilt     = 0;
}

// ── PID core — ใช้ร่วมกันทั้ง 2 function ─────────────────────
inline float _move_loop_pid(float targetYaw, int speedBase, float kp, float kd) {
  unsigned long now = millis();
  float dt = (now - _tick_lastPID) / 1000.0f;
  if (dt <= 0) dt = 0.001f;
  _tick_lastPID = now;

  float error_yaw = shortestAngle(getYaw(), targetYaw);

  _tick_integral += error_yaw * dt;
  _tick_integral  = constrain(_tick_integral, -40, 40);
  if (abs(error_yaw) < 0.5f) _tick_integral = 0;

  float deriv     = constrain((error_yaw - _tick_prevError) / dt, -200, 200);
  _tick_dFilt     = _tick_dFilt * 0.7f + deriv * 0.3f;
  _tick_prevError = error_yaw;

  float output = kp * error_yaw + 0.05f * _tick_integral + kd * _tick_dFilt;
  return constrain(output, -(speedBase * 0.7f), speedBase * 0.7f);
}

inline float _move_loop_base(int speedBase, int startSpeed) {
  unsigned long elapsed = millis() - _tick_startTime;
  return (elapsed < 150)
    ? startSpeed + (speedBase - startSpeed) * ((float)elapsed / 150.0f)
    : (float)speedBase;
}

// ══════════════════════════════════════════════════════════════
//  MOVE_LOOP — BNO055 อย่างเดียว
// ══════════════════════════════════════════════════════════════
inline void MOVE_LOOP(
    int   direction,
    float targetYaw,
    int   speedBase,
    float kp_yaw,
    float kd_yaw    = 0,
    int   startSpeed = 10) {

  float output = _move_loop_pid(targetYaw, speedBase, kp_yaw, kd_yaw);
  output = constrain(output, -(speedBase * 0.7f), speedBase * 0.7f);
  float base = _move_loop_base(speedBase, startSpeed);

  int R = constrain((int)(base - output), 0, 100);
  int L = constrain((int)(base + output), 0, 100);

  if (direction == 0) { motorL(L); motorR(R); }
  else                { motorL(-R); motorR(-L); }

  delay(1);
}

// ══════════════════════════════════════════════════════════════
//  MOVE_WALL_LOOP — BNO055 + Sonar รักษาระยะกำแพง
// ══════════════════════════════════════════════════════════════
inline void MOVE_WALL_LOOP(
    int   direction,
    float targetYaw,
    int   speedBase,
    float kp_yaw,
    float kp_wall,
    float targetDist,
    int   trigPin,
    int   echoPin,
    int   startSpeed = 30) {

  float output = _move_loop_pid(targetYaw, speedBase, kp_yaw, 0);

  float dist = sonarRead(trigPin, echoPin);
  if (dist > 0) output += kp_wall * (dist - targetDist);

  output = constrain(output, -(speedBase * 0.7f), speedBase * 0.7f);
  float base = _move_loop_base(speedBase, startSpeed);

  int R = constrain((int)(base - output), 0, 100);
  int L = constrain((int)(base + output), 0, 100);

  if (direction == 0) { motorL(L); motorR(R); }
  else                { motorL(-R); motorR(-L); }

  delay(4);
}