#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_bno055_zupt.h — BNO055 อ่าน gyro "ดิบ" (ไม่ผ่าน fusion) + ZUPT
//
//  แนวคิด: ใช้ BNO055 ในโหมด ACCGYRO (accel + gyro, ไม่มี fusion)
//          แล้วเอา gyro Z ดิบมา integrate เอง พร้อมระบบ ZUPT + Kalman
//          bias ชุดเดียวกับ imu_mpu6050.h
//
//  ทำไม: fusion ของ BNO055 (IMUPLUS) มี reference ที่เลื่อนเองตามเวลา/
//        การเลี้ยวเร็ว → ดริฟต์สะสม การข้าม fusion แล้ว re-zero bias
//        ทุกครั้งที่หุ่นหยุด (ZUPT) ตัดดริฟต์สะสมตรงจุด
//
//  ★ เป็น "ตัวเลือกเพิ่ม" ไม่กระทบโหมด BNO055 เดิม (imu_bno055.h)
//    ใช้ object ตัวเดียวกัน (_bnoDev()) — เลือกได้ทีละโหมดต่อการรัน
//
//  ⚠️ เลี้ยวกลับด้าน → เปลี่ยน BNOZ_YAW_SIGN เป็น -1.0f
//  ⚠️ ถ้าแกน yaw ไม่ใช่ Z (ติดเซนเซอร์ตะแคง) → เปลี่ยนแกนใน _bnoz_readAll
// ══════════════════════════════════════════════════════════════

#include "imu_bno055.h"   // ใช้ _bnoDev() + Adafruit_BNO055 + imu::Vector ร่วมกัน

// ── ★ ปรับจูนหลัก ─────────────────────────────────────────────
#define BNOZ_YAW_SIGN    (-1.0f)     // หมุนขวา = เลขเพิ่ม (กลับด้าน → -1.0f)
#define BNOZ_GRAVITY     9.80665f   // 1g ในหน่วย m/s² (BNO accel เป็น m/s²)
#define BNOZ_STILL_ACC   0.30f      // นิ่งเมื่อ |accel - g| < ค่านี้ (m/s² ≈ 0.03g)
#define BNOZ_STILL_HOLD  8          // จำนวนรอบนิ่งก่อน ZUPT (ปกติ)
#define BNOZ_GATE_HOLD   3          // หลัง ao() นับแค่ 3 รอบก็ ZUPT

// ── Adaptive ZUPT threshold ──────────────────────────────────
#define BNOZ_STILL_SIGMA 4.0f       // threshold = noise_floor × sigma (4σ)

// ── Kalman Bias (ทำงานในหน่วย dps โดยตรง) ─────────────────────
#define BNOZ_KALMAN_Q    0.0001f    // process noise: bias เปลี่ยนช้ามาก (dps²)
#define BNOZ_KALMAN_R    0.05f      // measurement noise (dps²) — tune ถ้า bias สั่น

static double        _bnoz_yawAccum   = 0.0;
static float         _bnoz_gyroZbias  = 0.0f;   // dps
static float         _bnoz_prevRate   = 0.0f;
static unsigned long _bnoz_lastUs     = 0;
static int           _bnoz_stillCnt   = 0;
static bool          _bnoz_stationary = false;

// IIR filter state — ใช้กับ still-detection เท่านั้น (integration ใช้ raw)
static float         _bnoz_rateFilt   = 0.0f;

// Motor Gating
static bool          _bnoz_gateFlag   = false;

// Adaptive ZUPT threshold (dps) — ตั้งตอน init จาก noise floor จริง
static float         _bnoz_stillThresh = 1.2f;

// Kalman covariance
static float         _bnoz_kalmanP    = 1.0f;

// ── อ่าน gyro(dps) + accel(m/s²) ในรอบเดียว ──────────────────
static inline void _bnoz_readAll(float &gx, float &gy, float &gz,
                                 float &ax, float &ay, float &az) {
  imu::Vector<3> g = _bnoDev().getVector(Adafruit_BNO055::VECTOR_GYROSCOPE);
  imu::Vector<3> a = _bnoDev().getVector(Adafruit_BNO055::VECTOR_ACCELEROMETER);
  gx = g.x(); gy = g.y(); gz = g.z();   // dps
  ax = a.x(); ay = a.y(); az = a.z();   // m/s²
}

// ── วัด bias (mean) + noise floor (stddev) ในลูปเดียว ────────
//  single-pass เหมือน imu_mpu6050.h เวอร์ชันปรับปรุง
static inline void _bnoz_calibrateBias(int samples = 200) {
  double sum = 0, sumSq = 0;
  for (int i = 0; i < samples; i++) {
    imu::Vector<3> g = _bnoDev().getVector(Adafruit_BNO055::VECTOR_GYROSCOPE);
    float z = g.z();                 // dps
    sum   += z;
    sumSq += (double)z * z;
    delay(10);                       // BNO055 gyro ODR ≈ 100Hz = 10ms ต่อ sample
  }
  double mean = sum / samples;
  _bnoz_gyroZbias = (float)mean;
  _bnoz_kalmanP   = 1.0f;            // reset Kalman covariance หลัง calibrate

  // variance = E[z²] − (E[z])²  (หน่วย dps²)
  double var = sumSq / samples - mean * mean;
  if (var < 0) var = 0;             // กันปัดเศษ double ติดลบ
  float stddev_dps = sqrtf((float)var);
  // floor 0.8 dps กันกรณีอ่านซ้ำ ODR ทำให้ stddev ต่ำเกิน → ZUPT ไม่ fire
  _bnoz_stillThresh = constrain(stddev_dps * BNOZ_STILL_SIGMA, 0.8f, 3.0f);
}

// รอจนหุ่นนิ่งจริงก่อนคาลิเบรต (เงื่อนไข: gyro เล็ก + accel ≈ 1g)
static inline void _bnoz_waitStable() {
  const float STILL_G = 3.0f;       // dps (เผื่อ bias ที่ยังไม่หัก)
  const float STILL_A = 0.40f;      // m/s²
  int stable = 0;
  unsigned long t0 = millis();
  while (stable < 15) {             // 15 รอบ × 20ms ≈ 300ms
    float gx, gy, gz, ax, ay, az;
    _bnoz_readAll(gx, gy, gz, ax, ay, az);
    float accMag = sqrtf(ax*ax + ay*ay + az*az);
    bool still = (fabsf(gx) < STILL_G) && (fabsf(gy) < STILL_G) &&
                 (fabsf(gz) < STILL_G) && (fabsf(accMag - BNOZ_GRAVITY) < STILL_A);
    if (still) stable++;
    else       stable = 0;
    delay(20);
    if (millis() - t0 > 6000) break; // กันค้างเกิน 6 วิ
  }
}

inline void bnoz_notifyStop() { _bnoz_gateFlag = true; }   // เรียกตรงก็ได้

inline void bnoz_initIMU() {
  Wire1.setSDA(26);
  Wire1.setSCL(27);
  Wire1.begin();
  delay(50);

  // ACCGYRO = accel + gyro ดิบ ไม่มี fusion
  if (!_bnoDev().begin(OPERATION_MODE_ACCGYRO)) {
    Serial.println("BNO055 (ZUPT) not detected");
    pinMode(9, OUTPUT);
    while (1) { tone(9, 2000); delay(100); noTone(9); delay(100); }  // Beep แจ้ง error
  }
  _bnoDev().setExtCrystalUse(true);
  delay(50);

  _bnoz_waitStable();          // รอจนหุ่นนิ่งจริงก่อน ~0.3s
  _bnoz_calibrateBias(600);    // วัด bias ตอนนิ่งสนิท ~1.2s
  _bnoz_yawAccum = 0.0;
  _bnoz_prevRate = 0.0;
  _bnoz_stillCnt = 0;
  _bnoz_lastUs   = micros();
}

inline float bnoz_getYawRaw() {
  unsigned long now = micros();
  float dt = (now - _bnoz_lastUs) / 1000000.0f;
  _bnoz_lastUs = now;
  if (dt > 0.05f) dt = 0.05f;   // clamp ไม่ทิ้ง integration

  // ── Motor Gating — รับ flag จาก ao() (global จาก motor_razors4.h) ──
  if (_motor_ao_called) {
    _motor_ao_called = false;
    _bnoz_gateFlag   = true;
  }

  float gx, gy, gz, ax, ay, az;
  _bnoz_readAll(gx, gy, gz, ax, ay, az);

  float rateZ = gz - _bnoz_gyroZbias;   // dps (หัก bias แล้ว)

  // IIR filter บน rateZ — ใช้เฉพาะ still-detection ไม่ใช้ integration
  _bnoz_rateFilt = 0.65f * _bnoz_rateFilt + 0.35f * rateZ;

  // Still detection
  float accMag = sqrtf(ax*ax + ay*ay + az*az);
  bool still = (fabsf(gx)            < _bnoz_stillThresh) &&
               (fabsf(gy)            < _bnoz_stillThresh) &&
               (fabsf(_bnoz_rateFilt) < _bnoz_stillThresh) &&
               (fabsf(accMag - BNOZ_GRAVITY) < BNOZ_STILL_ACC);

  // Motor Gating — ao() set flag → เร่ง ZUPT
  int holdNeeded = _bnoz_gateFlag ? BNOZ_GATE_HOLD : BNOZ_STILL_HOLD;

  if (still) {
    if (_bnoz_stillCnt < 100000) _bnoz_stillCnt++;
  } else {
    _bnoz_stillCnt = 0;
    _bnoz_gateFlag = false;
  }
  _bnoz_stationary = (_bnoz_stillCnt >= holdNeeded);
  if (_bnoz_stationary && _bnoz_gateFlag) _bnoz_gateFlag = false;

  // ── Kalman Bias Update ───────────────────────────────────────
  //  นิ่ง → update bias (ตอนหยุด rate ควรเป็น 0) | ขยับ → predict only
  if (_bnoz_stationary) {
    float err = gz - _bnoz_gyroZbias;                          // dps
    float K   = _bnoz_kalmanP / (_bnoz_kalmanP + BNOZ_KALMAN_R);
    _bnoz_gyroZbias += K * err;
    _bnoz_kalmanP    = (1.0f - K) * _bnoz_kalmanP + BNOZ_KALMAN_Q;
    rateZ = 0.0f;   // บังคับ rate=0 ขณะนิ่ง กันนอยส์รั่ว
  } else {
    _bnoz_kalmanP += BNOZ_KALMAN_Q;
  }

  float rate = rateZ * BNOZ_YAW_SIGN;

  // Trapezoidal integration (raw rate)
  _bnoz_yawAccum += (double)(0.5f * (rate + _bnoz_prevRate)) * dt;
  _bnoz_prevRate  = rate;

  double y = fmod(_bnoz_yawAccum, 360.0);
  if (y < 0) y += 360.0;
  return (float)y;
}

// ── Debug / OLED helpers ─────────────────────────────────────
inline bool  bnoz_isStationary()   { return _bnoz_stationary; }
inline float bnoz_getBias()        { return _bnoz_gyroZbias; }     // dps
inline float bnoz_getStillThresh() { return _bnoz_stillThresh; }   // dps
inline bool  bnoz_isGated()        { return _bnoz_gateFlag; }
