#pragma once
#include <Arduino.h>
#include <EEPROM.h>

// ══════════════════════════════════════════════════════════════
//  RazorS4 — Line Sensor Calibration Library
//
//  ใช้งาน:
//    autoScanSensor(chipType, duration_ms)  → scan + save EEPROM
//    loadCalibration()                      → โหลดค่ากลางจาก EEPROM
//    saveCalibration()                      → บันทึกค่ากลางลง EEPROM
//    getRef(ch)                             → อ่านค่ากลาง ch 0-7
//
//  chipType: 8 = MCP3008 (0-1023), 12 = MCP3208 (0-4095)
// ══════════════════════════════════════════════════════════════

#define EEPROM_SIZE    64
#define MAGIC_NUMBER   0xAA55

struct CalibrationData {
  uint16_t magic;
  uint8_t  chipType;    // 8=MCP3008  12=MCP3208
  uint16_t ref[8];      // ref[0]=A0 ... ref[7]=A7
};

static CalibrationData _calData;

// ── beep สำหรับใช้ภายใน linesensor ─────────────────────────
inline void _lsBeep() {
  pinMode(9, OUTPUT);
  tone(9, 1000); delay(200); noTone(9); delay(100);
}
inline int _readSensor(int ch, int chipType) {
  if (chipType == 12) return analog3208(ch);
  else                return analog3008(ch);
}

// ── บันทึกลง EEPROM ──────────────────────────────────────────
inline void saveCalibration() {
  EEPROM.begin(EEPROM_SIZE);
  _calData.magic = MAGIC_NUMBER;
  EEPROM.put(0, _calData);
  EEPROM.commit();
  EEPROM.end();
}

// ── โหลดจาก EEPROM ───────────────────────────────────────────
inline bool loadCalibration() {
  EEPROM.begin(EEPROM_SIZE);
  EEPROM.get(0, _calData);
  EEPROM.end();

  if (_calData.magic == MAGIC_NUMBER) return true;

  // ถ้าไม่มีข้อมูล → ใช้ค่า default
  _calData.chipType = 12;
  for (int i = 0; i < 8; i++) _calData.ref[i] = 200;
  return false;
}

// ── อ่านค่ากลาง channel ที่ต้องการ ───────────────────────────
inline int getRef(int ch) {
  if (ch < 0 || ch > 7) return 0;
  return _calData.ref[ch];
}

// ══════════════════════════════════════════════════════════════
//  autoScanSensor — scan หาค่ากลาง + แสดงบน OLED + save EEPROM
//
//  chipType    : 8=MCP3008  12=MCP3208
//  duration_ms : เวลา scan ms (แนะนำ 3000-5000)
// ══════════════════════════════════════════════════════════════
inline void autoScanSensor(int chipType, int duration_ms = 5000) {
  _calData.chipType = chipType;

  int maxV[8], minV[8];
  for (int i = 0; i < 8; i++) {
    maxV[i] = 0;
    minV[i] = (chipType == 12) ? 4095 : 1023;
  }

  // แสดงข้อความเริ่มต้น
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);  display.println("Calibrating...");
  display.setCursor(0, 12); display.println("Move over line");
  display.display();
  _lsBeep();
  delay(500);

  unsigned long startTime = millis();

  while (millis() - startTime < (unsigned long)duration_ms) {
    int val[8];
    for (int i = 0; i < 8; i++) {
      val[i] = _readSensor(i, chipType);
      if (val[i] > maxV[i]) maxV[i] = val[i];
      if (val[i] < minV[i]) minV[i] = val[i];
    }

    // แสดงค่า realtime บน OLED
    display.clearDisplay();
    display.setTextSize(1);
    // คอลัมน์ซ้าย A0-A5
    for (int i = 0; i < 6; i++) {
      display.setCursor(0,  i * 10);
      display.print("A"); display.print(i); display.print(":");
      display.setCursor(20, i * 10);
      display.println(val[i]);
    }
    // คอลัมน์ขวา A6-A7
    display.setCursor(68, 0);
    display.print("A6:"); display.println(val[6]);
    display.setCursor(68, 10);
    display.print("A7:"); display.println(val[7]);

    // แสดง progress bar
    int elapsed = millis() - startTime;
    int barW = map(elapsed, 0, duration_ms, 0, 100);
    display.drawRect(0, 56, 102, 8, WHITE);
    display.fillRect(0, 56, barW, 8, WHITE);
    display.display();

    delay(5);
  }

  // คำนวณค่ากลาง
  for (int i = 0; i < 8; i++) {
    _calData.ref[i] = (maxV[i] + minV[i]) / 2;
  }

  // บันทึก EEPROM
  saveCalibration();

  // แสดงผลลัพธ์
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(15, 0); display.println("Done! Ref values:");
  for (int i = 0; i < 6; i++) {
    display.setCursor(0,  10 + i * 9);
    display.print("A"); display.print(i); display.print(":");
    display.setCursor(20, 10 + i * 9);
    display.println(_calData.ref[i]);
  }
  display.setCursor(68, 10); display.print("A6:"); display.println(_calData.ref[6]);
  display.setCursor(68, 19); display.print("A7:"); display.println(_calData.ref[7]);
  display.display();

  _lsBeep();
  delay(2000);
  _lsBeep();
}

// ══════════════════════════════════════════════════════════════
//  อ่านค่า Sensor
// ══════════════════════════════════════════════════════════════

// ── เจอเส้นไหม (true = เจอเส้น) ─────────────────────────────
// lineType: 0 = ดำ/พื้นขาว,  1 = ขาว/พื้นดำ
inline bool sensorOnLine(int ch, int lineType = 0) {
  int raw = _readSensor(ch, _calData.chipType);
  int ref = _calData.ref[ch];
  if (lineType == 0) return raw < ref;   // ดำ = ต่ำกว่า ref
  else               return raw > ref;   // ขาว = สูงกว่า ref
}

// ── นับจำนวน sensor ที่เจอเส้น ───────────────────────────────
inline int countSensors(int chFrom, int chTo, int lineType = 0) {
  int count = 0;
  for (int i = chFrom; i <= chTo; i++)
    if (sensorOnLine(i, lineType)) count++;
  return count;
}

// ── แสดง sensor บน OLED แบบ ●○ ──────────────────────────────
inline void showSensors(int chFrom, int chTo, int row, int lineType = 0) {
  int x = 0;
  for (int i = chFrom; i <= chTo; i++) {
    display.setCursor(x, row * 10);
    if (sensorOnLine(i, lineType))
      display.print((char)0x01);   // ● filled
    else
      display.print((char)0x04);   // ○ empty
    x += 14;
  }
  display.display();
}

// ══════════════════════════════════════════════════════════════
//  ตำแหน่ง / ERROR
// ══════════════════════════════════════════════════════════════

// ── ตำแหน่งเส้น weighted average ─────────────────────────────
// คืน -100 ถึง +100
// 0 = กลาง, < 0 = ซ้าย, > 0 = ขวา
inline int linePosition(int chFrom, int chTo, int lineType = 0) {
  int n = chTo - chFrom + 1;
  if (n <= 0) return 0;

  long sumW = 0, sumS = 0;
  for (int i = chFrom; i <= chTo; i++) {
    int raw = _readSensor(i, _calData.chipType);
    int ref = _calData.ref[i];
    int maxV = (_calData.chipType == 12) ? 4095 : 1023;

    // normalize 0-100
    int pct;
    if (lineType == 0) {  // ดำ/พื้นขาว — ดำ = สูง
      pct = (raw < ref)
        ? map(raw, 0, ref, 100, 50)
        : map(raw, ref, maxV, 50, 0);
    } else {              // ขาว/พื้นดำ — ขาว = สูง
      pct = (raw > ref)
        ? map(raw, ref, maxV, 50, 100)
        : map(raw, 0, ref, 0, 50);
    }

    // weight ตำแหน่ง: -100 ถึง +100
    int weight = map(i, chFrom, chTo, -100, 100);
    sumW += (long)pct * weight;
    sumS += pct;
  }

  if (sumS == 0) return 0;
  return (int)(sumW / sumS);
}