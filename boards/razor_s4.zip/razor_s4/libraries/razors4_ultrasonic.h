#pragma once
#include <Arduino.h>

// ══════════════════════════════════════════════════════════════
//  RazorS4 — Ultrasonic (HC-SR04) Library
//
//  Pin ที่ใช้ได้: 4, 5, 6, 7, 8, 10
//  ไม่ต้อง init ก่อน — set pinMode อัตโนมัติตอนเรียก
//
//  ใช้งาน:
//    sonarRead(trigPin, echoPin)  → คืนระยะ cm (float)
//    timeout 30ms = ระยะสูงสุด ~500cm
// ══════════════════════════════════════════════════════════════

inline float sonarRead(int trigPin, int echoPin) {
  // ต้อง set pinMode ก่อนส่ง TRIG pulse เสมอ
  // เพราะ HC-SR04 ส่ง ECHO กลับมาทันทีหลัง TRIG — ถ้า pinMode ช้า จะ miss echo
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);   // ← ต้อง set ก่อน TRIG pulse

  // TRIG — ส่งสัญญาณออก
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // ECHO — รับสัญญาณกลับ
  long duration = pulseIn(echoPin, HIGH, 30000); // timeout 30ms

  if (duration == 0) return -1;  // ไม่มีสัญญาณ → คืน -1

  return duration * 0.034f / 2.0f;  // แปลงเป็น cm
}
