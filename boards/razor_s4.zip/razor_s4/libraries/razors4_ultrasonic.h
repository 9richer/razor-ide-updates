#pragma once
#include <Arduino.h>

// ══════════════════════════════════════════════════════════════
//  RazorS4 — Ultrasonic (HC-SR04) Library
//
//  Pin ที่ใช้ได้: 4, 5, 6, 7, 8, 10
//  ไม่ต้อง init ก่อน — set pinMode อัตโนมัติตอนเรียก
//
//  ใช้งาน:
//    sonarRead(trigPin, echoPin)  → คืนระยะ cm (float)
//    timeout 30ms = ระยะสูงสุด ~500cm
// ══════════════════════════════════════════════════════════════

inline float sonarRead(int trigPin, int echoPin) {
  // TRIG — ส่งสัญญาณออก
  pinMode(trigPin, OUTPUT);
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // ECHO — รับสัญญาณกลับ
  pinMode(echoPin, INPUT);
  long duration = pulseIn(echoPin, HIGH, 30000); // timeout 30ms

  if (duration == 0) return -1;  // ไม่มีสัญญาณ → คืน -1

  return duration * 0.034f / 2.0f;  // แปลงเป็น cm
}
