#pragma once

// ══════════════════════════════════════════════════════════════
//  Motor Offset — ชดเชยมอเตอร์ซ้าย/ขวาไม่เท่ากัน
//  ตั้งค่าใน Setup ครั้งเดียว → ใช้ได้ทุกฟังก์ชัน
//
//  offsetL > 0 → เพิ่มซ้าย (ถ้าซ้ายช้ากว่า)
//  offsetL < 0 → ลดซ้าย   (ถ้าซ้ายเร็วกว่า)
//  offsetR > 0 → เพิ่มขวา
//  offsetR < 0 → ลดขวา
// ══════════════════════════════════════════════════════════════

static int _offsetL = 0;
static int _offsetR = 0;

inline void setMotorOffset(int offsetL, int offsetR) {
  _offsetL = offsetL;
  _offsetR = offsetR;
}

// ══════════════════════════════════════════════════════════════
//  Battery Voltage Compensation — ชดเชยแบตลด (ไม่ต้องใช้ step-down)
//
//  ไฟเฉลี่ยที่มอเตอร์ได้ = Vbatt x (PWM/255)
//  อยากให้มอเตอร์ "รู้สึก" เหมือนใช้ Vref คงที่
//    -> PWM ที่ต้องใช้ = speed x (Vref / Vbatt)
//  แบตเต็ม (8.4V) -> ลด PWM ลง   แบตลด -> เพิ่ม PWM ชดเชย
//
//  เลือกได้:
//    ไม่เรียก setMotorVoltage()  -> _vref = 0 -> โหมดปกติ (พฤติกรรมเดิมทุกอย่าง)
//    setMotorVoltage(7.0)        -> เปิดโหมดชดเชย เป้าหมาย 7.0V
//    disableMotorVoltage()       -> กลับเป็นโหมดปกติ
// ══════════════════════════════════════════════════════════════

#define BATT_ADC_PIN   28        // GP28 / ADC2 ของ RP2040 (ตัวแบ่ง R5 47k / R6 10k)
#define BATT_DIVIDER   5.70f     // (R5+R6)/R6 = (47+10)/10 — ปรับให้ตรงของจริงด้วยมัลติมิเตอร์
#define BATT_ADC_FULL  1023.0f   // analogRead 10-bit (ถ้าตั้ง analogReadResolution(12) เปลี่ยนเป็น 4095)

static float        _vref      = 0.0f;   // 0 = ปิดชดเชย (ค่าเริ่มต้น)
static float        _vbatt_filt = 7.4f;
static unsigned long _vbatt_ms  = 0;

inline float battVoltageRaw() {
  int raw = analogRead(BATT_ADC_PIN);
  return raw * (3.3f / BATT_ADC_FULL) * BATT_DIVIDER;
}

// แรงดันแบตที่กรองแล้ว — อัปเดตทุก ~30ms กันค่ากระชากตอนมอเตอร์ดึงกระแส (sag)
inline float battVoltage() {
  unsigned long now = millis();
  if (now - _vbatt_ms >= 30) {
    _vbatt_ms = now;
    float v = battVoltageRaw();
    if (v > 3.0f && v < 13.0f)            // กันค่าหลุด / ADC ไม่ต่อ
      _vbatt_filt = _vbatt_filt * 0.8f + v * 0.2f;
  }
  return _vbatt_filt;
}

// เปิดโหมดชดเชย + ตั้งแรงดันเป้าหมาย (เรียกใน setup ครั้งเดียว)
inline void setMotorVoltage(float vref) {
  _vref = vref;
  _vbatt_filt = battVoltageRaw();         // seed ค่าเริ่มต้น
}
inline void disableMotorVoltage() { _vref = 0.0f; }

// แปลง speed (-100..100) -> speed ที่ชดเชยแล้ว (จำกัดที่ +-100 เสมอ)
inline int _vcomp(int speed) {
  if (_vref <= 0.0f || speed == 0) return speed;   // ปิดอยู่ หรือสั่งหยุด -> ไม่ยุ่ง
  float vb = battVoltage();
  if (vb < 1.0f) return speed;                      // กันหารศูนย์
  float out = speed * (_vref / vb);
  return constrain((int)(out + (out > 0 ? 0.5f : -0.5f)), -100, 100);
}

inline void motor1(int speed1)   
    {
      pinMode(0,OUTPUT);  //pwm Motor1  12 
      pinMode(11,OUTPUT);     
      pinMode(12,OUTPUT);     

       if(speed1>100)
         {
          speed1 = 100;
         }
       else if(speed1<-100)
         {
          speed1 = -100;
         }
      

      speed1 = _vcomp(speed1);   // ชดเชยแบต (ถ้าเปิดโหมด)

      if(speed1>0)
         {
            analogWrite(0,(speed1*255)/100);
            digitalWrite(11,HIGH);
            digitalWrite(12,LOW); 
         }
      else if(speed1<0)
         {
            analogWrite(0,-(speed1*255)/100);
            digitalWrite(11,LOW);
            digitalWrite(12,HIGH); 
         }
      else
         {
            analogWrite(0,255);
            digitalWrite(11,LOW);
            digitalWrite(12,LOW); 
         }



       
    }

inline void motor2(int speed1) {

      pinMode(1,OUTPUT);  //pwm Motor2 
      pinMode(20,OUTPUT);     
      pinMode(21,OUTPUT);     

       if(speed1>100)
         { speed1 = 100;  }
       else if(speed1<-100)
         { speed1 = -100;}

  speed1 = _vcomp(speed1);   // ชดเชยแบต (ถ้าเปิดโหมด)

  if(speed1 > 0)
  {
    analogWrite(1, (speed1*255)/100);
    digitalWrite(20, HIGH);
    digitalWrite(21, LOW);
  }
  else if(speed1 < 0)
  {
    analogWrite(1, -(speed1*255)/100);
    digitalWrite(20,LOW );
    digitalWrite(21, HIGH);
  }
  else
  {
    // brake
    digitalWrite(20, LOW);
    digitalWrite(21, LOW);
    analogWrite(1, 255);
  }
}


inline void motor3(int speed1)   
    {
      pinMode(2,OUTPUT);  //pwm Motor2 
      pinMode(15,OUTPUT);     
      pinMode(22,OUTPUT);     
       if(speed1>100)
         { speed1 = 100;  }
       else if(speed1<-100)
         { speed1 = -100;}

      speed1 = _vcomp(speed1);   // ชดเชยแบต (ถ้าเปิดโหมด)

      if(speed1>0)
         {
            analogWrite(2,(speed1*255)/100);
            digitalWrite(15,HIGH);
            digitalWrite(22,LOW); 
         }
      else if(speed1<0)
         {
            analogWrite(2,-(speed1*255)/100);
            digitalWrite(15,LOW);
            digitalWrite(22,HIGH); 
         }
      else
         {
            analogWrite(2,255);
            digitalWrite(15,LOW);
            digitalWrite(22,LOW); 
         }


       
    }


    inline void motor4(int speed1)   
    {
      pinMode(3,OUTPUT);  //pwm Motor2 
      pinMode(13,OUTPUT);     
      pinMode(14,OUTPUT);     
      if(speed1>100)
         { speed1 = 100;  }
      else if(speed1<-100)
         { speed1 = -100;}

      speed1 = _vcomp(speed1);   // ชดเชยแบต (ถ้าเปิดโหมด)

      if(speed1>0)
         {
            analogWrite(3,(speed1*255)/100);
            digitalWrite(13,HIGH);
            digitalWrite(14,LOW); 
         }
      else if(speed1<0)
         {
            analogWrite(3,-(speed1*255)/100);
            digitalWrite(13,LOW);
            digitalWrite(14,HIGH); 
         }
      else
         {
            analogWrite(3,255);
            digitalWrite(13,LOW);
            digitalWrite(14,LOW);  // FIX: pin 14 = IN2 ของ motor4 (ไม่ใช่ 22 ซึ่งเป็น motor3)
         }


       
    }

inline void motorL(int SPR) {
  int spd = constrain(SPR + _offsetL, -100, 100);
  motor1(spd);
  motor2(spd);
}

inline void motorR(int SPR) {
  int spd = constrain(SPR + _offsetR, -100, 100);
  motor3(spd);
  motor4(spd);
}


    inline void sr(int SPR)  //หมุนขวา
  {
    motor1(SPR);
    motor2(SPR);
    motor3(-SPR);
    motor4(-SPR);
  
  }

 inline void sl(int SPL) //หมุนซ้าย
  {
    motor1(-SPL);
    motor2(-SPL);
    motor3(SPL);
    motor4(SPL);
  
  }

  inline void tr(int SPR)  //เลี้ยวขวา
  {
    motor1(SPR);
    motor2(SPR);
    motor3(0);
    motor4(0);
  
  }

 inline void tl(int SPL)  //เลี้ยวซ้าย
  {
    motor1(0);
    motor2(0);
    motor3(SPL);
    motor4(SPL);
  
  }

inline void fd2(int speedL, int speedR) {
  motor1(speedL);
  motor2(speedL);
  motor3(speedR);
  motor4(speedR);
}

inline void bk(int speedL, int speedR) {
  motor1(-speedL);
  motor2(-speedL);
  motor3(-speedR);
  motor4(-speedR);
}

// ── ③ Motor Gating flag ───────────────────────────────────────
// ao() set ค่า → imu_mpu6050.h อ่านและ clear
// ใช้ static เพื่อหลีกเลี่ยง include-order dependency กับ IMU header
static volatile bool _motor_ao_called = false;

  inline void ao() {
  _motor_ao_called = true;   // ③ Motor Gating flag — IMU picks it up later

  analogWrite(0, 0);
  digitalWrite(11, 1);
  digitalWrite(12, 1);
 
  analogWrite(1,0);
  digitalWrite(20,1);
  digitalWrite(21,1); 

  analogWrite(2,0);
  digitalWrite(15,1);
  digitalWrite(22,1);

  analogWrite(3,0);
  digitalWrite(13,1);
  digitalWrite(14,1); 

  delay(10);

} 


