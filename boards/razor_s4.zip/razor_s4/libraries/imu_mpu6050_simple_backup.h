#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_mpu6050.h — ตัวอ่านเซนเซอร์ MPU6050 (เซนเซอร์ล้วน)
//  ใช้คู่กับ razors4_imu.h (ตัวสลับ IMU)
//  ฟังก์ชันขึ้นต้น mpu_ เพื่อไม่ชนกับ bno_
//
//  yaw = อินทิเกรต gyro-Z (6 แกน ไม่มี mag → ดริฟต์ได้)
//  สู้ดริฟต์: คาลิเบรต bias ตอนเปิด + DLPF + ZUPT
//
//  I2C addr 0x68 (AD0=GND) | Wire1 (SDA=GP26, SCL=GP27)
//  ⚠️ ถ้าเลี้ยวกลับด้าน → เปลี่ยน MPU_YAW_SIGN เป็น -1.0f
// ══════════════════════════════════════════════════════════════

#include <Wire.h>

#define MPU_ADDR      0x68       // 0x69 ถ้า AD0 ต่อ 3V3
#define MPU_WIRE      Wire1
#define MPU_SDA       26
#define MPU_SCL       27
#define MPU_YAW_SIGN  (+1.0f)

static double        _mpu_yawAccum  = 0.0;
static float         _mpu_gyroZbias = 0.0f;
static unsigned long _mpu_lastUs    = 0;
static const float   _MPU_LSB_PER_DPS = 131.0f;     // ±250 dps

static inline void _mpu_write(uint8_t reg, uint8_t val) {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(reg); MPU_WIRE.write(val);
  MPU_WIRE.endTransmission();
}

static inline int16_t _mpu_readGyroZraw() {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(0x47);                              // GYRO_ZOUT_H
  MPU_WIRE.endTransmission(false);
  MPU_WIRE.requestFrom((int)MPU_ADDR, 2);
  int16_t hi = MPU_WIRE.read();
  int16_t lo = MPU_WIRE.read();
  return (int16_t)((hi << 8) | lo);
}

static inline void _mpu_calibrateBias(int samples = 1000) {
  double sum = 0;
  for (int i = 0; i < samples; i++) { sum += _mpu_readGyroZraw(); delay(2); }
  _mpu_gyroZbias = (float)(sum / samples);
}

inline void mpu_initIMU() {
  MPU_WIRE.setSDA(MPU_SDA);                          // ลบ 3 บรรทัดได้ถ้าเฟรมเวิร์กเปิด Wire1 แล้ว
  MPU_WIRE.setSCL(MPU_SCL);
  MPU_WIRE.begin();
  MPU_WIRE.setClock(400000);

  MPU_WIRE.beginTransmission(MPU_ADDR);              // WHO_AM_I = 0x68
  MPU_WIRE.write(0x75);
  MPU_WIRE.endTransmission(false);
  MPU_WIRE.requestFrom((int)MPU_ADDR, 1);
  if (MPU_WIRE.read() != 0x68) {
    Serial.println("MPU6050 not detected");
    while (1);
  }

  _mpu_write(0x6B, 0x01);   // ปลุก + PLL gyro-X
  delay(50);
  _mpu_write(0x1A, 0x03);   // DLPF ~44Hz
  _mpu_write(0x19, 0x00);   // SMPLRT 1kHz
  _mpu_write(0x1B, 0x00);   // ±250 dps
  delay(50);

  _mpu_calibrateBias(1000); // ★ หุ่นต้องนิ่งสนิท ~2 วินาที
  _mpu_yawAccum = 0.0;
  _mpu_lastUs   = micros();
}

inline float mpu_getYawRaw() {
  unsigned long now = micros();
  float dt = (now - _mpu_lastUs) / 1000000.0f;
  _mpu_lastUs = now;
  if (dt < 0)     dt = 0;
  if (dt > 0.05f) dt = 0;                            // กันค่ากระโดดถ้าเว้นนาน

  int16_t raw = _mpu_readGyroZraw();
  float   err = raw - _mpu_gyroZbias;

  if (fabs(err) < (1.5f * _MPU_LSB_PER_DPS))         // ZUPT ตอนหุ่นนิ่ง
    _mpu_gyroZbias += 0.002f * err;

  float rate = (err / _MPU_LSB_PER_DPS) * MPU_YAW_SIGN;
  _mpu_yawAccum += (double)rate * dt;

  double y = fmod(_mpu_yawAccum, 360.0);
  if (y < 0) y += 360.0;
  return (float)y;
}

// โบนัส: roll/pitch จาก accel (ไม่ดริฟต์) — yaw ใช้ไม่ได้
inline void mpu_getRollPitch(float &roll, float &pitch) {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(0x3B);
  MPU_WIRE.endTransmission(false);
  MPU_WIRE.requestFrom((int)MPU_ADDR, 6);
  int16_t ax = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t ay = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t az = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  roll  = atan2((float)ay, (float)az) * 57.2958f;
  pitch = atan2(-(float)ax, sqrt((float)ay*ay + (float)az*az)) * 57.2958f;
}
