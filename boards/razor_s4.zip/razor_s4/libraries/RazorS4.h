#pragma once
#include <Arduino.h>
#include <Wire.h>
#include "motor_razors4.h"   //ใส่แบบ  "  "   = หาในโปรเจก    <  > = หาทั้งหมด
#include "myoled.h"
#include "mcp3008.h"
#include "razors4_servo.h"
#include "razors4_linesensor.h"
#include "razors4_ultrasonic.h"
#include "razors4_imu.h"      // ← ตัวสลับ IMU (BNO055 / MPU6050) แทน razors4_bno055.h เดิม


//------------------------------สวิทช์-----------------------------

inline void Beep()
{
  int buzzer = 9;
  pinMode(buzzer,OUTPUT);
  tone(buzzer, 1000); // 1000 Hz
  delay(200);

  noTone(buzzer); // หยุดเสียง
  delay(100);
}

inline void sw_go()
{
  pinMode(10,INPUT_PULLUP);
  while(true)
  {
    if(digitalRead(10)==LOW)   // กดปุ่ม
    {
      

      break;   // ออกจากเมนูไปเริ่มโปรแกรม
    }

  }
  Beep();
}

inline bool SW10()
{
  pinMode(10, INPUT_PULLUP);

  return digitalRead(10) == LOW;
}

//-----------------------------------------------------------