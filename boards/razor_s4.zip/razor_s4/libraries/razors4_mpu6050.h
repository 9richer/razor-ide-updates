#pragma once

// ══════════════════════════════════════════════════════════════
//  RazorS4 — MPU6050 IMU Provider  (drop-in แทน BNO055 sensor layer)
//
//  เป้าหมาย: ให้ฟังก์ชัน yaw หน้าตา "เหมือน BNO055 เป๊ะ"
//            → spinTo / MOVE / TurnF_PID ฯลฯ ใช้ต่อได้โดยไม่ต้องแก้
//
//  Hardware:
//    MPU6050 I2C address : 0x68  (AD0=GND)  หรือ 0x69 (AD0=3V3)
//    I2C Bus             : Wire1  (SDA=GP26, SCL=GP27)  ← เหมือน BNO เดิม
//
//  หลักการ:
//    yaw = อินทิเกรต gyro-Z (deg/s) ตามเวลา  (6 แกน ไม่มี mag → ดริฟต์ได้)
//    สู้ดริฟต์ด้วย 3 ด่าน:
//      1) คาลิเบรต bias ตอนเปิดเครื่อง (เฉลี่ย ~1000 ครั้ง ขณะหุ่นนิ่ง)
//      2) DLPF กรองนอยส์ในชิป
//      3) ZUPT — ตอนหุ่นหยุด ค่อย ๆ ปรับ bias ตามจริง (กันดริฟต์สะสม)
//
//  วิธีใช้ (เปลี่ยนแค่ include เดียว):
//    เดิม:  #include "razors4_bno055.h"
//    ใหม่:  #include "razors4_mpu6050.h"
//           // แล้ว COPY ส่วน "MATH + TURN/MOVE" จาก razors4_bno055.h
//           // (ตั้งแต่ normalizeAngle ลงไป) มาต่อท้ายไฟล์นี้ หรือ include แยก
//
//    ในโปรแกรมหลักเรียกเหมือนเดิมทุกอย่าง:
//      initIMU();  calibrateYawStart();  getYaw();  resetYaw();
//
//  ⚠️ ทิศหมุน: ถ้าเลี้ยว "กลับด้าน" กับของเดิม → เปลี่ยน YAW_SIGN เป็น -1
// ══════════════════════════════════════════════════════════════

#include <Wire.h>

// ── ตั้งค่าฮาร์ดแวร์ ───────────────────────────────────────────
#define MPU_ADDR   0x68      // 0x69 ถ้าต่อ AD0 เข้า 3V3
#define MPU_WIRE   Wire1     // บัสเดียวกับ BNO เดิม (GP26/GP27)
#define MPU_SDA    26
#define MPU_SCL    27
#define YAW_SIGN   (+1.0f)   // ถ้าเลี้ยวกลับด้าน เปลี่ยนเป็น -1.0f

// ── Global object (ชื่อเดียวกับของ BNO เพื่อความเข้ากันได้) ──────
float offsetYaw = 0;

// ── สถานะภายใน ────────────────────────────────────────────────
static double        _yawAccum   = 0.0;          // มุมสะสม (จะ wrap ตอนอ่าน)
static float         _gyroZbias  = 0.0f;         // bias (raw LSB)
static unsigned long _lastUs     = 0;
static const float   _LSB_PER_DPS = 131.0f;      // ±250 dps → 131 LSB/(deg/s)

// ── I2C helpers ───────────────────────────────────────────────
static inline void _mpuWrite(uint8_t reg, uint8_t val) {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(reg);
  MPU_WIRE.write(val);
  MPU_WIRE.endTransmission();
}

static inline int16_t _mpuReadGyroZraw() {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(0x47);                     // GYRO_ZOUT_H
  MPU_WIRE.endTransmission(false);          // repeated start
  MPU_WIRE.requestFrom((int)MPU_ADDR, 2);
  int16_t hi = MPU_WIRE.read();
  int16_t lo = MPU_WIRE.read();
  return (int16_t)((hi << 8) | lo);
}

// ── คาลิเบรต gyro-Z bias (หุ่นต้องนิ่งสนิท) ─────────────────────
static inline void _calibrateGyroBias(int samples = 1000) {
  double sum = 0;
  for (int i = 0; i < samples; i++) {
    sum += _mpuReadGyroZraw();
    delay(2);                               // ~2s ที่ 1000 รอบ
  }
  _gyroZbias = (float)(sum / samples);
}

// ══════════════════════════════════════════════════════════════
//  Init  — แทน initIMU() ของ BNO055
// ══════════════════════════════════════════════════════════════
inline void initIMU() {
  MPU_WIRE.setSDA(MPU_SDA);                 // ลบ 3 บรรทัดนี้ได้ถ้าเฟรมเวิร์ก
  MPU_WIRE.setSCL(MPU_SCL);                 // เปิด Wire1 ให้แล้ว
  MPU_WIRE.begin();
  MPU_WIRE.setClock(400000);                // I2C fast mode

  // เช็คว่าเจอชิปไหม (WHO_AM_I = 0x68)
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(0x75);
  MPU_WIRE.endTransmission(false);
  MPU_WIRE.requestFrom((int)MPU_ADDR, 1);
  if (MPU_WIRE.read() != 0x68) {
    Serial.println("MPU6050 not detected");
    while (1);
  }

  _mpuWrite(0x6B, 0x01);   // PWR_MGMT_1: ปลุกชิป + ใช้ PLL จาก gyro-X (นิ่งกว่า)
  delay(50);
  _mpuWrite(0x1A, 0x03);   // CONFIG: DLPF ~44Hz (กรองนอยส์/สั่นมอเตอร์)
  _mpuWrite(0x19, 0x00);   // SMPLRT_DIV: 1kHz
  _mpuWrite(0x1B, 0x00);   // GYRO_CONFIG: ±250 dps (ละเอียดสุด เหมาะหุ่นช้า)
  delay(50);

  _calibrateGyroBias(1000);                 // ★ หัวใจของความนิ่ง — หุ่นต้องอยู่นิ่ง!
  _yawAccum = 0.0;
  _lastUs   = micros();
}

// ══════════════════════════════════════════════════════════════
//  อ่านมุม  — หน้าตาเหมือน BNO055 เป๊ะ (0–360)
//
//  ★ อินทิเกรตตอน "อ่าน" โดยใช้ dt จาก micros()
//    → ต้องเรียก getYaw()/getYawRaw() ถี่ ๆ (ลูป PID ของคุณเรียกทุก ~4ms = โอเค)
// ══════════════════════════════════════════════════════════════
inline float getYawRaw() {
  unsigned long now = micros();
  float dt = (now - _lastUs) / 1000000.0f;
  _lastUs = now;
  if (dt < 0)     dt = 0;
  if (dt > 0.05f) dt = 0;                    // กันค่ากระโดดถ้ามีช่วงเว้นนาน

  int16_t raw = _mpuReadGyroZraw();
  float   err = raw - _gyroZbias;            // หัก bias (หน่วย LSB)

  // ── ZUPT: ถ้าหุ่นแทบไม่หมุน (±1.5 dps) ค่อย ๆ ปรับ bias ตามจริง ──
  if (fabs(err) < (1.5f * _LSB_PER_DPS)) {
    _gyroZbias += 0.002f * err;              // ดึง bias เข้าหาค่าจริงช้า ๆ
  }

  float rate = (err / _LSB_PER_DPS) * YAW_SIGN;   // deg/s
  _yawAccum += (double)rate * dt;                 // อินทิเกรต

  // wrap 0–360
  double y = fmod(_yawAccum, 360.0);
  if (y < 0) y += 360.0;
  return (float)y;
}

inline float getYaw() {
  float yaw = getYawRaw();
  yaw -= offsetYaw;
  if (yaw < 0)    yaw += 360;
  if (yaw >= 360) yaw -= 360;
  return yaw;
}

// ══════════════════════════════════════════════════════════════
//  Calibrate / Reset  — ชื่อ+พฤติกรรมเหมือน BNO055
// ══════════════════════════════════════════════════════════════
inline void calibrateYawStart() {           // ตั้งทิศเริ่มต้น (เฉลี่ย 20 ครั้ง)
  float sum = 0;
  for (int i = 0; i < 20; i++) {
    sum += getYawRaw();
    delay(2);
  }
  offsetYaw = sum / 20.0;
}

inline void resetYaw(int samples = 10) {
  if (samples <= 1) { offsetYaw = getYawRaw(); return; }
  float sum = 0;
  for (int i = 0; i < samples; i++) {
    sum += getYawRaw();
    delay(2);
  }
  offsetYaw = sum / (float)samples;
}

inline void recalibrateAxisFast() { offsetYaw = getYawRaw(); }

// ══════════════════════════════════════════════════════════════
//  (โบนัส) roll/pitch จาก accel — yaw ใช้ไม่ได้ แต่ 2 ตัวนี้แม่นไม่ดริฟต์
//  เผื่ออยากเช็คว่าหุ่นเอียง/ตกหลุม
// ══════════════════════════════════════════════════════════════
inline void getRollPitch(float &roll, float &pitch) {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(0x3B);                      // ACCEL_XOUT_H
  MPU_WIRE.endTransmission(false);
  MPU_WIRE.requestFrom((int)MPU_ADDR, 6);
  int16_t ax = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t ay = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  int16_t az = (MPU_WIRE.read() << 8) | MPU_WIRE.read();
  roll  = atan2((float)ay, (float)az) * 57.2958f;
  pitch = atan2(-(float)ax, sqrt((float)ay*ay + (float)az*az)) * 57.2958f;
}

// ══════════════════════════════════════════════════════════════
//  ↓↓↓ COPY ส่วนนี้จาก razors4_bno055.h มาต่อท้าย ↓↓↓
//      (ตั้งแต่ normalizeAngle, shortestAngle, spinTo, MOVE, ...)
//      ทุกฟังก์ชันเรียก getYaw()/getYawRaw()/offsetYaw → ทำงานต่อได้เลย
// ══════════════════════════════════════════════════════════════
