#pragma once

// ══════════════════════════════════════════════════════════════
//  RazorS4 — BNO055 IMU Library
//
//  Hardware:
//    BNO055 I2C address : 0x29
//    I2C Bus            : Wire1  (SDA=GP26, SCL=GP27)
//
//  Dependencies (ต้องมีใน libraries/):
//    Adafruit_BNO055.h + Adafruit_BNO055.cpp
//    utility/imumaths.h, vector.h, matrix.h, quaternion.h
//    Adafruit_BusIO (I2CDevice)
//
//  ใช้งาน:
//    1. ประกาศ bno object และ offsetYaw ใน main sketch
//    2. เรียก initIMU() ใน setup()
//    3. เรียก calibrateYawStart() หลัง initIMU()
//
//  Functions:
//    initIMU()                   — เริ่มใช้งาน BNO055
//    getYawRaw()                 — อ่านมุมดิบ 0–360
//    getYaw()                    — อ่านมุมพร้อม offset
//    calibrateYawStart()         — ตั้งทิศเริ่มต้น (เฉลี่ย 20 ครั้ง)
//    resetYaw()                  — รีเซตทิศ (เฉลี่ย 10 ครั้ง)
//    recalibrateAxisFast()       — รีเซตแบบไว (1 ครั้ง)
//    normalizeAngle(angle)       — แปลงมุมให้อยู่ -180 ถึง 180
//    shortestAngle(cur, target)  — หามุมลัดที่สั้นสุด
//    turnByAngle(angle,kp,kd,min,max)    — เลี้ยวตามองศา PD
//    turnTo(targetYaw)                   — เลี้ยวไปทิศ adaptive PD
//    turnPID_BNO_pivot(...)              — pivot turn หน้า PD
//    turnBPID_BNO_pivot(...)             — pivot turn หลัง PD
//    fd_pidNEW01(dir,yaw,spd,ms,kp,ki,kd,slow) — เดินหน้า PID v1
//    fd_pidNEW02(dir,yaw,spd,ms,kp,ki,kd,slow) — เดินหน้า PID v2 (ramp)
// ══════════════════════════════════════════════════════════════

#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>

// ── Global objects (ประกาศที่นี่ — include ไฟล์นี้ครั้งเดียว) ──
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x29, &Wire1);
float offsetYaw = 0;


// ══════════════════════════════════════════════════════════════
//  Init
// ══════════════════════════════════════════════════════════════

inline void initIMU() {
  if (!bno.begin(OPERATION_MODE_IMUPLUS)) {   // OPERATION_MODE_NDOF ใช้สนามแม่เหล็กโลก
    Serial.println("BNO055 not detected");
    while (1);
  }
  bno.setExtCrystalUse(true);
}


// ══════════════════════════════════════════════════════════════
//  อ่านมุม
// ══════════════════════════════════════════════════════════════

inline float getYawRaw() {
  imu::Vector<3> euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
  return euler.x();   // 0–360
}

inline float getYaw() {
  imu::Vector<3> euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
  float yaw = euler.x();
  yaw -= offsetYaw;
  if (yaw < 0)    yaw += 360;
  if (yaw >= 360) yaw -= 360;
  return yaw;
}


// ══════════════════════════════════════════════════════════════
//  Calibrate / Reset
// ══════════════════════════════════════════════════════════════

inline void calibrateYawStart() {   // ตั้งทิศเริ่มต้น เฉลี่ย 20 ครั้ง
  float sum = 0;
  for (int i = 0; i < 20; i++) {
    sum += getYawRaw();
    delay(2);
  }
  offsetYaw = sum / 20.0;
}

// รีเซตทิศ — ตั้งจำนวนรอบได้  default = 10
// samples=1  → ไว ไม่ delay
// samples=10 → เฉลี่ย 10 ครั้ง แม่นขึ้น (~20ms)
// samples=20 → เฉลี่ย 20 ครั้ง แม่นสุด (~40ms)
inline void resetYaw(int samples = 10) {
  if (samples <= 1) {
    offsetYaw = getYawRaw();
    return;
  }
  float sum = 0;
  for (int i = 0; i < samples; i++) {
    sum += getYawRaw();
    delay(2);
  }
  offsetYaw = sum / (float)samples;
}


// ══════════════════════════════════════════════════════════════
//  Math helpers
// ══════════════════════════════════════════════════════════════

inline float normalizeAngle(float angle) {
  while (angle > 180)  angle -= 360;
  while (angle <= -180) angle += 360;
  return angle;
}

inline float shortestAngle(float currentAngle, float targetAngle) {
  return fmod((targetAngle - currentAngle + 540), 360) - 180;
}


// ══════════════════════════════════════════════════════════════
//  Turn functions
// ══════════════════════════════════════════════════════════════

// เลี้ยวตามองศา PD — เลี้ยวแล้วไม่กลับมา
inline void turnByAngle(float angle, float kp, float kd, int speedMin, int speedMax) {
  float startYaw  = getYaw();
  float targetYaw = startYaw + angle;
  if (targetYaw >= 360) targetYaw -= 360;
  if (targetYaw < 0)    targetYaw += 360;

  float prevError = 0;
  unsigned long lastTime = millis();

  while (1) {
    float currentYaw = getYaw();
    float error = normalizeAngle(targetYaw - currentYaw);
    if (abs(error) < 1.5) break;

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0, 0.001);
    lastTime = now;

    float derivative = (error - prevError) / dt;
    prevError = error;

    float output = kp * error + kd * derivative;
    int speed = constrain(abs(output), speedMin, speedMax);

    if (output > 0) { motorL(speed);  motorR(-speed); }   // เลี้ยวขวา
    else            { motorL(-speed); motorR(speed);  }   // เลี้ยวซ้าย
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  spinTo config — ตั้งครั้งเดียวใน setup()
// ══════════════════════════════════════════════════════════════

struct SpinConfig {
  float kp_fast = 6.0;
  float kp_mid  = 3.5;
  float kp_slow = 1.5;
  float kd      = 0.3;
} _spinCfg;

inline void setSpinConfig(float kp_fast, float kp_mid, float kp_slow, float kd) {
  _spinCfg.kp_fast = kp_fast;
  _spinCfg.kp_mid  = kp_mid;
  _spinCfg.kp_slow = kp_slow;
  _spinCfg.kd      = kd;
}

// ══════════════════════════════════════════════════════════════
//  spinTo — เลี้ยวไปทิศที่กำหนด แม่นสุด (World Frame)
//
//  targetYaw      : ทิศเป้าหมาย (องศา)
//  errorThreshold : หยุดเมื่อ error < ค่านี้  default=1.5
//  timeout_ms     : เวลาสูงสุด ms  default=200 (ป้องกันติด loop)
//  spdMin         : ความเร็วต่ำสุด  default=40
//  spdMax         : ความเร็วสูงสุด  default=70
//
//  adaptive kp: error>30 → kp_fast, error>10 → kp_mid, อื่น → kp_slow
//  settle: ต้องนิ่ง 5 รอบติดต่อกัน (~20ms) ถึงหยุด
// ══════════════════════════════════════════════════════════════

inline void spinTo(float targetYaw,
                   float errorThreshold = 1.5,
                   int timeout_ms = 200,
                   int spdMin = 40,
                   int spdMax = 70) {

  float prevError  = 0;
  float dFilt      = 0;
  int   settleCount = 0;

  unsigned long lastTime  = millis();
  unsigned long startTime = millis();

  while (1) {

    // timeout — ป้องกันติด loop
    if ((millis() - startTime) > (unsigned long)timeout_ms) break;

    float currentYaw = getYaw();   // World Frame
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0f, 0.001f);
    lastTime = now;

    // Derivative + low-pass filter
    float derivative = (error - prevError) / dt;
    derivative = constrain(derivative, -200, 200);
    dFilt      = dFilt * 0.7 + derivative * 0.3;
    prevError  = error;

    // Adaptive kp
    float kp;
    if      (abs(error) > 30) kp = _spinCfg.kp_fast;
    else if (abs(error) > 10) kp = _spinCfg.kp_mid;
    else                      kp = _spinCfg.kp_slow;

    float output = kp * error + _spinCfg.kd * dFilt;
    int speed = constrain((int)abs(output), spdMin, spdMax);

    if (output > 0) { motorL(speed);  motorR(-speed); }
    else            { motorL(-speed); motorR(speed);  }

    // Settle counter — ต้องนิ่ง 5 รอบติดต่อกัน
    if (abs(error) < errorThreshold && abs(dFilt) < 3) {
      if (++settleCount >= 5) break;
    } else {
      settleCount = 0;
    }

    delay(4);
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  TurnF_PID — ดิฟหน้า (pivot หน้า)
//  ล้อซ้ายดัน ล้อขวาหยุด → หมุนรอบล้อขวา
//
//  targetYaw      : ทิศเป้าหมาย (องศา)
//  speedMin       : ความเร็วต่ำสุด
//  speedMax       : ความเร็วสูงสุด
//  kp, kd         : PD gains
//  errorThreshold : หยุดเมื่อ error < ค่านี้ (องศา) default=5.0
//                   ค่ามาก → หยุดเร็ว/หยาบ  ค่าน้อย → แม่นแต่อาจแกว่ง
// ══════════════════════════════════════════════════════════════
inline void TurnF_PID(float targetYaw, int speedMin, int speedMax,
                      float kp, float kd, float errorThreshold = 5.0) {
  float prevError = 0;
  unsigned long lastTime = millis();

  while (1) {
    float currentYaw = getYaw();   // ← World Frame (มี offset)
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0, 0.001);
    lastTime = now;

    float derivative = (error - prevError) / dt;
    float output = kp * error + kd * derivative;
    prevError = error;

    int speed = constrain(abs(output), speedMin, speedMax);

    if (output > 0) { motorL(speed); motorR(5);     }   // หมุนขวา
    else            { motorL(5);     motorR(speed); }   // หมุนซ้าย

    if (abs(error) < errorThreshold) break;
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  TurnB_PID — ดิฟหลัง (pivot หลัง)
//  ล้อซ้ายถอย ล้อขวาหยุด → ท้ายสวิงออก
//
//  targetYaw      : ทิศเป้าหมาย (องศา)
//  speedMin       : ความเร็วต่ำสุด
//  speedMax       : ความเร็วสูงสุด
//  kp, kd         : PD gains
//  errorThreshold : หยุดเมื่อ error < ค่านี้ (องศา) default=5.0
// ══════════════════════════════════════════════════════════════
inline void TurnB_PID(float targetYaw, int speedMin, int speedMax,
                      float kp, float kd, float errorThreshold = 5.0) {
  float prevError = 0;
  unsigned long lastTime = millis();

  while (1) {
    float currentYaw = getYaw();   // ← World Frame (มี offset)
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0, 0.001);
    lastTime = now;

    float derivative = (error - prevError) / dt;
    float output = kp * error + kd * derivative;
    prevError = error;

    int speed = constrain(abs(output), speedMin, speedMax);

    if (output > 0) { motorL(-5);     motorR(-speed); }  // หมุนขวาถอย
    else            { motorL(-speed); motorR(-5);     }  // หมุนซ้ายถอย

    if (abs(error) < errorThreshold) break;
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  fd_pidNEW01 — เดินหน้า/หลัง PID v1
//
//  Movedirection : 0=หน้า  1=หลัง
//  targetYaw     : ทิศที่ต้องการ (องศา)
//  speedBase     : ความเร็วหลัก 0–100
//  duration      : เวลา ms
//  kp, ki, kd    : PID gains
//  Slow          : 1=ชะลอก่อนหยุด  0=ไม่ชะลอ
// ══════════════════════════════════════════════════════════════

inline void fd_pidNEW01(int Movedirection, float targetYaw, int speedBase,
                        float duration, float kp, float ki, float kd, int Slow) {
  unsigned long lastTime = millis();
  unsigned long endTime  = lastTime + (unsigned long)duration;

  float integral  = 0;
  float prevError = 0;

  while (millis() < endTime) {
    float currentYaw = getYaw();
    float error = normalizeAngle(targetYaw - currentYaw);

    unsigned long now = millis();
    float dt = max((now - lastTime) / 1000.0, 0.001);
    lastTime = now;

    integral += error * dt;
    integral  = constrain(integral, -40, 40);

    float derivative = (error - prevError) / dt;
    derivative = constrain(derivative, -200, 200);

    float output = kp * error + ki * integral + kd * derivative;
    prevError = error;

    float maxTurn = speedBase * 0.6;
    output = constrain(output, -maxTurn, maxTurn);

    int base = speedBase;
    if (Slow == 1) {
      long remain = endTime - now;
      if (remain < 300 && remain > 0)
        base = map(remain, 0, 80, 10, speedBase);
    }

    int minSpd      = max(10, (int)(speedBase * 0.4));
    int rightSpeed  = constrain((int)(base - output), minSpd, 100);
    int leftSpeed   = constrain((int)(base + output), minSpd, 100);

    if (Movedirection == 0) { motorL(leftSpeed);   motorR(rightSpeed);  }
    else                    { motorL(-rightSpeed);  motorR(-leftSpeed); }

    delay(5);
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  MOVE — เดินหน้า/ถอยหลัง PID พร้อม ramp up/down
//
//  direction   : 0=เดินหน้า  1=ถอยหลัง
//  targetYaw   : ทิศเป้าหมาย (World Frame องศา)
//  speedBase   : ความเร็วหลัก 0–100
//  duration    : เวลา ms
//  kp, ki, kd  : PID gains
//  rampUp_ms   : เร่งความเร็ว ms (0=พุ่งเลย)   default=0
//  rampDown_ms : ชะลอความเร็ว ms (0=หยุดทันที) default=0
// ══════════════════════════════════════════════════════════════

inline void MOVE(int direction, float targetYaw, int speedBase,
                 float duration, float kp, float ki, float kd,
                 int rampUp_ms = 0, int rampDown_ms = 0, int startSpeed = 30) {

  unsigned long startTime = millis();
  unsigned long lastPID   = millis();
  unsigned long endTime   = startTime + (unsigned long)duration;

  float integral  = 0;
  float prevError = 0;
  float dFilt     = 0;

  while (millis() < endTime) {
    float currentYaw = getYaw();
    float error = shortestAngle(currentYaw, targetYaw);

    unsigned long now = millis();
    float dt = (now - lastPID) / 1000.0;
    if (dt <= 0) dt = 0.001;
    lastPID = now;

    // PID
    integral += error * dt;
    integral  = constrain(integral, -40, 40);
    if (abs(error) < 0.5) integral = 0;

    float derivative = (error - prevError) / dt;
    derivative = constrain(derivative, -200, 200);
    dFilt      = dFilt * 0.7 + derivative * 0.3;
    prevError  = error;

    float output = kp * error + ki * integral + kd * dFilt;
    float maxTurn = speedBase * 0.7;
    output = constrain(output, -maxTurn, maxTurn);

    // Base speed
    float base = speedBase;
    unsigned long elapsed = now - startTime;
    long remain = endTime - now;

    // Ramp up — เร่งจาก startSpeed → speedBase
    if (rampUp_ms > 0 && elapsed < (unsigned long)rampUp_ms) {
      float ramp = (float)elapsed / (float)rampUp_ms;
      base = startSpeed + (speedBase - startSpeed) * ramp;
    }

    // Ramp down
    if (rampDown_ms > 0 && remain < rampDown_ms && remain > 0) {
      float rampDown = constrain((float)remain / (float)rampDown_ms, 0.0, 1.0);
      base = 10 + (speedBase - 10) * rampDown;
    }

    int rightSpeed = constrain((int)(base - output), 0, 100);
    int leftSpeed  = constrain((int)(base + output), 0, 100);

    if (direction == 0) { motorL(leftSpeed);   motorR(rightSpeed);  }
    else                { motorL(-rightSpeed); motorR(-leftSpeed);  }

    delay(4);
  }
  ao();
}

// ══════════════════════════════════════════════════════════════
//  Drop counter — reset ก่อนแข่งทุกรอบ
// ══════════════════════════════════════════════════════════════
static int _dropBack  = 0;
static int _dropFront = 0;

inline void resetDrop() {
  _dropBack  = 0;
  _dropFront = 0;
}

// MOVE_WALL_UNTIL — ลบออกแล้ว (ไม่ได้ใช้)
#if 0
inline void MOVE_WALL_UNTIL(
    int   direction,
    float targetYaw,
    int   speedBase,
    int   startSpeed,
    float stopDist,
    int   trigFront,  int echoFront,
    float kp_yaw,     float kp_wall,
    float wallDist,   int trigSide,  int echoSide,
    int   lineType,
    int   overTime,
    int   pinBack,    int angleBack,
    int   pinFront,   int angleFront,
    int   maxBack,
    int   timeout_ms = 5000) {

  unsigned long startTime = millis();
  unsigned long lastPID   = millis();
  float integral  = 0;
  float prevError = 0;
  float dFilt     = 0;
  bool  greenFound = false;

  while (1) {
    // timeout
    if (timeout_ms > 0 && millis() - startTime > (unsigned long)timeout_ms) break;

    // sonar หน้า
    float distFront = sonarRead(trigFront, echoFront);
    if (distFront > 0 && distFront < stopDist) break;

    // เช็คพื้นเขียว
    bool frontSee = sensorOnLine(0, lineType) || sensorOnLine(1, lineType);

    if (frontSee && !greenFound) {
      greenFound = true;
      ao();

      // U-Turn
      spinTo(targetYaw + 180, 1.5, 300, 40, 70);

      // เดินต่ออีก overTime ms
      unsigned long overStart = millis();
      while (millis() - overStart < (unsigned long)overTime) {
        float cy  = getYaw();
        float ey  = shortestAngle(cy, targetYaw + 180);
        float out = constrain(kp_yaw * ey, -(speedBase * 0.7f), speedBase * 0.7f);
        int L = constrain((int)(speedBase + out), 0, 100);
        int R = constrain((int)(speedBase - out), 0, 100);
        motorL(L); motorR(R);
        delay(4);
      }
      ao();

      // ปล่อย
      if (_dropBack < maxBack) {
        servoFast(pinBack,  angleBack);
        _dropBack++;
      } else {
        servoFast(pinFront, angleFront);
        _dropFront++;
      }

      delay(200);

      // กลับทิศเดิม
      spinTo(targetYaw, 1.5, 300, 40, 70);
      greenFound = false;
    }

    // BNO + Sonar PID
    unsigned long now = millis();
    float dt = (now - lastPID) / 1000.0f;
    if (dt <= 0) dt = 0.001f;
    lastPID = now;

    float error_yaw = shortestAngle(getYaw(), targetYaw);
    integral += error_yaw * dt;
    integral  = constrain(integral, -40, 40);
    if (abs(error_yaw) < 0.5f) integral = 0;

    float deriv = (error_yaw - prevError) / dt;
    dFilt     = dFilt * 0.7f + constrain(deriv, -200, 200) * 0.3f;
    prevError = error_yaw;

    float output = kp_yaw * error_yaw + 0.05f * integral + 0.1f * dFilt;

    float distSide = sonarRead(trigSide, echoSide);
    if (distSide > 0) output += kp_wall * (distSide - wallDist);

    output = constrain(output, -(speedBase * 0.7f), speedBase * 0.7f);

    unsigned long elapsed = now - startTime;
    float base = (elapsed < 150)
      ? startSpeed + (speedBase - startSpeed) * ((float)elapsed / 150.0f)
      : speedBase;

    int R = constrain((int)(base - output), 0, 100);
    int L = constrain((int)(base + output), 0, 100);

    if (direction == 0) { motorL(L); motorR(R); }
    else                { motorL(-R); motorR(-L); }

    delay(4);
  }
  ao();
}
#endif  // MOVE_WALL_UNTIL disabled

// ══════════════════════════════════════════════════════════════
//  MOVE_LOOP / MOVE_WALL_LOOP
//  เดินตลอดจนกว่าจะ break จากข้างนอก
//  ไม่มี duration — วิ่งไปเรื่อยๆ 1 cycle (~4ms) ต่อการเรียก
//
//  MOVE_LOOP      → BNO055 อย่างเดียว
//  MOVE_WALL_LOOP → BNO055 + Sonar รักษาระยะกำแพง
//
//  ใช้งาน:
//    MOVE_LOOP_RESET();
//    while(true) {
//      if(เงื่อนไข) { ao(); break; }
//      MOVE_LOOP(...);        หรือ MOVE_WALL_LOOP(...)
//    }
// ══════════════════════════════════════════════════════════════

static unsigned long _tick_lastPID   = 0;
static unsigned long _tick_startTime = 0;
static float _tick_integral  = 0;
static float _tick_prevError = 0;
static float _tick_dFilt     = 0;

inline void MOVE_LOOP_RESET() {
  _tick_startTime = millis();
  _tick_lastPID   = millis();
  _tick_integral  = 0;
  _tick_prevError = 0;
  _tick_dFilt     = 0;
}

// ── PID core — ใช้ร่วมกันทั้ง 2 function ─────────────────────
inline float _move_loop_pid(float targetYaw, int speedBase, float kp, float kd) {
  unsigned long now = millis();
  float dt = (now - _tick_lastPID) / 1000.0f;
  if (dt <= 0) dt = 0.001f;
  _tick_lastPID = now;

  float error_yaw = shortestAngle(getYaw(), targetYaw);

  _tick_integral += error_yaw * dt;
  _tick_integral  = constrain(_tick_integral, -40, 40);
  if (abs(error_yaw) < 0.5f) _tick_integral = 0;

  float deriv     = constrain((error_yaw - _tick_prevError) / dt, -200, 200);
  _tick_dFilt     = _tick_dFilt * 0.7f + deriv * 0.3f;
  _tick_prevError = error_yaw;

  float output = kp * error_yaw + 0.05f * _tick_integral + kd * _tick_dFilt;
  return constrain(output, -(speedBase * 0.7f), speedBase * 0.7f);
}

inline float _move_loop_base(int speedBase, int startSpeed) {
  unsigned long elapsed = millis() - _tick_startTime;
  return (elapsed < 150)
    ? startSpeed + (speedBase - startSpeed) * ((float)elapsed / 150.0f)
    : (float)speedBase;
}

// ══════════════════════════════════════════════════════════════
//  MOVE_LOOP — BNO055 อย่างเดียว
// ══════════════════════════════════════════════════════════════
inline void MOVE_LOOP(
    int   direction,
    float targetYaw,
    int   speedBase,
    float kp_yaw,
    float kd_yaw    = 0,
    int   startSpeed = 10) {

  float output = _move_loop_pid(targetYaw, speedBase, kp_yaw, kd_yaw);
  output = constrain(output, -(speedBase * 0.7f), speedBase * 0.7f);
  float base = _move_loop_base(speedBase, startSpeed);

  int R = constrain((int)(base - output), 0, 100);
  int L = constrain((int)(base + output), 0, 100);

  if (direction == 0) { motorL(L); motorR(R); }
  else                { motorL(-R); motorR(-L); }

  delay(1);
}

// ══════════════════════════════════════════════════════════════
//  MOVE_WALL_LOOP — BNO055 + Sonar รักษาระยะกำแพง
// ══════════════════════════════════════════════════════════════
inline void MOVE_WALL_LOOP(
    int   direction,
    float targetYaw,
    int   speedBase,
    float kp_yaw,
    float kp_wall,
    float targetDist,
    int   trigPin,
    int   echoPin,
    int   startSpeed = 30) {

  float output = _move_loop_pid(targetYaw, speedBase, kp_yaw, 0);

  float dist = sonarRead(trigPin, echoPin);
  if (dist > 0) output += kp_wall * (dist - targetDist);

  output = constrain(output, -(speedBase * 0.7f), speedBase * 0.7f);
  float base = _move_loop_base(speedBase, startSpeed);

  int R = constrain((int)(base - output), 0, 100);
  int L = constrain((int)(base + output), 0, 100);

  if (direction == 0) { motorL(L); motorR(R); }
  else                { motorL(-R); motorR(-L); }

  delay(4);
}