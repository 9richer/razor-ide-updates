// functions.cpp — board-level helper functions
// หมายเหตุ: motorL(), motorR(), ao(), sr(), sl(), tr(), tl()
// ถูกนิยามเป็น inline ใน motor_razors4.h แล้ว — ไม่ต้องนิยามซ้ำที่นี่
// ไฟล์นี้จำเป็นต้องมีเพื่อ arduino-cli รู้ว่ามี .cpp อยู่ในโปรเจค
