#pragma once
#include <Arduino.h>

// ══════════════════════════════════════════════════════════════
//  razors2_encoder.h — Wheel Encoder (ESP32) + MOVE_ENC
//
//  นับพัลส์ล้อด้วย attachInterrupt (ช่องเดียว/ล้อ — รู้ทิศจากคำสั่งมอเตอร์)
//  ใช้วัด "ระยะทาง" ให้ MOVE_ENC จบด้วยระยะ (cm) แทนเวลา
//
//  ⚠ ลำดับ include: ต้องอยู่ "หลัง" S2_motor.h / razors2_imu.h
//    (ใช้ motorL/motorR/ao · getYaw/shortestAngle)
//  ⚠ ต้องตั้งขาด้วยบล็อก "ตั้งขา encoder" (setupEncoder) ใน Setup ก่อนใช้ MOVE_ENC
//    ขา GPIO ที่ว่าง + มี pull-up: 18, 19, 23, 5, 13(A8), 14(A9)
//    ห้ามใช้ขาเซนเซอร์เส้น / มอเตอร์ (2,4,16,17) / I2C (21,22)
// ══════════════════════════════════════════════════════════════

static volatile long _encCntL = 0;
static volatile long _encCntR = 0;
static int   _encPinL = -1, _encPinR = -1;
static float _encTicksPerCm = 20.0f;   // pulse ต่อ 1 ซม. (ต้องคาลิเบรตตามล้อ/encoder)

void IRAM_ATTR _encISR_L() { _encCntL++; }
void IRAM_ATTR _encISR_R() { _encCntR++; }

// ── ตั้งขา + จำนวน pulse ต่อ cm (เรียกใน Setup ครั้งเดียว) ────
inline void setupEncoder(int pinL, int pinR, float ticksPerCm) {
  _encPinL = pinL;
  _encPinR = pinR;
  if (ticksPerCm > 0) _encTicksPerCm = ticksPerCm;
  _encCntL = 0; _encCntR = 0;
  // ต่อ interrupt เฉพาะล้อที่เลือกใช้ (เลือก "ไม่มี" = -1 ข้ามได้ → ใช้ 1 หรือ 2 ตัวก็ได้)
  if (pinL >= 0) {
    pinMode(pinL, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(pinL), _encISR_L, RISING);
  }
  if (pinR >= 0) {
    pinMode(pinR, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(pinR), _encISR_R, RISING);
  }
}

inline long encCountL() { return _encCntL; }
inline long encCountR() { return _encCntR; }
inline void encReset()  { _encCntL = 0; _encCntR = 0; }

// ระยะทาง (cm) — เฉลี่ยเฉพาะล้อที่ต่อ encoder (1 หรือ 2 ตัว)
//   นับขึ้นอย่างเดียว ทิศรู้จากคำสั่งมอเตอร์
inline float encDistanceCm() {
  long sum = 0; int n = 0;
  if (_encPinL >= 0) { sum += _encCntL; n++; }
  if (_encPinR >= 0) { sum += _encCntR; n++; }
  if (n == 0) return 0;
  return (float)(sum / n) / _encTicksPerCm;
}

// ══════════════════════════════════════════════════════════════
//  MOVE_ENC — เหมือน MOVE (PID ยึดทิศไจโร) แต่จบด้วย "ระยะ (cm)"
//    ramp เร่ง/ชะลอ คิดเป็นระยะทาง (cm) ด้วย
//  ⚠ กันหุ่นวิ่งหนี: ถ้าไม่ขยับ 2 วิ (ยังไม่ setup / encoder ไม่มา / ล้อติด) → หยุด
// ══════════════════════════════════════════════════════════════
inline void MOVE_ENC(int direction, float targetYaw, int speedBase,
                     float distanceCm, float kp, float ki, float kd,
                     float rampUpCm = 0, float rampDownCm = 0, int startSpeed = 30) {
  unsigned long lastPID = millis();
  float integral = 0, prevError = 0, dFilt = 0;

  encReset();
  float lastDist = 0;
  unsigned long lastProgress = millis();

  while (encDistanceCm() < distanceCm) {
    float cur   = getYaw();
    float error = shortestAngle(cur, targetYaw);
    unsigned long now = millis();
    float dt = (now - lastPID) / 1000.0;
    if (dt <= 0) dt = 0.001;
    lastPID = now;

    integral += error * dt;
    integral = constrain(integral, -40, 40);
    if (fabs(error) < 0.5) integral = 0;

    float deriv = (error - prevError) / dt;
    deriv = constrain(deriv, -200, 200);
    dFilt = dFilt * 0.7 + deriv * 0.3;
    prevError = error;

    float output  = kp * error + ki * integral + kd * dFilt;
    float maxTurn = speedBase * 0.7;
    output = constrain(output, -maxTurn, maxTurn);

    // base speed + ramp เร่ง/ชะลอ (คิดเป็นระยะทาง cm)
    float traveled = encDistanceCm();
    float remain   = distanceCm - traveled;
    float base     = speedBase;
    if (rampUpCm > 0 && traveled < rampUpCm) {
      base = startSpeed + (speedBase - startSpeed) * (traveled / rampUpCm);
    }
    if (rampDownCm > 0 && remain < rampDownCm && remain > 0) {
      float rd = constrain(remain / rampDownCm, 0.0f, 1.0f);
      base = 10 + (speedBase - 10) * rd;
    }

    // กันวิ่งหนี — ตรวจว่ามีความคืบหน้าไหม
    if (traveled > lastDist + 0.05f) { lastDist = traveled; lastProgress = now; }
    else if (now - lastProgress > 2000) break;

    int R = constrain((int)(base - output), 0, 100);
    int L = constrain((int)(base + output), 0, 100);
    if (direction == 0) { motorL(L);  motorR(R);  }
    else                { motorL(-R); motorR(-L); }
    delay(4);
  }
  ao(); delay(20);
}

// ══════════════════════════════════════════════════════════════
//  LINE_MOVE_ENC — ตามเส้น + ไจโร (เหมือน LINE_MOVE) แต่จบด้วย "ระยะ (cm)"
//    ramp เร่ง/ชะลอ คิดเป็นระยะทาง (cm) ด้วย
//  ⚠ ต้อง setupLineFront/Back + calibrate เส้น + setupEncoder ก่อน
//  ⚠ กันหุ่นวิ่งหนี: ไม่ขยับ 2 วิ (ยังไม่ setup / encoder ไม่มา / ล้อติด) → หยุด
// ══════════════════════════════════════════════════════════════
inline void LINE_MOVE_ENC(int direction, float targetYaw, int speedBase,
                          float distanceCm, float kpLine, float kdLine,
                          float kpYaw, float kdYaw,
                          float rampUpCm = 0, float rampDownCm = 0,
                          int startSpeed = 30) {
  unsigned long lastPID = millis();
  float prevErrLine = 0, prevErrYaw = 0, dFiltYaw = 0, dFiltLine = 0;

  int lnFrom = (direction == 0) ? _lnFrontFrom : _lnBackFrom;
  int lnTo   = (direction == 0) ? _lnFrontTo   : _lnBackTo;
  int lnType = (direction == 0) ? _lnFrontType : _lnBackType;

  encReset();
  float lastDist = 0;
  unsigned long lastProgress = millis();

  while (encDistanceCm() < distanceCm) {
    unsigned long now = millis();
    float dt = (now - lastPID) / 1000.0;
    if (dt <= 0) dt = 0.001;
    lastPID = now;

    // ── PID เส้น (กรอง D กันกระตุก) ──
    float errLine = linePosition(lnFrom, lnTo, lnType);
    if (direction == 1 && _lnBackFlip) errLine = -errLine;
    float dLine   = errLine - prevErrLine;
    dFiltLine     = dFiltLine * 0.7 + dLine * 0.3;
    float outLine = kpLine * errLine + kdLine * dFiltLine;
    prevErrLine   = errLine;

    // ── PID ไจโร ──
    float errYaw = shortestAngle(getYaw(), targetYaw);
    float dYaw   = constrain((errYaw - prevErrYaw) / dt, -200.0, 200.0);
    dFiltYaw     = dFiltYaw * 0.7 + dYaw * 0.3;
    prevErrYaw   = errYaw;
    float outYaw = kpYaw * errYaw + kdYaw * dFiltYaw;

    float output  = outLine + outYaw;
    float maxTurn = speedBase;
    output = constrain(output, -maxTurn, maxTurn);

    // ── base + ramp เร่ง/ชะลอ (คิดเป็นระยะทาง cm) ──
    float traveled = encDistanceCm();
    float remain   = distanceCm - traveled;
    float base     = speedBase;
    if (rampUpCm > 0 && traveled < rampUpCm) {
      base = startSpeed + (speedBase - startSpeed) * (traveled / rampUpCm);
    }
    if (rampDownCm > 0 && remain < rampDownCm && remain > 0) {
      float r = constrain(remain / rampDownCm, 0.0f, 1.0f);
      base = 10 + (speedBase - 10) * r;
    }

    // ── กันวิ่งหนี ──
    if (traveled > lastDist + 0.05f) { lastDist = traveled; lastProgress = now; }
    else if (now - lastProgress > 2000) break;

    int leftSpeed  = constrain((int)(base + output), 0, 100);
    int rightSpeed = constrain((int)(base - output), 0, 100);
    if (direction == 0) { motorL(leftSpeed);   motorR(rightSpeed); }
    else                { motorL(-rightSpeed); motorR(-leftSpeed); }
    delay(4);
  }
  ao();
}

// ══════════════════════════════════════════════════════════════
//  LINE_BACK_ENC — ถอยตามเส้น (ไม่มีไจโร) เลือกช่วงเซนเซอร์ในตัว
//                  จบด้วย "ระยะ (cm)" จาก encoder
//    ธรรมเนียมมอเตอร์ = ถอยแบบ LINE_MOVE (สลับ+กลับขั้ว) → flip ตรงกับบล็อกไจโร
//  ⚠ ไม่ต้อง setupLineBack — ใส่ from/to/สี/flip มาในบล็อกเลย
//  ⚠ ต้อง calibrate เส้น + setupEncoder ก่อน
//  ⚠ ถอยด้วยเซนเซอร์หน้า = sensor อยู่ท้ายทิศ → ส่ายง่าย: speed ต่ำ + kd สูงหน่อย
//  ⚠ กันวิ่งหนี: ไม่ขยับ 2 วิ (encoder ไม่มา/ล้อติด) → หยุด
// ══════════════════════════════════════════════════════════════
inline void LINE_BACK_ENC(int chFrom, int chTo, int lineType, int backFlip,
                          int speedBase, float distanceCm, float kp, float kd,
                          float rampUpCm = 0, float rampDownCm = 0,
                          int startSpeed = 30) {
  unsigned long lastPID = millis();
  float prevErrLine = 0, dFiltLine = 0;

  encReset();
  float lastDist = 0;
  unsigned long lastProgress = millis();

  while (encDistanceCm() < distanceCm) {
    unsigned long now = millis();
    float dt = (now - lastPID) / 1000.0;
    if (dt <= 0) dt = 0.001;
    lastPID = now;

    // ── PID เส้น (กรอง D กันกระตุก) ──
    float errLine = linePosition(chFrom, chTo, lineType);
    if (backFlip) errLine = -errLine;
    float dLine   = errLine - prevErrLine;
    dFiltLine     = dFiltLine * 0.7 + dLine * 0.3;
    float output  = kp * errLine + kd * dFiltLine;
    prevErrLine   = errLine;

    float maxTurn = speedBase;
    output = constrain(output, -maxTurn, maxTurn);

    // ── base + ramp เร่ง/ชะลอ (คิดเป็นระยะทาง cm) ──
    float traveled = encDistanceCm();
    float remain   = distanceCm - traveled;
    float base     = speedBase;
    if (rampUpCm > 0 && traveled < rampUpCm) {
      base = startSpeed + (speedBase - startSpeed) * (traveled / rampUpCm);
    }
    if (rampDownCm > 0 && remain < rampDownCm && remain > 0) {
      float r = constrain(remain / rampDownCm, 0.0f, 1.0f);
      base = 10 + (speedBase - 10) * r;
    }

    // ── กันวิ่งหนี ──
    if (traveled > lastDist + 0.05f) { lastDist = traveled; lastProgress = now; }
    else if (now - lastProgress > 2000) break;

    int leftSpeed  = constrain((int)(base + output), 0, 100);
    int rightSpeed = constrain((int)(base - output), 0, 100);
    motorL(-rightSpeed);   // ถอย: สลับ+กลับขั้ว (เหมือน LINE_MOVE ตอนถอย)
    motorR(-leftSpeed);
    delay(4);
  }
  ao();
}
