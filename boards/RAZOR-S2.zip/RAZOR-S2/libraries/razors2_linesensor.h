#pragma once
#include <Arduino.h>
#include <EEPROM.h>

// ══════════════════════════════════════════════════════════════
//  RazorS2 (ESP32) — Line Sensor + PID + Line+Gyro
//  พอร์ตจาก RAZOR-S3 → อ่าน analog ตรงจากขา ESP32 (ไม่ใช่ MCP3008)
//
//  พอร์ต A0–A7 = GPIO 39,34,32,35,25,33,27,26  (12-bit 0–4095)
//    ⚠ A4/25, A6/27, A7/26 อยู่บน ADC2 — ใช้ได้เมื่อ "ไม่เปิด WiFi"
//      (ถ้าต้อง 8 ตัวพร้อม WiFi ต้องสลับไปขา ADC1 เท่านั้น)
//
//  ลำดับ include: ต้องอยู่หลัง S2_motor.h / S2_oled.h / razors2_imu.h
//    (ใช้ motorL/motorR/ao · oled_* · getYaw/shortestAngle)
//
//  EEPROM (ESP32, size 256 ใช้ร่วมกับ color):
//    0 – 31  : Line sensor (LineCalEE)   ← ของไฟล์นี้
//    64 –    : Color sensor (TcsCalEE)
// ══════════════════════════════════════════════════════════════

#define LINE_BUZ        12        // buzzer
#define LINE_EE_SIZE    256       // ⚠ ต้องเท่ากับ TCS_EE_SIZE (กัน commit ลบกัน)
#define LINE_EE_ADDR    0
#define LINE_EE_MAGIC   0xA55A
#define LINE_MAXV       4095      // ESP32 ADC 12-bit

// แมปช่อง A0–A7 → ขา GPIO (ตาม schematic RAZOR-S2)
static const uint8_t _lineGPIO[8] = { 39, 34, 32, 35, 25, 33, 27, 26 };

static uint16_t _lineRef[8] = { 2000,2000,2000,2000,2000,2000,2000,2000 };

// ── อ่านค่าดิบ 1 ช่อง (0–4095) ──────────────────────────────
inline int _lineRead(int ch) {
  if (ch < 0 || ch > 7) return 0;
  return analogRead(_lineGPIO[ch]);
}
inline int getRef(int ch) {
  if (ch < 0 || ch > 7) return 0;
  return _lineRef[ch];
}

// ══════════════════════════════════════════════════════════════
//  EEPROM — บันทึก/โหลดค่ากลาง (ESP32: begin/put/commit)
// ══════════════════════════════════════════════════════════════
struct LineCalEE {
  uint16_t magic;
  uint16_t ref[8];
};

inline void saveLineCal() {
  LineCalEE ee;
  ee.magic = LINE_EE_MAGIC;
  for (int i = 0; i < 8; i++) ee.ref[i] = _lineRef[i];
  EEPROM.begin(LINE_EE_SIZE);
  EEPROM.put(LINE_EE_ADDR, ee);
  EEPROM.commit();
}

inline bool loadLineCal() {
  LineCalEE ee;
  EEPROM.begin(LINE_EE_SIZE);
  EEPROM.get(LINE_EE_ADDR, ee);
  if (ee.magic != LINE_EE_MAGIC) return false;
  for (int i = 0; i < 8; i++) _lineRef[i] = ee.ref[i];
  return true;
}

// ══════════════════════════════════════════════════════════════
//  autoScanSensor — กวาดหาค่ากลาง + โชว์ OLED 128×32 + เซฟ
//    duration_ms : เวลา scan (แนะนำ 3000–5000) — ลากหุ่นคร่อมเส้นไปมา
// ══════════════════════════════════════════════════════════════
inline void autoScanSensor(int duration_ms = 5000) {
  int maxV[8], minV[8];
  for (int i = 0; i < 8; i++) { maxV[i] = 0; minV[i] = LINE_MAXV; }

  oled_clear();
  oled(1, "Calibrating...", 1);
  oled(2, "move over line", 1);
  oled_update();
  pinMode(LINE_BUZ, OUTPUT);
  buzzBeep(200); delay(300);

  unsigned long t0 = millis();
  while (millis() - t0 < (unsigned long)duration_ms) {
    for (int i = 0; i < 8; i++) {
      int v = _lineRead(i);
      if (v > maxV[i]) maxV[i] = v;
      if (v < minV[i]) minV[i] = v;
    }
    int barW = map((int)(millis() - t0), 0, duration_ms, 0, 100);
    oled_clear();
    oled(1, "Calibrating...", 1);
    oled_progress(0, 20, 100, 10, barW);
    oled_update();
    delay(15);
  }

  for (int i = 0; i < 8; i++) _lineRef[i] = (maxV[i] + minV[i]) / 2;
  saveLineCal();

  oled_clear();
  oled(1, "Calibrate DONE", 1);
  oled(2, "saved to EEPROM", 1);
  oled_update();
  buzzBeep(200); delay(200);
  buzzBeep(200); delay(200);
}

// ══════════════════════════════════════════════════════════════
//  อ่านสถานะเซนเซอร์
//    lineType: 0 = ดำ/พื้นขาว,  1 = ขาว/พื้นดำ
// ══════════════════════════════════════════════════════════════
inline bool sensorOnLine(int ch, int lineType = 0) {
  int raw = _lineRead(ch);
  int ref = _lineRef[ch];
  if (lineType == 0) return raw < ref;   // ดำสะท้อนน้อย = ต่ำกว่า ref
  else               return raw > ref;
}

inline int countSensors(int chFrom, int chTo, int lineType = 0) {
  int count = 0;
  for (int i = chFrom; i <= chTo; i++)
    if (sensorOnLine(i, lineType)) count++;
  return count;
}

// ── ตำแหน่งเส้น weighted average (-100..+100 · 0=กลาง) ───────
inline int linePosition(int chFrom, int chTo, int lineType = 0) {
  int n = chTo - chFrom + 1;
  if (n <= 0) return 0;

  long sumW = 0, sumS = 0;
  for (int i = chFrom; i <= chTo; i++) {
    int raw = _lineRead(i);
    int ref = _lineRef[i];
    if (ref <= 0 || ref >= LINE_MAXV) continue;   // เซนเซอร์เสีย/หลุดสาย → ไม่โหวต (กันหารศูนย์)

    // เฉพาะเซนเซอร์ที่ "เห็นเส้น" (raw ข้าม ref) เท่านั้นที่โหวต
    //  ตัวที่อยู่บนพื้น → pct = 0 สนิท (กัน baseline bias ทำให้เยื้องข้าง)
    int pct;
    if (lineType == 0) {  // ดำ/พื้นขาว — เห็นเส้น = raw ต่ำกว่า ref
      pct = (raw < ref) ? map(raw, 0, ref, 100, 0) : 0;
    } else {              // ขาว/พื้นดำ — เห็นเส้น = raw สูงกว่า ref
      pct = (raw > ref) ? map(raw, ref, LINE_MAXV, 0, 100) : 0;
    }

    int weight = map(i, chFrom, chTo, -100, 100);
    sumW += (long)pct * weight;
    sumS += pct;
  }
  if (sumS == 0) return 0;
  return (int)(sumW / sumS);
}

// ══════════════════════════════════════════════════════════════
//  Line Follow PID — ตั้งค่าหน้า/หลัง (Setup) แล้วเรียก PID ใน loop
// ══════════════════════════════════════════════════════════════
static int   _lnFrontFrom = 0, _lnFrontTo = 7, _lnFrontType = 0;
static int   _lnBackFrom  = 4, _lnBackTo  = 7, _lnBackType  = 0, _lnBackFlip = 0;
static float _lnPrevErrF = 0, _lnPrevErrB = 0;

inline void setupLineFront(int from, int to, int lineType) {
  _lnFrontFrom = from; _lnFrontTo = to; _lnFrontType = lineType;
}
inline void setupLineBack(int from, int to, int lineType, int backFlip) {
  _lnBackFrom = from; _lnBackTo = to; _lnBackType = lineType; _lnBackFlip = backFlip;
}

// เดินหน้า 1 รอบ — เซนเซอร์ชุดหน้า
inline void linePID_front(int baseSpeed, float kp, float kd) {
  int   error  = linePosition(_lnFrontFrom, _lnFrontTo, _lnFrontType);
  float output = kp * error + kd * (error - _lnPrevErrF);
  _lnPrevErrF  = error;
  motorL(constrain(baseSpeed + (int)output, -100, 100));
  motorR(constrain(baseSpeed - (int)output, -100, 100));
}

// ถอยหลัง 1 รอบ — เซนเซอร์ชุดหลัง
inline void linePID_back(int baseSpeed, float kp, float kd) {
  int error = linePosition(_lnBackFrom, _lnBackTo, _lnBackType);
  if (_lnBackFlip) error = -error;
  float output = kp * error + kd * (error - _lnPrevErrB);
  _lnPrevErrB  = error;
  motorL(-constrain(baseSpeed + (int)output, -100, 100));
  motorR(-constrain(baseSpeed - (int)output, -100, 100));
}

// ══════════════════════════════════════════════════════════════
//  LINE_MOVE — เดินตามเส้น + ไจโรยึดทิศ (ผสม PID 2 ชุด) + ramp + time
//  signature: LINE_MOVE(dir, yaw, speed, time, kpLine, kdLine, kpYaw, kdYaw, rampUp, rampDown, startSpeed)
//    dir : 0=เดินหน้า(เซนเซอร์หน้า)  1=ถอยหลัง(เซนเซอร์หลัง)
//  ⚠ ต้อง setupLineFront/Back + calibrate ก่อน · ทางโค้งลด kpYaw
// ══════════════════════════════════════════════════════════════
inline void LINE_MOVE(int direction, float targetYaw, int speedBase,
                      float duration, float kpLine, float kdLine,
                      float kpYaw, float kdYaw,
                      int rampUp_ms = 0, int rampDown_ms = 0,
                      int startSpeed = 30) {

  unsigned long startTime = millis();
  unsigned long lastPID   = millis();
  unsigned long endTime   = startTime + (unsigned long)duration;

  float prevErrLine = 0;
  float prevErrYaw  = 0;
  float dFiltYaw    = 0;
  float dFiltLine   = 0;

  int lnFrom = (direction == 0) ? _lnFrontFrom : _lnBackFrom;
  int lnTo   = (direction == 0) ? _lnFrontTo   : _lnBackTo;
  int lnType = (direction == 0) ? _lnFrontType : _lnBackType;

  while (millis() < endTime) {
    unsigned long now = millis();
    float dt = (now - lastPID) / 1000.0;
    if (dt <= 0) dt = 0.001;
    lastPID = now;

    float errLine = linePosition(lnFrom, lnTo, lnType);
    if (direction == 1 && _lnBackFlip) errLine = -errLine;
    float dLine   = errLine - prevErrLine;         // ผลต่างดิบ (สเกล kdLine เท่าเดิม)
    dFiltLine     = dFiltLine * 0.7 + dLine * 0.3; // กรอง noise กันกระตุก (เหมือนฝั่งไจโร)
    float outLine = kpLine * errLine + kdLine * dFiltLine;
    prevErrLine   = errLine;

    float errYaw = shortestAngle(getYaw(), targetYaw);
    float dYaw   = constrain((errYaw - prevErrYaw) / dt, -200.0, 200.0);
    dFiltYaw     = dFiltYaw * 0.7 + dYaw * 0.3;
    prevErrYaw   = errYaw;
    float outYaw = kpYaw * errYaw + kdYaw * dFiltYaw;

    float output  = outLine + outYaw;
    float maxTurn = speedBase;
    output = constrain(output, -maxTurn, maxTurn);

    float base = speedBase;
    unsigned long elapsed = now - startTime;
    long remain = (long)(endTime - now);
    if (rampUp_ms > 0 && elapsed < (unsigned long)rampUp_ms) {
      base = startSpeed + (speedBase - startSpeed) * ((float)elapsed / (float)rampUp_ms);
    }
    if (rampDown_ms > 0 && remain < rampDown_ms && remain > 0) {
      float r = constrain((float)remain / (float)rampDown_ms, 0.0, 1.0);
      base = 10 + (speedBase - 10) * r;
    }

    int leftSpeed  = constrain((int)(base + output), 0, 100);
    int rightSpeed = constrain((int)(base - output), 0, 100);

    if (direction == 0) { motorL(leftSpeed);   motorR(rightSpeed); }
    else                { motorL(-rightSpeed); motorR(-leftSpeed); }

    delay(4);
  }
  ao();
}
