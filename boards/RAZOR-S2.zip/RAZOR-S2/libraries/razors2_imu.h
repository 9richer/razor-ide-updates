#pragma once
// ══════════════════════════════════════════════════════════════
//  razors2_imu.h — ตัวสลับ IMU สำหรับ RAZOR-S2 (ESP32)
//
//  รองรับ 6 ชิป (เหมือน RAZOR-S3):
//    IMU_MPU6050  IMU_GY91 (MPU9250)
//    IMU_BNO055   IMU_BNO055_MAG
//    IMU_BNO085   IMU_BNO085_MAG
//    IMU_ICM20948
//
//  I2C shared กับ OLED: SDA=21  SCL=22
//  ใช้บล็อก "เลือก IMU" ใน Setup ก่อน "IMU คาริเบต"
// ══════════════════════════════════════════════════════════════

#include <Wire.h>
#include "razors2_terrain.h"
#include "imu_bno055.h"
#include "imu_bno085.h"
#include "imu_icm20948.h"

// ── ชนิด IMU (ตรงกับ RAZOR-S3) ────────────────────────────
#define IMU_BNO055      0
#define IMU_MPU6050     1
#define IMU_BNO085      2
#define IMU_BNO085_MAG  3
#define IMU_BNO055_MAG  4
#define IMU_GY91        5
#define IMU_ICM20948    6

uint8_t imuType = IMU_MPU6050;   // ← ค่าเริ่มต้น (เปลี่ยนด้วยบล็อก "เลือก IMU")

inline void setIMU(uint8_t t) { imuType = t; }

// ── ③ Motor Gating flag — set โดย ao() ──────────────────────
static bool _motor_ao_called = false;

// ao() = หยุดมอเตอร์ + trigger ZUPT เร็ว
inline void ao2() {
  motorL(0); motorR(0);
  _motor_ao_called = true;
}

// sonarRead() — wrapper ให้ razors4_imu functions ใช้ได้ตรง
inline float sonarRead(int trig, int echo) {
  pinMode(trig, OUTPUT);
  pinMode(echo, INPUT);
  digitalWrite(trig, LOW);  delayMicroseconds(2);
  digitalWrite(trig, HIGH); delayMicroseconds(10);
  digitalWrite(trig, LOW);
  long dur = pulseIn(echo, HIGH, 23200UL);  // timeout ~4m
  return dur > 0L ? (float)(dur / 58L) : -1.0f;
}


// ══════════════════════════════════════════════════════════════
//  MPU6050 Driver — ESP32 version
//  (ดัดแปลงจาก imu_mpu6050.h — ใช้ Wire แทน Wire1)
// ══════════════════════════════════════════════════════════════

#define MPU_ADDR      0x68
#define MPU_WIRE      Wire
#define MPU_SDA       21
#define MPU_SCL       22
#define MPU_YAW_SIGN  (-1.0f)   // หมุนขวา = เลขเพิ่ม

// ── ★ ปรับจูนหลัก ────────────────────────────────────────────
#define MPU_GYRO_FS      1000    // 250/500/1000/2000 °/s
#define MPU_DLPF         0x04   // 0x03≈44Hz  0x04≈21Hz
#define MPU_STILL_GYRO   1.2f
#define MPU_STILL_ACC    0.06f
#define MPU_STILL_HOLD   8
#define MPU_GATE_HOLD    3
#define MPU_STILL_SIGMA  4.0f
#define MPU_KALMAN_Q     0.0001f
#define MPU_KALMAN_R     100.0f
#define MPU_THERMAL_ENABLE  0
#define MPU_THERMAL_COEFF   0.05f

#if   MPU_GYRO_FS == 250
  #define _MPU_GYRO_REG 0x00
  static const float _MPU_LSB_DPS = 131.0f;
#elif MPU_GYRO_FS == 500
  #define _MPU_GYRO_REG 0x08
  static const float _MPU_LSB_DPS = 65.5f;
#elif MPU_GYRO_FS == 1000
  #define _MPU_GYRO_REG 0x10
  static const float _MPU_LSB_DPS = 32.8f;
#else
  #define _MPU_GYRO_REG 0x18
  static const float _MPU_LSB_DPS = 16.4f;
#endif
static const float _MPU_LSB_G = 16384.0f;

static double        _mpu_yawAccum   = 0.0;
static float         _mpu_gyroZbias  = 0.0f;
static float         _mpu_prevRate   = 0.0f;
static unsigned long _mpu_lastUs     = 0;
static int           _mpu_stillCnt   = 0;
static bool          _mpu_stationary = false;
static float         _mpu_tempC      = 0.0f;
static float         _mpu_rateFilt   = 0.0f;
static bool          _mpu_gateFlag   = false;
static float         _mpu_stillThresh = MPU_STILL_GYRO;
static float         _mpu_kalmanP    = 1.0f;
static float         _mpu_tempRef    = 25.0f;

static inline void _mpu_write(uint8_t reg, uint8_t val) {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(reg); MPU_WIRE.write(val);
  MPU_WIRE.endTransmission();
}

static inline void _mpu_readAll(float &ax, float &ay, float &az,
                                float &gx, float &gy, float &gz) {
  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(0x3B);
  MPU_WIRE.endTransmission(false);
  uint8_t got = MPU_WIRE.requestFrom((int)MPU_ADDR, 14);
  if (got < 14) {
    ax=0; ay=0; az=1.0f; gx=0; gy=0; gz=0;
    while (MPU_WIRE.available()) MPU_WIRE.read();
    return;
  }
  int16_t rax=(MPU_WIRE.read()<<8)|MPU_WIRE.read();
  int16_t ray=(MPU_WIRE.read()<<8)|MPU_WIRE.read();
  int16_t raz=(MPU_WIRE.read()<<8)|MPU_WIRE.read();
  int16_t rt =(MPU_WIRE.read()<<8)|MPU_WIRE.read();
  int16_t rgx=(MPU_WIRE.read()<<8)|MPU_WIRE.read();
  int16_t rgy=(MPU_WIRE.read()<<8)|MPU_WIRE.read();
  int16_t rgz=(MPU_WIRE.read()<<8)|MPU_WIRE.read();
  ax=rax/_MPU_LSB_G; ay=ray/_MPU_LSB_G; az=raz/_MPU_LSB_G;
  gx=rgx/_MPU_LSB_DPS; gy=rgy/_MPU_LSB_DPS; gz=(float)rgz;
  _mpu_tempC = rt/340.0f + 36.53f;
}

static inline void _mpu_calibrateBias(int samples=2000) {
  double sum=0;
  for(int i=0;i<samples;i++){
    MPU_WIRE.beginTransmission(MPU_ADDR);
    MPU_WIRE.write(0x47); MPU_WIRE.endTransmission(false);
    MPU_WIRE.requestFrom((int)MPU_ADDR,2);
    int16_t z=(MPU_WIRE.read()<<8)|MPU_WIRE.read();
    sum+=z; delay(1);
  }
  _mpu_gyroZbias=(float)(sum/samples);
  _mpu_kalmanP=1.0f;
  double sumSq=0;
  const int nN=200;
  for(int i=0;i<nN;i++){
    MPU_WIRE.beginTransmission(MPU_ADDR);
    MPU_WIRE.write(0x47); MPU_WIRE.endTransmission(false);
    MPU_WIRE.requestFrom((int)MPU_ADDR,2);
    int16_t z=(MPU_WIRE.read()<<8)|MPU_WIRE.read();
    float err=(float)z-_mpu_gyroZbias;
    sumSq+=(double)err*err; delay(1);
  }
  float stddev_lsb=sqrtf((float)(sumSq/nN));
  float stddev_dps=stddev_lsb/_MPU_LSB_DPS;
  _mpu_stillThresh=constrain(stddev_dps*MPU_STILL_SIGMA,0.8f,3.0f);
  _mpu_tempRef=_mpu_tempC;
}

static inline void _mpu_waitStable() {
  const float STILL_G=3.0f, STILL_A=0.08f;
  int stable=0;
  unsigned long t0=millis();
  while(stable<30){
    float ax,ay,az,gx,gy,gzRaw;
    _mpu_readAll(ax,ay,az,gx,gy,gzRaw);
    float gz=gzRaw/_MPU_LSB_DPS;
    float mag=sqrt(ax*ax+ay*ay+az*az);
    bool still=(fabs(gx)<STILL_G)&&(fabs(gy)<STILL_G)&&
               (fabs(gz)<STILL_G)&&(fabs(mag-1.0f)<STILL_A);
    if(still) stable++; else stable=0;
    delay(20);
    if(millis()-t0>6000) break;
  }
}

inline void mpu_notifyStop() { _mpu_gateFlag=true; }

inline void mpu_initIMU() {
  // ESP32: ใช้ Wire.begin(SDA, SCL) — Wire ถูก init โดย OLED แล้ว แต่ begin ซ้ำได้
  MPU_WIRE.begin(MPU_SDA, MPU_SCL);
  MPU_WIRE.setClock(400000);

  MPU_WIRE.beginTransmission(MPU_ADDR);
  MPU_WIRE.write(0x75); MPU_WIRE.endTransmission(false);
  MPU_WIRE.requestFrom((int)MPU_ADDR,1);
  uint8_t who=MPU_WIRE.read();
  if(who!=0x68 && who!=0x70 && who!=0x71){
    Serial.println("MPU6050 not detected (SDA=21 SCL=22)");
    pinMode(12,OUTPUT);                         // Piezo บน RAZOR-S2
    while(1){ buzzOn(); delay(100); buzzOff(); delay(100); }
  }

  _mpu_write(0x6B,0x01); delay(50);
  _mpu_write(0x1A,MPU_DLPF);
  _mpu_write(0x19,0x00);
  _mpu_write(0x1B,_MPU_GYRO_REG);
  _mpu_write(0x1C,0x00);
  delay(50);

  _mpu_waitStable();
  _mpu_calibrateBias(2000);
  _mpu_yawAccum=0.0; _mpu_prevRate=0.0;
  _mpu_stillCnt=0; _mpu_lastUs=micros();
}

inline float mpu_getYawRaw() {
  unsigned long now=micros();
  float dt=(now-_mpu_lastUs)/1000000.0f;
  _mpu_lastUs=now;
  if(dt<0) dt=0;
  if(dt>0.05f) dt=0.05f;

  if(_motor_ao_called){ _motor_ao_called=false; _mpu_gateFlag=true; }

  float ax,ay,az,gx,gy,gzRaw;
  _mpu_readAll(ax,ay,az,gx,gy,gzRaw);

  // ป้อนสภาพพื้น (gx,gy เป็น dps แล้ว, ax..az เป็น g) — ★ แกน pitch ตามการติดตั้ง
  terrainFeed(atan2f(ax, sqrtf(ay*ay+az*az))*57.2958f, sqrtf(gx*gx+gy*gy));

  float thermalOffset=0.0f;
#if MPU_THERMAL_ENABLE
  thermalOffset=(_mpu_tempC-_mpu_tempRef)*MPU_THERMAL_COEFF*_MPU_LSB_DPS;
#endif

  float errZ=gzRaw-_mpu_gyroZbias-thermalOffset;
  float rateZ=errZ/_MPU_LSB_DPS;

  _mpu_rateFilt=0.65f*_mpu_rateFilt+0.35f*rateZ;

  float accMag=sqrtf(ax*ax+ay*ay+az*az);
  bool still=(fabsf(gx)<_mpu_stillThresh)&&
             (fabsf(gy)<_mpu_stillThresh)&&
             (fabsf(_mpu_rateFilt)<_mpu_stillThresh)&&
             (fabsf(accMag-1.0f)<MPU_STILL_ACC);

  int holdNeeded=_mpu_gateFlag ? MPU_GATE_HOLD : MPU_STILL_HOLD;
  if(still){ if(_mpu_stillCnt<100000)_mpu_stillCnt++; }
  else      { _mpu_stillCnt=0; _mpu_gateFlag=false; }
  _mpu_stationary=(_mpu_stillCnt>=holdNeeded);
  if(_mpu_stationary&&_mpu_gateFlag) _mpu_gateFlag=false;

  if(_mpu_stationary){
    float K=_mpu_kalmanP/(_mpu_kalmanP+MPU_KALMAN_R);
    _mpu_gyroZbias+=K*errZ;
    _mpu_kalmanP=(1.0f-K)*_mpu_kalmanP+MPU_KALMAN_Q;
    rateZ=0.0f;
  } else {
    _mpu_kalmanP+=MPU_KALMAN_Q;
  }

  float rate=rateZ*MPU_YAW_SIGN;
  _mpu_yawAccum+=(double)(0.5f*(rate+_mpu_prevRate))*dt;
  _mpu_prevRate=rate;

  double y=fmod(_mpu_yawAccum,360.0);
  if(y<0) y+=360.0;
  return (float)y;
}

inline bool  mpu_isStationary()   { return _mpu_stationary; }
inline float mpu_getBias()        { return _mpu_gyroZbias/_MPU_LSB_DPS; }
inline float mpu_getTemp()        { return _mpu_tempC; }


// ══════════════════════════════════════════════════════════════
//  High-level IMU API (ชื่อเหมือน RAZOR-S3)
// ══════════════════════════════════════════════════════════════

float offsetYaw = 0;

inline void initIMU() {
  if      (imuType == IMU_MPU6050 || imuType == IMU_GY91) mpu_initIMU();
  else if (imuType == IMU_ICM20948)                        icm_initIMU();
  else if (imuType == IMU_BNO085)     { _bno085_useMag = false; bno085_initIMU(); }
  else if (imuType == IMU_BNO085_MAG) { _bno085_useMag = true;  bno085_initIMU(); }
  else if (imuType == IMU_BNO055_MAG) { _bno_useMag    = true;  bno_initIMU(); }
  else                                { _bno_useMag    = false; bno_initIMU(); }
}

inline float getYawRaw() {
  if      (imuType == IMU_MPU6050 || imuType == IMU_GY91) return mpu_getYawRaw();
  else if (imuType == IMU_ICM20948)                        return icm_getYawRaw();
  else if (imuType == IMU_BNO085 || imuType == IMU_BNO085_MAG) return bno085_getYawRaw();
  else                                                     return bno_getYawRaw();
}

inline float getYaw() {
  float yaw = getYawRaw() - offsetYaw;
  if(yaw < 0)    yaw += 360;
  if(yaw >= 360) yaw -= 360;
  return yaw;
}

inline void calibrateYawStart() {
  unsigned long t0=millis();
  while(millis()-t0<200){ getYawRaw(); delay(4); }
  float sum=0;
  for(int i=0;i<20;i++){ sum+=getYawRaw(); delay(2); }
  offsetYaw=sum/20.0f;
}

inline void resetYaw(int samples=10) {
  if(samples<=1){ offsetYaw=getYawRaw(); return; }
  float sum=0;
  for(int i=0;i<samples;i++){ sum+=getYawRaw(); delay(2); }
  offsetYaw=sum/(float)samples;
}


// ══════════════════════════════════════════════════════════════
//  สภาพพื้น — ใช้ได้ทุกชิป (0=ราบ 1=ทางเอียง 2=ลูกระนาด)
//  getYawRaw() ของทุกชิปป้อนค่าเข้าแกนกลางอยู่แล้ว จึงเรียกอ่านซ้ำ
//  1 ครั้งเพื่ออัปเดตค่าล่าสุด แล้วคืนผลจากแกนกลาง
//  (setTerrainRamp / setTerrainBump / setTerrainBumpCount อยู่ใน razors2_terrain.h)
// ══════════════════════════════════════════════════════════════

inline int getTerrain()   { getYawRaw(); return terrainGet(); }
inline float getTilt()    { getYawRaw(); return terrainTilt(); }      // มุมก้ม-เงย (องศา) — ไว้จูน
inline float getBump()    { getYawRaw(); return terrainBump(); }      // ค่าการสั่น (°/s) — ไว้จูน
inline int getBumpCount() { getYawRaw(); return terrainBumpCount(); } // จำนวนครั้งกระดก — ไว้จูน


// ══════════════════════════════════════════════════════════════
//  Math helpers
// ══════════════════════════════════════════════════════════════

inline float normalizeAngle(float angle) {
  while(angle>180)  angle-=360;
  while(angle<=-180) angle+=360;
  return angle;
}

inline float shortestAngle(float cur, float tgt) {
  return fmod((tgt-cur+540),360)-180;
}


// ══════════════════════════════════════════════════════════════
//  spinTo config
// ══════════════════════════════════════════════════════════════

struct SpinConfig {
  float kp_fast=6.0, kp_mid=3.5, kp_slow=1.5, kd=0.3;
} _spinCfg;

inline void setSpinConfig(float kf,float km,float ks,float kd){
  _spinCfg.kp_fast=kf; _spinCfg.kp_mid=km;
  _spinCfg.kp_slow=ks; _spinCfg.kd=kd;
}

// ── spinTo — เลี้ยวแม่นสุด (PD + Adaptive kp) ────────────────
inline void spinTo(float targetYaw, float errThr=1.5,
                   int timeout_ms=200, int spdMin=40, int spdMax=70) {
  float prevError=0, dFilt=0;
  int settleCount=0;
  unsigned long lastTime=millis(), startTime=millis();
  while(1){
    if((millis()-startTime)>(unsigned long)timeout_ms) break;
    float cur=getYaw();
    float error=normalizeAngle(targetYaw-cur);
    unsigned long now=millis();
    float dt=max((now-lastTime)/1000.0f,0.001f);
    lastTime=now;
    float deriv=(error-prevError)/dt;
    deriv=constrain(deriv,-200,200);
    dFilt=dFilt*0.7+deriv*0.3;
    prevError=error;
    float kp=(abs(error)>30)?_spinCfg.kp_fast:(abs(error)>10)?_spinCfg.kp_mid:_spinCfg.kp_slow;
    float output=kp*error+_spinCfg.kd*dFilt;
    int speed=constrain((int)abs(output),spdMin,spdMax);
    if(output>0){motorL(speed);motorR(-speed);}
    else        {motorL(-speed);motorR(speed);}
    if(abs(error)<errThr&&abs(dFilt)<3){ if(++settleCount>=5)break; }
    else settleCount=0;
    delay(4);
  }
  ao(); delay(120);
}

// ── TurnF_PID — ดิฟหน้า (pivot หน้า) ─────────────────────────
inline void TurnF_PID(float targetYaw, int spdMin, int spdMax,
                      float kp, float kd, float errThr=5.0,
                      int timeout_ms=2000) {
  float prevError=0;
  unsigned long lastTime=millis(), startTime=millis();
  while(1){
    if((millis()-startTime)>(unsigned long)timeout_ms) break;
    float cur=getYaw();
    float error=normalizeAngle(targetYaw-cur);
    unsigned long now=millis();
    float dt=max((now-lastTime)/1000.0,0.001);
    lastTime=now;
    float deriv=(error-prevError)/dt;
    float output=kp*error+kd*deriv;
    prevError=error;
    int speed=constrain(abs(output),spdMin,spdMax);
    if(output>0){motorL(speed);motorR(-10);}
    else        {motorL(-10);motorR(speed);}
    if(abs(error)<errThr) break;
  }
  ao(); delay(10);
}

// ── TurnB_PID — ดิฟหลัง (pivot หลัง) ─────────────────────────
inline void TurnB_PID(float targetYaw, int spdMin, int spdMax,
                      float kp, float kd, float errThr=5.0,
                      int timeout_ms=2000) {
  float prevError=0;
  unsigned long lastTime=millis(), startTime=millis();
  while(1){
    if((millis()-startTime)>(unsigned long)timeout_ms) break;
    float cur=getYaw();
    float error=normalizeAngle(targetYaw-cur);
    unsigned long now=millis();
    float dt=max((now-lastTime)/1000.0,0.001);
    lastTime=now;
    float deriv=(error-prevError)/dt;
    float output=kp*error+kd*deriv;
    prevError=error;
    int speed=constrain(abs(output),spdMin,spdMax);
    if(output>0){motorL(10);motorR(-speed);}
    else        {motorL(-speed);motorR(10);}
    if(abs(error)<errThr) break;
  }
  ao(); delay(10);
}

// ── spinTo_F / spinTo_B — หมุนในที่ ไม่มี PID ────────────────
inline void spinTo_F(float targetYaw, int maxSpd, int minSpd,
                     float thr=3.0, int timeout_ms=2000) {
  float startErr=abs(normalizeAngle(targetYaw-getYaw()));
  if(startErr<thr) return;
  unsigned long startTime=millis();
  while(1){
    if((millis()-startTime)>(unsigned long)timeout_ms) break;
    float error=normalizeAngle(targetYaw-getYaw());
    float rem=abs(error);
    if(rem<thr) break;
    float ratio=min(rem/max(startErr,1.0f),1.0f);
    int speed=constrain((int)(minSpd+(maxSpd-minSpd)*ratio),minSpd,maxSpd);
    if(error>0){motorL(speed);motorR(-speed);}
    else       {motorL(-speed);motorR(speed);}
  }
  ao();delay(100);
}

inline void spinTo_B(float targetYaw, int maxSpd, int minSpd,
                     float thr=3.0, int timeout_ms=2000) {
  spinTo_F(targetYaw,maxSpd,minSpd,thr,timeout_ms);
}

// ── TurnF_S — ดิฟหน้า ไม่มี PID ─────────────────────────────
inline void TurnF_S(float targetYaw, int maxSpd, int minSpd,
                    float thr=3.0, int timeout_ms=2000) {
  float startErr=abs(normalizeAngle(targetYaw-getYaw()));
  if(startErr<thr) return;
  unsigned long startTime=millis();
  while(1){
    if((millis()-startTime)>(unsigned long)timeout_ms) break;
    float error=normalizeAngle(targetYaw-getYaw());
    float rem=abs(error);
    if(rem<thr) break;
    float ratio=min(rem/max(startErr,1.0f),1.0f);
    int speed=constrain((int)(minSpd+(maxSpd-minSpd)*ratio),minSpd,maxSpd);
    if(error>0){motorL(speed);motorR(-10);}
    else       {motorL(-10);motorR(speed);}
  }
  ao();delay(20);
}

// ── TurnB_S — ดิฟหลัง ไม่มี PID ─────────────────────────────
inline void TurnB_S(float targetYaw, int maxSpd, int minSpd,
                    float thr=3.0, int timeout_ms=2000) {
  float startErr=abs(normalizeAngle(targetYaw-getYaw()));
  if(startErr<thr) return;
  unsigned long startTime=millis();
  while(1){
    if((millis()-startTime)>(unsigned long)timeout_ms) break;
    float error=normalizeAngle(targetYaw-getYaw());
    float rem=abs(error);
    if(rem<thr) break;
    float ratio=min(rem/max(startErr,1.0f),1.0f);
    int speed=constrain((int)(minSpd+(maxSpd-minSpd)*ratio),minSpd,maxSpd);
    if(error>0){motorL(10);motorR(-speed);}
    else       {motorL(-speed);  motorR(10);}
  }
  ao();delay(20);
}


// ══════════════════════════════════════════════════════════════
//  MOVE — เดินหน้า/ถอยหลัง PID + ramp
// ══════════════════════════════════════════════════════════════

inline void MOVE(int direction, float targetYaw, int speedBase,
                 float duration, float kp, float ki, float kd,
                 int rampUp_ms=0, int rampDown_ms=0, int startSpeed=30) {
  unsigned long startTime=millis(), lastPID=millis();
  unsigned long endTime=startTime+(unsigned long)duration;
  float integral=0, prevError=0, dFilt=0;

  while(millis()<endTime){
    float cur=getYaw();
    float error=shortestAngle(cur,targetYaw);
    unsigned long now=millis();
    float dt=(now-lastPID)/1000.0;
    if(dt<=0) dt=0.001;
    lastPID=now;

    integral+=error*dt;
    integral=constrain(integral,-40,40);
    if(abs(error)<0.5) integral=0;

    float deriv=(error-prevError)/dt;
    deriv=constrain(deriv,-200,200);
    dFilt=dFilt*0.7+deriv*0.3;
    prevError=error;

    float output=kp*error+ki*integral+kd*dFilt;
    float maxTurn=speedBase*0.7;
    output=constrain(output,-maxTurn,maxTurn);

    float base=speedBase;
    unsigned long elapsed=now-startTime;
    long remain=endTime-now;

    if(rampUp_ms>0&&elapsed<(unsigned long)rampUp_ms){
      float ramp=(float)elapsed/(float)rampUp_ms;
      base=startSpeed+(speedBase-startSpeed)*ramp;
    }
    if(rampDown_ms>0&&remain<rampDown_ms&&remain>0){
      float rd=constrain((float)remain/(float)rampDown_ms,0.0,1.0);
      base=10+(speedBase-10)*rd;
    }

    int R=constrain((int)(base-output),0,100);
    int L=constrain((int)(base+output),0,100);
    if(direction==0){motorL(L);motorR(R);}
    else            {motorL(-R);motorR(-L);}
    delay(4);
  }
  ao(); delay(20);
}


// ══════════════════════════════════════════════════════════════
//  MOVE_WALL — IMU + Sonar Wall Tracking
// ══════════════════════════════════════════════════════════════

inline void MOVE_WALL(int direction, float targetYaw, int speedBase,
                      float duration, float kp_yaw, float kp_wall,
                      float targetDist, int trigPin, int echoPin,
                      int rampUp_ms=0, int rampDown_ms=0, int startSpeed=30) {
  unsigned long startTime=millis(), lastPID=millis();
  unsigned long endTime=startTime+(unsigned long)duration;
  float integral=0, prevError=0, dFilt=0;

  while(millis()<endTime){
    unsigned long now=millis();
    float dt=(now-lastPID)/1000.0f;
    if(dt<=0) dt=0.001f;
    lastPID=now;

    float cur=getYaw();
    float error_yaw=shortestAngle(cur,targetYaw);

    integral+=error_yaw*dt;
    integral=constrain(integral,-40,40);
    if(abs(error_yaw)<0.5) integral=0;

    float deriv=(error_yaw-prevError)/dt;
    deriv=constrain(deriv,-200,200);
    dFilt=dFilt*0.7f+deriv*0.3f;
    prevError=error_yaw;

    float output=kp_yaw*error_yaw+0.05f*integral+0.1f*dFilt;

    float dist=sonarRead(trigPin,echoPin);
    if(dist>0) output+=kp_wall*(dist-targetDist);

    float maxTurn=speedBase*0.7f;
    output=constrain(output,-maxTurn,maxTurn);

    float base=speedBase;
    unsigned long elapsed=now-startTime;
    long remain=endTime-now;

    if(rampUp_ms>0&&elapsed<(unsigned long)rampUp_ms){
      float ramp=(float)elapsed/(float)rampUp_ms;
      base=startSpeed+(speedBase-startSpeed)*ramp;
    }
    if(rampDown_ms>0&&remain<rampDown_ms&&remain>0){
      float rd=constrain((float)remain/(float)rampDown_ms,0.0f,1.0f);
      base=10+(speedBase-10)*rd;
    }

    int R=constrain((int)(base-output),0,100);
    int L=constrain((int)(base+output),0,100);
    if(direction==0){motorL(L);motorR(R);}
    else            {motorL(-R);motorR(-L);}
    delay(4);
  }
  ao();
}


// ══════════════════════════════════════════════════════════════
//  MOVE_LOOP / MOVE_WALL_LOOP — เดินตลอด ไม่มี duration
// ══════════════════════════════════════════════════════════════

static unsigned long _tick_lastPID   = 0;
static unsigned long _tick_startTime = 0;
static float _tick_integral  = 0;
static float _tick_prevError = 0;
static float _tick_dFilt     = 0;

inline void MOVE_LOOP_RESET() {
  _tick_startTime=millis(); _tick_lastPID=millis();
  _tick_integral=0; _tick_prevError=0; _tick_dFilt=0;
}

inline float _move_loop_pid(float targetYaw, int speedBase, float kp, float kd) {
  unsigned long now=millis();
  float dt=(now-_tick_lastPID)/1000.0f;
  if(dt<=0) dt=0.001f;
  _tick_lastPID=now;
  float error_yaw=shortestAngle(getYaw(),targetYaw);
  _tick_integral+=error_yaw*dt;
  _tick_integral=constrain(_tick_integral,-40,40);
  if(abs(error_yaw)<0.5f) _tick_integral=0;
  float deriv=constrain((error_yaw-_tick_prevError)/dt,-200,200);
  _tick_dFilt=_tick_dFilt*0.7f+deriv*0.3f;
  _tick_prevError=error_yaw;
  float output=kp*error_yaw+0.05f*_tick_integral+kd*_tick_dFilt;
  return constrain(output,-(speedBase*0.7f),(speedBase*0.7f));
}

inline float _move_loop_base(int speedBase, int startSpeed) {
  unsigned long elapsed=millis()-_tick_startTime;
  return(elapsed<150)
    ? startSpeed+(speedBase-startSpeed)*((float)elapsed/150.0f)
    : (float)speedBase;
}

inline void MOVE_LOOP(int direction, float targetYaw, int speedBase,
                      float kp_yaw, float kd_yaw=0, int startSpeed=10) {
  float output=_move_loop_pid(targetYaw,speedBase,kp_yaw,kd_yaw);
  output=constrain(output,-(speedBase*0.7f),(speedBase*0.7f));
  float base=_move_loop_base(speedBase,startSpeed);
  int R=constrain((int)(base-output),0,100);
  int L=constrain((int)(base+output),0,100);
  if(direction==0){motorL(L);motorR(R);}
  else            {motorL(-R);motorR(-L);}
  delay(1);
}

inline void MOVE_WALL_LOOP(int direction, float targetYaw, int speedBase,
                           float kp_yaw, float kp_wall, float targetDist,
                           int trigPin, int echoPin, int startSpeed=30) {
  float output=_move_loop_pid(targetYaw,speedBase,kp_yaw,0);
  float dist=sonarRead(trigPin,echoPin);
  if(dist>0) output+=kp_wall*(dist-targetDist);
  output=constrain(output,-(speedBase*0.7f),(speedBase*0.7f));
  float base=_move_loop_base(speedBase,startSpeed);
  int R=constrain((int)(base-output),0,100);
  int L=constrain((int)(base+output),0,100);
  if(direction==0){motorL(L);motorR(R);}
  else            {motorL(-R);motorR(-L);}
  delay(4);
}
