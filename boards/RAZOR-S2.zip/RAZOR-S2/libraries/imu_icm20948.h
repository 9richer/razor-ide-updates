#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_icm20948.h — ICM-20948 สำหรับ RAZOR-S2 (ESP32)
//  ดัดแปลงจาก RAZOR-S3 → ใช้ Wire แทน Wire1
//
//  I2C addr 0x69 (AD0=1) หรือ 0x68 (AD0=0) | Wire (SDA=21, SCL=22)
//  ★ gyro ดิบ + ZUPT (ไม่ใช้ DMP)
// ══════════════════════════════════════════════════════════════

#include "ICM_20948.h"

#define ICM_YAW_SIGN   (-1.0f)   // หมุนขวา = เลขเพิ่ม (ตรงกับ MPU/BNO + S3) · เลี้ยวกลับด้าน → +1.0f
#define ICM_STILL_G    1.2f
#define ICM_STILL_A    0.06f
#define ICM_STILL_HOLD 25
#define ICM_BIAS_GAIN  0.02f

ICM_20948_I2C _icmDev;

static double        _icm_yawAccum  = 0.0;
static float         _icm_bias      = 0.0f;
static float         _icm_prevRate  = 0.0f;
static unsigned long _icm_lastUs    = 0;
static int           _icm_stillCnt  = 0;
static bool          _icm_stationary = false;
static bool          _icm_firstRead  = true;

static inline bool _icm_read(float &ax, float &ay, float &az,
                             float &gx, float &gy, float &gz) {
  if (!_icmDev.dataReady()) return false;
  _icmDev.getAGMT();
  ax = _icmDev.accX() / 1000.0f;
  ay = _icmDev.accY() / 1000.0f;
  az = _icmDev.accZ() / 1000.0f;
  gx = _icmDev.gyrX();
  gy = _icmDev.gyrY();
  gz = _icmDev.gyrZ();
  return true;
}

static inline void _icm_calibrateBias(int samples=1000) {
  double sum=0; int got=0;
  unsigned long t0=millis();
  while(got<samples && millis()-t0<4000){
    float ax,ay,az,gx,gy,gz;
    if(_icm_read(ax,ay,az,gx,gy,gz)){ sum+=gz; got++; }
  }
  if(got>0) _icm_bias=(float)(sum/got);
}

static inline void _icm_waitStable() {
  int stable=0;
  unsigned long t0=millis();
  while(stable<30){
    float ax,ay,az,gx,gy,gz;
    if(_icm_read(ax,ay,az,gx,gy,gz)){
      float mag=sqrt(ax*ax+ay*ay+az*az);
      bool still=(fabs(gx)<ICM_STILL_G)&&(fabs(gy)<ICM_STILL_G)&&
                 (fabs(gz)<ICM_STILL_G)&&(fabs(mag-1.0f)<ICM_STILL_A);
      if(still) stable++; else stable=0;
    }
    delay(10);
    if(millis()-t0>6000) break;
  }
}

inline void icm_initIMU() {
  bool ok=false;
  for(int i=0;i<5&&!ok;i++){
    if(_icmDev.begin(Wire, 1)==ICM_20948_Stat_Ok) ok=true;    // Wire ไม่ใช่ Wire1
    else if(_icmDev.begin(Wire, 0)==ICM_20948_Stat_Ok) ok=true;
    else delay(50);
  }
  if(!ok){
    Serial.println("ICM-20948 not detected (SDA=21 SCL=22)");
    pinMode(12,OUTPUT);
    while(1){ buzzOn(); delay(100); buzzOff(); delay(100); }
  }
  _icmDev.swReset(); delay(250);
  _icmDev.sleep(false);
  _icmDev.lowPower(false);
  ICM_20948_fss_t fss;
  fss.a=gpm2; fss.g=dps1000;
  _icmDev.setFullScale((ICM_20948_Internal_Acc|ICM_20948_Internal_Gyr),fss);
  _icmDev.setSampleMode((ICM_20948_Internal_Acc|ICM_20948_Internal_Gyr),
                        ICM_20948_Sample_Mode_Continuous);
  delay(50);
  _icm_waitStable();
  _icm_calibrateBias(1000);
  _icm_yawAccum=0.0; _icm_prevRate=0.0;
  _icm_stillCnt=0; _icm_firstRead=true;
  _icm_lastUs=micros();
}

inline float icm_getYawRaw() {
  float ax,ay,az,gx,gy,gz;
  if(!_icm_read(ax,ay,az,gx,gy,gz)){
    double y0=fmod(_icm_yawAccum,360.0);
    if(y0<0) y0+=360.0;
    return (float)y0;
  }
  unsigned long now=micros();
  float dt=(now-_icm_lastUs)/1000000.0f;
  _icm_lastUs=now;
  if(dt<0) dt=0;
  if(dt>0.05f) dt=0;
  if(_icm_firstRead){ dt=0; _icm_firstRead=false; }

  float errZ=gz-_icm_bias;
  float accMag=sqrt(ax*ax+ay*ay+az*az);
  bool still=(fabs(gx)<ICM_STILL_G)&&(fabs(gy)<ICM_STILL_G)&&
             (fabs(errZ)<ICM_STILL_G)&&(fabs(accMag-1.0f)<ICM_STILL_A);

  if(still){ if(_icm_stillCnt<100000)_icm_stillCnt++; }
  else      { _icm_stillCnt=0; }
  _icm_stationary=(_icm_stillCnt>=ICM_STILL_HOLD);

  float rate=errZ;
  if(_icm_stationary){ _icm_bias+=ICM_BIAS_GAIN*errZ; rate=0; }
  rate*=ICM_YAW_SIGN;

  _icm_yawAccum+=(double)(0.5f*(rate+_icm_prevRate))*dt;
  _icm_prevRate=rate;

  double y=fmod(_icm_yawAccum,360.0);
  if(y<0) y+=360.0;
  return (float)y;
}
