#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_icm20948.h — ICM-20948 สำหรับ RAZOR-S2 (ESP32)
//  ดัดแปลงจาก RAZOR-S3 → ใช้ Wire แทน Wire1
//
//  I2C addr 0x69 (AD0=1) หรือ 0x68 (AD0=0) | Wire (SDA=21, SCL=22)
//  ★ gyro ดิบ + ZUPT (ไม่ใช้ DMP)
// ══════════════════════════════════════════════════════════════

#include "ICM_20948.h"

#define ICM_YAW_SIGN   (-1.0f)   // หมุนขวา = เลขเพิ่ม (ตรงกับ MPU/BNO + S3) · เลี้ยวกลับด้าน → +1.0f
#define ICM_STILL_G    1.2f
#define ICM_STILL_A    0.06f
#define ICM_STILL_HOLD 25
#define ICM_BIAS_GAIN  0.02f

// ── สภาพพื้น (พื้นราบ / ทางเอียง / ลูกระนาด) ──────────────────
//  ★ ค่าเริ่มต้น — ปรับตอนรันได้จากบล็อก "ตั้งไวจับทางเอียง/ลูกระนาด" ใน Setup
#define ICM_RAMP_TH      8.0f   // องศา  — |tilt| เกินนี้ = ทางเอียง (สะพาน)
#define ICM_BUMP_TH      80.0f  // °/s   — การสั่น เกินนี้ = ลูกระนาด
#define ICM_TERRAIN_HOLD 3      // อ่านซ้ำกี่ครั้งจึงเปลี่ยนสถานะ (กันค่ากระพริบ)

#define ICM_BUMP_WINDOW  1500   // ms  — ช่วงเวลานับจำนวนกระดก
#define ICM_BUMP_COUNT   3      // ครั้ง — กระดกกี่ครั้งในช่วงเวลานี้ = ลูกระนาด

static float _icm_rampTh   = ICM_RAMP_TH;    // ปรับได้ด้วย icm_setRampTh()
static float _icm_bumpTh   = ICM_BUMP_TH;    // ระดับความแรงที่นับเป็น "กระดก 1 ครั้ง"
static int   _icm_bumpMin  = ICM_BUMP_COUNT; // ต้องกระดกกี่ครั้งจึงเป็นลูกระนาด
inline void icm_setRampTh(float deg)  { _icm_rampTh  = deg; }
inline void icm_setBumpTh(float dps)  { _icm_bumpTh  = dps; }
inline void icm_setBumpMin(int n)     { _icm_bumpMin = n;   }

#define TERRAIN_FLAT 0          // พื้นราบ
#define TERRAIN_RAMP 1          // ทางเอียง (สะพาน)
#define TERRAIN_BUMP 2          // ลูกระนาด

ICM_20948_I2C _icmDev;

static double        _icm_yawAccum  = 0.0;
static float         _icm_bias      = 0.0f;
static float         _icm_prevRate  = 0.0f;
static unsigned long _icm_lastUs    = 0;
static int           _icm_stillCnt  = 0;
static bool          _icm_stationary = false;
static bool          _icm_firstRead  = true;

// ── ตัวแปรสภาพพื้น ────────────────────────────────────────────
static float _icm_tilt        = 0.0f;   // มุมก้ม-เงย กรองแล้ว (องศา)
static float _icm_bump        = 0.0f;   // ความแรงการกระดก |gyro แนวราบ| กรองแล้ว (°/s)
static int   _icm_terrain     = TERRAIN_FLAT;   // สถานะที่ยืนยันแล้ว
static int   _icm_terrainCand = TERRAIN_FLAT;   // สถานะที่กำลังลุ้น
static int   _icm_terrainCnt  = 0;

// ── ตัวนับจำนวนกระดก (แยกลูกระนาดจากรอยต่อกริด) ──────────────
static unsigned long _icm_bumpTimes[8] = {0};  // เวลาที่กระดกแต่ละครั้ง (ring)
static int  _icm_bumpHead = 0;
static bool _icm_inBump   = false;             // hysteresis: กำลังอยู่ในจังหวะกระดก
static int  _icm_bumpNow  = 0;                 // จำนวนครั้งในหน้าต่างล่าสุด (ไว้อ่านออกจอ)

// อัปเดต tilt/bump/terrain จากค่าที่อ่านมาแล้ว 1 ชุด
static inline void _icm_terrainStep(float ax, float ay, float az,
                                    float gx, float gy, float gz) {
  // มุมก้ม-เงยจากแรงโน้มถ่วง (ไม่ดริฟต์) — ★ ถ้าแกนผิดสลับ ax↔ay หรือใส่ลบ
  float pitch = atan2f(ax, sqrtf(ay*ay + az*az)) * 57.2958f;
  _icm_tilt = 0.9f * _icm_tilt + 0.1f * pitch;

  // การกระดกหน้า-หลัง — z คือแกนตั้ง (yaw) จึงใช้ gx,gy ที่เหลือ (กัน yaw รบกวน)
  float rock = sqrtf(gx*gx + gy*gy);
  _icm_bump = 0.8f * _icm_bump + 0.2f * rock;   // ค่าเฉลี่ยไว้ดูระดับ

  // ── นับ "ครั้ง" ที่กระดก ด้วย hysteresis (กันนับซ้ำจากสัญญาณสั่น) ──
  unsigned long nowMs = millis();
  if (!_icm_inBump && rock > _icm_bumpTh) {           // ขึ้นเกินระดับ = กระดก 1 ครั้ง
    _icm_inBump = true;
    _icm_bumpTimes[_icm_bumpHead] = nowMs;
    _icm_bumpHead = (_icm_bumpHead + 1) % 8;
  } else if (_icm_inBump && rock < _icm_bumpTh * 0.5f) { // ตกลงต่ำ = พร้อมนับครั้งใหม่
    _icm_inBump = false;
  }
  // นับว่ามีกี่ครั้งในหน้าต่างเวลาล่าสุด
  int bumpCnt = 0;
  for (int i = 0; i < 8; i++)
    if (_icm_bumpTimes[i] != 0 && (nowMs - _icm_bumpTimes[i]) <= ICM_BUMP_WINDOW) bumpCnt++;
  _icm_bumpNow = bumpCnt;

  int cand;
  if      (bumpCnt >= _icm_bumpMin)         cand = TERRAIN_BUMP;   // กระดกซ้ำหลายครั้ง
  else if (fabsf(_icm_tilt) > _icm_rampTh)  cand = TERRAIN_RAMP;
  else                                      cand = TERRAIN_FLAT;

  if (cand == _icm_terrainCand) { if (_icm_terrainCnt < 1000) _icm_terrainCnt++; }
  else                          { _icm_terrainCand = cand; _icm_terrainCnt = 0; }
  if (_icm_terrainCnt >= ICM_TERRAIN_HOLD) _icm_terrain = cand;
}

static inline bool _icm_read(float &ax, float &ay, float &az,
                             float &gx, float &gy, float &gz) {
  if (!_icmDev.dataReady()) return false;
  _icmDev.getAGMT();
  ax = _icmDev.accX() / 1000.0f;
  ay = _icmDev.accY() / 1000.0f;
  az = _icmDev.accZ() / 1000.0f;
  gx = _icmDev.gyrX();
  gy = _icmDev.gyrY();
  gz = _icmDev.gyrZ();
  return true;
}

static inline void _icm_calibrateBias(int samples=1000) {
  double sum=0; int got=0;
  unsigned long t0=millis();
  while(got<samples && millis()-t0<4000){
    float ax,ay,az,gx,gy,gz;
    if(_icm_read(ax,ay,az,gx,gy,gz)){ sum+=gz; got++; }
  }
  if(got>0) _icm_bias=(float)(sum/got);
}

static inline void _icm_waitStable() {
  int stable=0;
  unsigned long t0=millis();
  while(stable<30){
    float ax,ay,az,gx,gy,gz;
    if(_icm_read(ax,ay,az,gx,gy,gz)){
      float mag=sqrt(ax*ax+ay*ay+az*az);
      bool still=(fabs(gx)<ICM_STILL_G)&&(fabs(gy)<ICM_STILL_G)&&
                 (fabs(gz)<ICM_STILL_G)&&(fabs(mag-1.0f)<ICM_STILL_A);
      if(still) stable++; else stable=0;
    }
    delay(10);
    if(millis()-t0>6000) break;
  }
}

inline void icm_initIMU() {
  bool ok=false;
  for(int i=0;i<5&&!ok;i++){
    if(_icmDev.begin(Wire, 1)==ICM_20948_Stat_Ok) ok=true;    // Wire ไม่ใช่ Wire1
    else if(_icmDev.begin(Wire, 0)==ICM_20948_Stat_Ok) ok=true;
    else delay(50);
  }
  if(!ok){
    Serial.println("ICM-20948 not detected (SDA=21 SCL=22)");
    pinMode(12,OUTPUT);
    while(1){ buzzOn(); delay(100); buzzOff(); delay(100); }
  }
  _icmDev.swReset(); delay(250);
  _icmDev.sleep(false);
  _icmDev.lowPower(false);
  ICM_20948_fss_t fss;
  fss.a=gpm2; fss.g=dps1000;
  _icmDev.setFullScale((ICM_20948_Internal_Acc|ICM_20948_Internal_Gyr),fss);
  _icmDev.setSampleMode((ICM_20948_Internal_Acc|ICM_20948_Internal_Gyr),
                        ICM_20948_Sample_Mode_Continuous);
  delay(50);
  _icm_waitStable();
  _icm_calibrateBias(1000);
  _icm_yawAccum=0.0; _icm_prevRate=0.0;
  _icm_stillCnt=0; _icm_firstRead=true;
  _icm_lastUs=micros();
}

inline float icm_getYawRaw() {
  float ax,ay,az,gx,gy,gz;
  if(!_icm_read(ax,ay,az,gx,gy,gz)){
    double y0=fmod(_icm_yawAccum,360.0);
    if(y0<0) y0+=360.0;
    return (float)y0;
  }
  _icm_terrainStep(ax,ay,az,gx,gy,gz);   // อัปเดตสภาพพื้นระหว่างอ่านไจโร

  unsigned long now=micros();
  float dt=(now-_icm_lastUs)/1000000.0f;
  _icm_lastUs=now;
  if(dt<0) dt=0;
  if(dt>0.05f) dt=0;
  if(_icm_firstRead){ dt=0; _icm_firstRead=false; }

  float errZ=gz-_icm_bias;
  float accMag=sqrt(ax*ax+ay*ay+az*az);
  bool still=(fabs(gx)<ICM_STILL_G)&&(fabs(gy)<ICM_STILL_G)&&
             (fabs(errZ)<ICM_STILL_G)&&(fabs(accMag-1.0f)<ICM_STILL_A);

  if(still){ if(_icm_stillCnt<100000)_icm_stillCnt++; }
  else      { _icm_stillCnt=0; }
  _icm_stationary=(_icm_stillCnt>=ICM_STILL_HOLD);

  float rate=errZ;
  if(_icm_stationary){ _icm_bias+=ICM_BIAS_GAIN*errZ; rate=0; }
  rate*=ICM_YAW_SIGN;

  _icm_yawAccum+=(double)(0.5f*(rate+_icm_prevRate))*dt;
  _icm_prevRate=rate;

  double y=fmod(_icm_yawAccum,360.0);
  if(y<0) y+=360.0;
  return (float)y;
}

// ── อ่านสภาพพื้นแบบเดี่ยว (เรียกใน loop ตอนไม่ได้ MOVE) ────────
//  ถ้ามีข้อมูลใหม่ก็อัปเดตก่อน แล้วคืนค่าล่าสุด
inline int icm_readTerrain() {
  float ax,ay,az,gx,gy,gz;
  if(_icm_read(ax,ay,az,gx,gy,gz)) _icm_terrainStep(ax,ay,az,gx,gy,gz);
  return _icm_terrain;
}
inline float icm_getTilt() {
  float ax,ay,az,gx,gy,gz;
  if(_icm_read(ax,ay,az,gx,gy,gz)) _icm_terrainStep(ax,ay,az,gx,gy,gz);
  return _icm_tilt;
}
inline float icm_getBump() {
  float ax,ay,az,gx,gy,gz;
  if(_icm_read(ax,ay,az,gx,gy,gz)) _icm_terrainStep(ax,ay,az,gx,gy,gz);
  return _icm_bump;
}
inline int icm_getBumpCount() {
  float ax,ay,az,gx,gy,gz;
  if(_icm_read(ax,ay,az,gx,gy,gz)) _icm_terrainStep(ax,ay,az,gx,gy,gz);
  return _icm_bumpNow;
}
