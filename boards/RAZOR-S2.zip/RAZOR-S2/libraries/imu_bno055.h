#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_bno055.h — BNO055 สำหรับ RAZOR-S2 (ESP32)
//  ดัดแปลงจาก RAZOR-S3 → ใช้ Wire แทน Wire1
//
//  I2C addr 0x29 | Wire (SDA=21, SCL=23)
//  ★ 2 โหมด: IMUPLUS (6 แกน, ทนมอเตอร์) | NDOF (9 แกน, ทิศเหนือสัมบูรณ์)
// ══════════════════════════════════════════════════════════════

#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>
#include "razors2_terrain.h"    // ตัวจำแนกสภาพพื้น (ใช้ร่วมทุกชิป)

bool _bno_useMag = false;

inline Adafruit_BNO055& _bnoDev() {
  static Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x29, &Wire);  // Wire ไม่ใช่ Wire1
  return bno;
}

inline void bno_initIMU() {
  adafruit_bno055_opmode_t mode = _bno_useMag ? OPERATION_MODE_NDOF
                                              : OPERATION_MODE_IMUPLUS;
  if (!_bnoDev().begin(mode)) {
    Serial.println("BNO055 not detected (SDA=21 SCL=22)");
    pinMode(12, OUTPUT);
    while (1) { buzzOn(); delay(100); buzzOff(); delay(100); }
  }
  _bnoDev().setExtCrystalUse(true);
}

inline float bno_getYawRaw() {
  imu::Vector<3> euler = _bnoDev().getVector(Adafruit_BNO055::VECTOR_EULER);
  imu::Vector<3> gyro  = _bnoDev().getVector(Adafruit_BNO055::VECTOR_GYROSCOPE);  // dps
  // สภาพพื้น: pitch จาก fusion + ไจโรจริง (z=yaw จึงใช้ x,y) หน่วย °/s เท่ากับ ICM/MPU
  float rock = sqrtf((float)(gyro.x()*gyro.x() + gyro.y()*gyro.y()));
  terrainFeed((float)euler.y(), rock);
  return euler.x();  // 0–360
}

inline int bno_getMagAccuracy() {
  uint8_t sys, gyro, accel, mag;
  _bnoDev().getCalibration(&sys, &gyro, &accel, &mag);
  return mag;
}
