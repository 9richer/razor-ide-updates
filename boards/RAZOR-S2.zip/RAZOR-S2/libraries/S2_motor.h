


void motorL(int speed1)   
  {

 
       if(speed1>100)
         {
          speed1 = 100;
         }
       else if(speed1<-100)
         {
          speed1 = -100;
         }
         
      if(speed1>0)
         {
            analogWrite(4,(speed1*255)/100);
            analogWrite(2,0); //digitalWrite(16,LOW);
                  }
      else if(speed1<0)
         {
            analogWrite(2,-(speed1*255)/100);
            analogWrite(4,0);
         }
      else
         {
            analogWrite(2,255);
            analogWrite(4,255); 

            digitalWrite(2,LOW);
            digitalWrite(4,LOW); 
         }



       
    }





void motorR(int speed1)   
    {

 
       if(speed1>100)
         {
          speed1 = 100;
         }
       else if(speed1<-100)
         {
          speed1 = -100;
         }
         
      if(speed1>0)
         {
            analogWrite(17,(speed1*255)/100);
            analogWrite(16,0); //digitalWrite(16,LOW);
                  }
      else if(speed1<0)
         {
            analogWrite(16,-(speed1*255)/100);
            analogWrite(17,0);
         }
      else
         {
            analogWrite(17,255);
            analogWrite(16,255); 

            digitalWrite(17,LOW);
            digitalWrite(16,LOW); 
         }



       
    }

void ao(){
    analogWrite(17, 255);
    analogWrite(16, 255);
    analogWrite(2,255);
    analogWrite(4,255); 
    delay(10);
    analogWrite(17, 0);
    analogWrite(16, 0);
    analogWrite(2,0);
    analogWrite(4,0); 
     delay(10);

}



// ── Buzzer (active, pin 12) ──────────────────────────────────
//  เป็น active buzzer — มีออสซิลเลเตอร์ในตัว สั่งได้แค่ ON/OFF
//  (ปรับความถี่ไม่ได้ จึงใช้ digitalWrite ไม่ใช่ tone())
#define BUZZER_PIN 12
inline void buzzOn()         { digitalWrite(BUZZER_PIN, HIGH); }
inline void buzzOff()        { digitalWrite(BUZZER_PIN, LOW);  }
inline void buzzBeep(int ms) { digitalWrite(BUZZER_PIN, HIGH); delay(ms); digitalWrite(BUZZER_PIN, LOW); }


