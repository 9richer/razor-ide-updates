
// ── RAZOR-S2 Motor Driver — โหมดขับ "drive-brake" (slow decay) ────────
//  เปลี่ยนจากเดิม analogWrite (fast decay / ช่วง OFF ปล่อยไหล = coast)
//  มาเป็น LEDC แบบ drive-brake:
//    - ขา "ทาง" ที่ต้องการวิ่ง ตรึงไว้ HIGH (255)
//    - ขาตรงข้าม จ่าย PWM = 255 - |duty|
//    → ช่วง OFF มอเตอร์ถูกเบรก (short) แทนที่จะปล่อยไหล
//    → ตอบสนองรอบต่ำเป็นเชิงเส้นขึ้น แรงบิดดีขึ้น เบรกไว
//  speed = -100..100 (บวก=เดินหน้า, ลบ=ถอย, 0=เบรกอยู่กับที่)
//
//  ขา/แชนเนล LEDC (หลบ servo ที่จอง channel 0-3 บน core 2.x):
//    ซ้าย : เดินหน้า pin 4 (ch4) · ถอย pin 2  (ch5)
//    ขวา  : เดินหน้า pin17 (ch6) · ถอย pin16 (ch7)
//  รองรับทั้ง core 2.x (channel-based) และ 3.x (pin-based) เหมือน servo helper
#define _S2_MOT_FREQ  20000   // 20 kHz — เหนือย่านได้ยิน (เงียบ)
#define _S2_MOT_BITS  8       // 8-bit → duty 0..255

static inline void _s2MotAttach(int pin, int ch) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  (void)ch; ledcAttach(pin, _S2_MOT_FREQ, _S2_MOT_BITS);
#else
  ledcSetup(ch, _S2_MOT_FREQ, _S2_MOT_BITS);
  ledcAttachPin(pin, ch);
#endif
}

// core 3.x เขียนด้วย pin, core 2.x เขียนด้วย channel
static inline void _s2MotWrite(int pin, int ch, int duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  (void)ch; ledcWrite(pin, duty);
#else
  (void)pin; ledcWrite(ch, duty);
#endif
}

// lazy-init: attach ครั้งแรกที่เรียกมอเตอร์ (ไม่ต้องพึ่งลำดับใน setup)
static inline void _s2MotInit() {
  static bool done = false;
  if (done) return;
  done = true;
  _s2MotAttach(4,  4);   // L เดินหน้า
  _s2MotAttach(2,  5);   // L ถอย
  _s2MotAttach(17, 6);   // R เดินหน้า
  _s2MotAttach(16, 7);   // R ถอย
}


void motorL(int speed1)
  {
    _s2MotInit();
    if(speed1 >  100) speed1 =  100;
    else if(speed1 < -100) speed1 = -100;

    int duty = (abs(speed1) * 255) / 100;   // 0..255

    if(speed1 > 0)          // เดินหน้า: ตรึงขา fwd(4) HIGH, ขา bwd(2)=255-duty
      {
        _s2MotWrite(4, 4, 255);
        _s2MotWrite(2, 5, 255 - duty);
      }
    else if(speed1 < 0)     // ถอย: ตรึงขา bwd(2) HIGH, ขา fwd(4)=255-duty
      {
        _s2MotWrite(2, 5, 255);
        _s2MotWrite(4, 4, 255 - duty);
      }
    else                    // หยุด = เบรก (ทั้งสองขา HIGH)
      {
        _s2MotWrite(4, 4, 255);
        _s2MotWrite(2, 5, 255);
      }
  }





void motorR(int speed1)
    {
      _s2MotInit();
      if(speed1 >  100) speed1 =  100;
      else if(speed1 < -100) speed1 = -100;

      int duty = (abs(speed1) * 255) / 100;   // 0..255

      if(speed1 > 0)          // เดินหน้า: ตรึงขา fwd(17) HIGH, ขา bwd(16)=255-duty
        {
          _s2MotWrite(17, 6, 255);
          _s2MotWrite(16, 7, 255 - duty);
        }
      else if(speed1 < 0)     // ถอย: ตรึงขา bwd(16) HIGH, ขา fwd(17)=255-duty
        {
          _s2MotWrite(16, 7, 255);
          _s2MotWrite(17, 6, 255 - duty);
        }
      else                    // หยุด = เบรก (ทั้งสองขา HIGH)
        {
          _s2MotWrite(17, 6, 255);
          _s2MotWrite(16, 7, 255);
        }
    }

// ao() = หยุดสนิทแบบเบรก (speed 0 ในโหมด drive-brake = ตรึงทั้งสองขา HIGH)
void ao(){
    motorL(0);
    motorR(0);
    delay(1);
}



// ── Buzzer (active, pin 12) ──────────────────────────────────
//  เป็น active buzzer — มีออสซิลเลเตอร์ในตัว สั่งได้แค่ ON/OFF
//  (ปรับความถี่ไม่ได้ จึงใช้ digitalWrite ไม่ใช่ tone())
#define BUZZER_PIN 12
inline void buzzOn()         { digitalWrite(BUZZER_PIN, HIGH); }
inline void buzzOff()        { digitalWrite(BUZZER_PIN, LOW);  }
inline void buzzBeep(int ms) { digitalWrite(BUZZER_PIN, HIGH); delay(ms); digitalWrite(BUZZER_PIN, LOW); }


