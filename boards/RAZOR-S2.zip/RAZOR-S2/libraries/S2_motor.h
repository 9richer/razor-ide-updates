


void motorL(int speed1)   
  {

 
       if(speed1>100)
         {
          speed1 = 100;
         }
       else if(speed1<-100)
         {
          speed1 = -100;
         }
         
      if(speed1>0)
         {
            analogWrite(4,(speed1*255)/100);
            analogWrite(2,0); //digitalWrite(16,LOW);
                  }
      else if(speed1<0)
         {
            analogWrite(2,-(speed1*255)/100);
            analogWrite(4,0);
         }
      else
         {
            analogWrite(2,255);
            analogWrite(4,255); 

            digitalWrite(2,LOW);
            digitalWrite(4,LOW); 
         }



       
    }





void motorR(int speed1)   
    {

 
       if(speed1>100)
         {
          speed1 = 100;
         }
       else if(speed1<-100)
         {
          speed1 = -100;
         }
         
      if(speed1>0)
         {
            analogWrite(17,(speed1*255)/100);
            analogWrite(16,0); //digitalWrite(16,LOW);
                  }
      else if(speed1<0)
         {
            analogWrite(16,-(speed1*255)/100);
            analogWrite(17,0);
         }
      else
         {
            analogWrite(17,255);
            analogWrite(16,255); 

            digitalWrite(17,LOW);
            digitalWrite(16,LOW); 
         }



       
    }

void ao(){
    analogWrite(17, 255);
    analogWrite(16, 255);
    //digitalWrite(17,HIGH);
   // digitalWrite(16,HIGH); 
    //delay(10);
}