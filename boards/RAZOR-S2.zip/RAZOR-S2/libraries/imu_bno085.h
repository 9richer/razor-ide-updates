#pragma once
// ══════════════════════════════════════════════════════════════
//  imu_bno085.h — BNO085 สำหรับ RAZOR-S2 (ESP32)
//  ดัดแปลงจาก RAZOR-S3 → ใช้ Wire แทน Wire1
//
//  I2C addr 0x4B | Wire (SDA=21, SCL=22)
//  ★ 2 โหมด: GIRV (latency ต่ำ) | RotationVector (9 แกน, ทิศเหนือ)
// ══════════════════════════════════════════════════════════════

#include "SparkFun_BNO08x_Arduino_Library.h"
#include "razors2_terrain.h"    // ตัวจำแนกสภาพพื้น (ใช้ร่วมทุกชิป)

#define BNO085_ADDR     0x4B      // ถ้าไม่เจอลองเปลี่ยนเป็น 0x4A
#define BNO085_YAW_SIGN (-1.0f)
#define BNO085_RATE_MS  10        // 10=100Hz

bool _bno085_useMag = false;

inline BNO08x& _bno085Dev() {
  static BNO08x dev;
  return dev;
}
static float _bno085_yaw = 0;

inline float bno085_getYawRaw() {
  if (_bno085Dev().getSensorEvent()) {
    float qr = _bno085Dev().getQuatReal();
    float qi = _bno085Dev().getQuatI();
    float qj = _bno085Dev().getQuatJ();
    float qk = _bno085Dev().getQuatK();
    float yaw = atan2(2.0f*(qr*qk + qi*qj),
                      1.0f - 2.0f*(qj*qj + qk*qk)) * 57.2958f;
    yaw *= BNO085_YAW_SIGN;
    if (yaw < 0)    yaw += 360;
    if (yaw >= 360) yaw -= 360;
    _bno085_yaw = yaw;

    // pitch จาก quaternion (ไว้จำแนกสภาพพื้น) — clamp กัน asin หลุดช่วง
    float sp = 2.0f*(qr*qj - qk*qi);
    if (sp >  1.0f) sp =  1.0f;
    if (sp < -1.0f) sp = -1.0f;
    float pitch = asinf(sp) * 57.2958f;
    if (_bno085_useMag) {
      // โหมด RotationVector ไม่มี angVel ในรายงาน → ใช้อัตราเปลี่ยน pitch
      terrainFeedAngle(pitch);
    } else {
      // โหมด GIRV มี angular velocity จริง (rad/s → °/s) หน่วยเดียวกับ ICM/MPU
      float wx = _bno085Dev().getGyroIntegratedRVangVelX() * 57.2958f;
      float wy = _bno085Dev().getGyroIntegratedRVangVelY() * 57.2958f;
      terrainFeed(pitch, sqrtf(wx*wx + wy*wy));
    }
  }
  return _bno085_yaw;
}

inline void _bno085_waitStable() {
  float last = bno085_getYawRaw();
  int stable = 0;
  unsigned long t0 = millis();
  while (stable < 30) {
    float now = bno085_getYawRaw();
    if (fabs(now - last) < 0.3f) stable++;
    else                          stable = 0;
    last = now;
    delay(20);
    if (millis() - t0 > 5000) break;
  }
}

inline void bno085_initIMU() {
  if (!_bno085Dev().begin(BNO085_ADDR, Wire)) {  // Wire ไม่ใช่ Wire1
    Serial.println("BNO085 not detected (ลองเปลี่ยน BNO085_ADDR เป็น 0x4A)");
    pinMode(12, OUTPUT);
    while (1) { buzzOn(); delay(100); buzzOff(); delay(100); }
  }
  if (_bno085_useMag)
    _bno085Dev().enableRotationVector(BNO085_RATE_MS);
  else
    _bno085Dev().enableGyroIntegratedRotationVector(BNO085_RATE_MS);
  delay(200);
  _bno085_waitStable();
}

inline int bno085_getMagAccuracy() { return _bno085Dev().getMagAccuracy(); }
