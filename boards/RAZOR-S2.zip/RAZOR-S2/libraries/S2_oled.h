// ============================================================
//  S2_oled.h — OLED SSD1306 สำหรับ RAZOR-S2 (ESP32)
//  ★ ใช้ไลบรารีมาตรฐาน Adafruit_SSD1306 + Adafruit_GFX
//    (พอร์ตจาก RAZOR-S3 / myoled.h — เปลี่ยน Wire1(RP2040) → Wire(ESP32))
//
//  รองรับจอ 128×32 และ 128×64 — เลือกด้วยบล็อก "OLED ขนาดจอ"
//    → oled_setSize(32|64)   ค่าเริ่มต้น = 128×32
//
//  I2C: SDA=21  SCL=23  addr=0x3C
// ============================================================
#pragma once
#include <Wire.h>
#include "Adafruit_GFX.h"
#include "Adafruit_SSD1306.h"

#define _S2O_W     128
#define _S2O_ADDR  0x3C
#define _S2O_SDA   21
#define _S2O_SCL   22

// ── ขนาดจอปัจจุบัน + ตัวจอ (สร้างใหม่ตามขนาดที่เลือก) ────────
static uint8_t           _s2oH   = 32;        // 32 หรือ 64
static Adafruit_SSD1306* _disp   = nullptr;

// ════════════════════════════════════════════════════════
//  init / เลือกขนาด
// ════════════════════════════════════════════════════════

// สร้าง object + init จอตาม _s2oH
//  ★ Wire.begin(21,22) เอง + ส่ง periphBegin=false ให้ Adafruit ไม่ init Wire ซ้ำ
//    (21/22 = พินจริงบนบอร์ด RAZOR S2 — D21=sda D22=scl ตาม schematic)
void razors2_oled() {
  Wire.begin(_S2O_SDA, _S2O_SCL);
  if (_disp) { delete _disp; _disp = nullptr; }
  _disp = new Adafruit_SSD1306(_S2O_W, _s2oH, &Wire, -1);
  _disp->begin(SSD1306_SWITCHCAPVCC, _S2O_ADDR, true, false);  // periphBegin=false
  _disp->clearDisplay();
  _disp->setTextColor(SSD1306_WHITE);
  _disp->display();
}

// เลือกขนาดจอ (32 หรือ 64) แล้ว re-init ใหม่
//  setup.txt เรียก razors2_oled() เป็น 32 ไปก่อนเสมอ —
//  ถ้าผู้ใช้วางบล็อกขนาด 64 ฟังก์ชันนี้สร้างจอใหม่ให้ถูกต้อง
void oled_setSize(int h) {
  _s2oH = (h >= 64) ? 64 : 32;
  razors2_oled();
}

// ════════════════════════════════════════════════════════
//  control
// ════════════════════════════════════════════════════════

void oled_clear()          { if (_disp) _disp->clearDisplay(); }
void oled_update()         { if (_disp) _disp->display(); }
void oled_invert(bool inv) { if (_disp) _disp->invertDisplay(inv); }
void oled_dim(bool dim)    { if (_disp) _disp->dim(dim); }

// ════════════════════════════════════════════════════════
//  text — แถว (size=1 → สูง 8px ต่อแถว)
//   oled(1, "Hello");
//   oled(2, analogRead(A0));
//   oled(3, "A0", analogRead(A0));   ← label + ค่า
// ════════════════════════════════════════════════════════

template<typename T>
void oled(int line, T value, int size = 1) {
  if (!_disp) return;
  _disp->setTextSize(size);
  _disp->setCursor(0, (line - 1) * 8 * size);
  _disp->print(value);
}

template<typename T>
void oled(int line, String label, T value, int size = 1) {
  if (!_disp) return;
  _disp->setTextSize(size);
  _disp->setCursor(0, (line - 1) * 8 * size);
  _disp->print(label);
  _disp->print(value);
}

// text — ตำแหน่ง pixel
template<typename T>
void oled_xy(int x, int y, T value, int size = 1) {
  if (!_disp) return;
  _disp->setTextSize(size);
  _disp->setCursor(x, y);
  _disp->print(value);
}

// ════════════════════════════════════════════════════════
//  drawing
// ════════════════════════════════════════════════════════

void oled_line(int x1, int y1, int x2, int y2) {
  if (_disp) _disp->drawLine(x1, y1, x2, y2, SSD1306_WHITE);
}

void oled_rect(int x, int y, int w, int h) {
  if (_disp) _disp->drawRect(x, y, w, h, SSD1306_WHITE);
}

void oled_fill_rect(int x, int y, int w, int h) {
  if (_disp) _disp->fillRect(x, y, w, h, SSD1306_WHITE);
}

void oled_circle(int x, int y, int r) {
  if (_disp) _disp->drawCircle(x, y, r, SSD1306_WHITE);
}

void oled_fill_circle(int x, int y, int r) {
  if (_disp) _disp->fillCircle(x, y, r, SSD1306_WHITE);
}

// progress bar (value 0–100)
void oled_progress(int x, int y, int w, int h, int value) {
  if (!_disp) return;
  if (value < 0)   value = 0;
  if (value > 100) value = 100;
  _disp->drawRect(x, y, w, h, SSD1306_WHITE);
  int fillW = (int)((w - 2) * value / 100.0);
  if (fillW > 0) _disp->fillRect(x + 1, y + 1, fillW, h - 2, SSD1306_WHITE);
}
