#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <EEPROM.h>

// ══════════════════════════════════════════════════════════════
//  RazorS2 (ESP32) — TCS34725 Color Sensor (อ่านสีพื้น)
//  พอร์ตจาก RAZOR-S3 (RP2040) → ใช้ Wire (ไม่ใช่ Wire1) + EEPROM ESP32
//
//  ต่อสาย (ใช้บัส I2C เดียวกับ OLED/IMU = Wire):
//    SDA → GP21   SCL → GP22
//    VIN → 5V (ให้ไฟ LED นิ่ง)   GND → GND
//    LED → ปล่อยลอย = ไฟขาวติดตลอด
//
//  I2C address 0x29  (ไม่ชน OLED 0x3C / MPU6050 0x68)
//  ⚠ ถ้าใช้ IMU BNO055 (0x29) จะชน TCS — เลือก IMU อื่นหรือถอด BNO055
//
//  จัดการแสง: ถ้า R/G/B (0-255) อ่านได้น้อย เพิ่ม gain + จ่อใกล้พื้น
// ══════════════════════════════════════════════════════════════

#define TCS_WIRE      Wire
#define TCS_SDA       21
#define TCS_SCL       22
#define TCS_ADDR      0x29
#define TCS_BTN       15        // ปุ่ม SW (กด = LOW)
#define TCS_BUZ       12        // buzzer

// ── register ───────────────────────────────────────────────
#define TCS_CMD       0x80
#define TCS_AUTOINC   0x20
#define TCS_ENABLE    0x00
#define   TCS_PON     0x01
#define   TCS_AEN     0x02
#define TCS_ATIME     0x01
#define TCS_CONTROL   0x0F
#define TCS_ID        0x12
#define TCS_CDATAL    0x14

// ── reject distance (space 4 มิติ chroma+L) · ปรับบนหุ่นจริง ──
static float _tcsRejectDist = 0.35f;
#define TCS_LUM_WEIGHT  1.0f

// ── ตารางสีที่สอนไว้ ───────────────────────────────────────
//   r,g,b : chromaticity = ช่อง/(R+G+B) (ทนแสง) · L : Clear/Clear-ของขาว
struct TcsColor {
  bool   used;
  float  r, g, b;
  float  L;
  char   name[10];
};
static TcsColor _tcsTable[8];

// ── white reference (ค่าของพื้นขาว) ─────────────────────────
static uint16_t _tcsWhiteC   = 21504;
static uint16_t _tcsWhiteR   = 21504;
static uint16_t _tcsWhiteG   = 21504;
static uint16_t _tcsWhiteB   = 21504;
static uint16_t _tcsFullScale = 21504;

static inline float _tcsLum(uint16_t c) {
  uint16_t ref = (_tcsWhiteC < 1) ? 1 : _tcsWhiteC;
  float x = (float)c / (float)ref;
  return (x > 1.27f) ? 1.27f : x;
}

// ── เขียน/อ่าน register ─────────────────────────────────────
inline void _tcsWrite(uint8_t reg, uint8_t val) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | reg);
  TCS_WIRE.write(val);
  TCS_WIRE.endTransmission();
}

inline uint8_t _tcsRead8(uint8_t reg) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | reg);
  TCS_WIRE.endTransmission();
  TCS_WIRE.requestFrom(TCS_ADDR, 1);
  return TCS_WIRE.read();
}

// ══════════════════════════════════════════════════════════════
//  เริ่มต้นเซนเซอร์ — เรียกใน setup() หลัง razors2_oled()
//  integ : 0xEB = 50ms (แนะนำ) · gain : 0=1x 1=4x 2=16x 3=60x
// ══════════════════════════════════════════════════════════════
inline bool tcs_begin(uint8_t integ = 0xEB, uint8_t gain = 0x01) {
  TCS_WIRE.begin(TCS_SDA, TCS_SCL);     // ESP32: Wire.begin(sda, scl)

  uint8_t id = _tcsRead8(TCS_ID);
  if (id != 0x44 && id != 0x4D && id != 0x10) return false;

  _tcsWrite(TCS_ATIME, integ);
  _tcsWrite(TCS_CONTROL, gain);
  _tcsWrite(TCS_ENABLE, TCS_PON);
  delay(3);
  _tcsWrite(TCS_ENABLE, TCS_PON | TCS_AEN);
  delay(50);

  uint32_t fs = (uint32_t)(256 - integ) * 1024UL;
  if (fs > 65535UL) fs = 65535UL;
  if (fs < 1UL)     fs = 1UL;
  _tcsFullScale = (uint16_t)fs;
  _tcsWhiteC = _tcsWhiteR = _tcsWhiteG = _tcsWhiteB = (uint16_t)fs;

  for (int i = 0; i < 8; i++) _tcsTable[i].used = false;
  return true;
}

// ── อ่านค่าดิบ 16-bit (r,g,b,c) ─────────────────────────────
inline void tcs_readRaw(uint16_t &r, uint16_t &g, uint16_t &b, uint16_t &c) {
  TCS_WIRE.beginTransmission(TCS_ADDR);
  TCS_WIRE.write(TCS_CMD | TCS_AUTOINC | TCS_CDATAL);
  TCS_WIRE.endTransmission();
  TCS_WIRE.requestFrom(TCS_ADDR, 8);

  // อ่านลงตัวแปรชั่วคราว — ห้าม read()|(read()<<8) บรรทัดเดียว (ลำดับ eval ไม่แน่นอน)
  uint8_t cl = TCS_WIRE.read(), ch = TCS_WIRE.read();
  uint8_t rl = TCS_WIRE.read(), rh = TCS_WIRE.read();
  uint8_t gl = TCS_WIRE.read(), gh = TCS_WIRE.read();
  uint8_t bl = TCS_WIRE.read(), bh = TCS_WIRE.read();
  c = (uint16_t)cl | ((uint16_t)ch << 8);
  r = (uint16_t)rl | ((uint16_t)rh << 8);
  g = (uint16_t)gl | ((uint16_t)gh << 8);
  b = (uint16_t)bl | ((uint16_t)bh << 8);
}

inline void tcs_readAvg(uint16_t &r, uint16_t &g, uint16_t &b, uint16_t &c, int n = 5) {
  uint32_t sr = 0, sg = 0, sb = 0, sc = 0;
  uint16_t tr, tg, tb, tc;
  for (int i = 0; i < n; i++) {
    tcs_readRaw(tr, tg, tb, tc);
    sr += tr; sg += tg; sb += tb; sc += tc;
    delay(2);
  }
  r = sr / n; g = sg / n; b = sb / n; c = sc / n;
}

// ── HSV (h:0-360 s:0-100 v:0-100) ───────────────────────────
inline void tcs_readHSV(float &h, float &s, float &v, int n = 5) {
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, n);
  float rf = (c > 0) ? (float)r / c : 0;
  float gf = (c > 0) ? (float)g / c : 0;
  float bf = (c > 0) ? (float)b / c : 0;
  float mx = max(rf, max(gf, bf));
  float mn = min(rf, min(gf, bf));
  float d  = mx - mn;
  if (d < 1e-6f)        h = 0;
  else if (mx == rf)    h = 60.0f * fmodf((gf - bf) / d, 6.0f);
  else if (mx == gf)    h = 60.0f * (((bf - rf) / d) + 2.0f);
  else                  h = 60.0f * (((rf - gf) / d) + 4.0f);
  if (h < 0) h += 360.0f;
  s = (mx <= 0) ? 0 : (d / mx) * 100.0f;
  v = constrain((float)c / (float)((_tcsWhiteC < 1) ? 1 : _tcsWhiteC) * 100.0f, 0.0f, 100.0f);
}

// ══════════════════════════════════════════════════════════════
//  TEACH — สอนสี (⚠ สอน slot 0 = WHITE ก่อนเสมอ = ค่าอ้างอิงแสง)
// ══════════════════════════════════════════════════════════════
inline void tcs_teach(int slot, const char *name) {
  if (slot < 0 || slot > 7) return;
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, 10);

  if (slot == 0) {
    uint16_t oldRef = (_tcsWhiteC < 1) ? 1 : _tcsWhiteC;
    _tcsWhiteC = (c < 1) ? 1 : c;
    _tcsWhiteR = (r < 1) ? 1 : r;
    _tcsWhiteG = (g < 1) ? 1 : g;
    _tcsWhiteB = (b < 1) ? 1 : b;
    for (int k = 1; k < 8; k++) {     // rescale L ของสีที่สอนไว้ก่อน
      if (!_tcsTable[k].used) continue;
      float Lr = _tcsTable[k].L * ((float)oldRef / (float)_tcsWhiteC);
      _tcsTable[k].L = (Lr > 1.27f) ? 1.27f : Lr;
    }
  }

  float sum = r + g + b;
  if (sum < 1) sum = 1;
  _tcsTable[slot].used = true;
  _tcsTable[slot].r = r / sum;
  _tcsTable[slot].g = g / sum;
  _tcsTable[slot].b = b / sum;
  _tcsTable[slot].L = _tcsLum(c);
  strncpy(_tcsTable[slot].name, name, 9);
  _tcsTable[slot].name[9] = '\0';
}

// ── อ่านสี → slot ใกล้สุด (-1 = ไม่รู้จัก) ───────────────────
inline int tcs_readColor() {
  uint16_t r, g, b, c;
  tcs_readAvg(r, g, b, c, 5);
  float sum = r + g + b;
  if (sum < 1) sum = 1;
  float rf = r / sum, gf = g / sum, bf = b / sum;
  float L  = _tcsLum(c);

  int   best = -1;
  float bestD = 1e9;
  for (int i = 0; i < 8; i++) {
    if (!_tcsTable[i].used) continue;
    float dr = rf - _tcsTable[i].r;
    float dg = gf - _tcsTable[i].g;
    float db = bf - _tcsTable[i].b;
    float dl = L  - _tcsTable[i].L;
    float dist = sqrtf(dr * dr + dg * dg + db * db + TCS_LUM_WEIGHT * dl * dl);
    if (dist < bestD) { bestD = dist; best = i; }
  }
  if (bestD > _tcsRejectDist) return -1;
  return best;
}

inline const char* tcs_colorName(int slot) {
  if (slot < 0 || slot > 7 || !_tcsTable[slot].used) return "?";
  return _tcsTable[slot].name;
}

inline void tcs_setReject(float d) { _tcsRejectDist = d; }

// ── ค่าเดี่ยว (debug / ทำเงื่อนไขเอง) ────────────────────────
inline int tcs_hue() { float h, s, v; tcs_readHSV(h, s, v, 3); return (int)h; }
inline int tcs_sat() { float h, s, v; tcs_readHSV(h, s, v, 3); return (int)s; }
inline int tcs_clear() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return c; }

// ── R/G/B สเกล 0-255 (เทียบพื้นขาว: ขาว≈255 ดำ≈0) ──────────
static inline int _tcsScale255(uint16_t v, uint16_t wref) {
  if (wref < 1) wref = 1;
  long s = (long)v * 255L / (long)wref;
  if (s < 0)   s = 0;
  if (s > 255) s = 255;
  return (int)s;
}
inline int tcs_r() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return _tcsScale255(r, _tcsWhiteR); }
inline int tcs_g() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return _tcsScale255(g, _tcsWhiteG); }
inline int tcs_b() { uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3); return _tcsScale255(b, _tcsWhiteB); }

// ── Lux (ประมาณ, สูตร Adafruit จากค่าดิบ) ────────────────────
inline int tcs_lux() {
  uint16_t r, g, b, c; tcs_readAvg(r, g, b, c, 3);
  float lux = (-0.32466f * r) + (1.57837f * g) + (-0.73191f * b);
  return (lux < 0) ? 0 : (int)lux;
}

// ══════════════════════════════════════════════════════════════
//  EEPROM (ESP32) — บันทึก/โหลดค่าสี
//  แผนผัง (size 256 ใช้ร่วมกับ line sensor — ต้องเท่ากันกัน commit ลบกัน):
//    0 – 31  : Line sensor (LineCalEE)
//    64 –    : Color sensor (TcsCalEE)  ← ของเรา
// ══════════════════════════════════════════════════════════════
#define TCS_EE_SIZE   256         // ⚠ ต้องเท่ากับ LINE_EE_SIZE
#define TCS_EE_ADDR   64          // ไม่ชน line (0-31)
#define TCS_EE_MAGIC  0xC01C      // รูปแบบ v3 (ตรงกับ RAZOR-S3)

struct TcsCalEE {
  uint16_t magic;
  uint16_t cwhite;
  uint16_t wr, wg, wb;
  uint8_t  used[8];
  uint8_t  r[8], g[8], b[8];
  uint8_t  L[8];
};

static const char* _TCS_STD_NAME[8] =
  { "WHITE","RED","GREEN","BLUE","YELLOW","BLACK","C6","C7" };

inline void tcs_saveCal() {
  TcsCalEE ee;
  ee.magic  = TCS_EE_MAGIC;
  ee.cwhite = _tcsWhiteC;
  ee.wr = _tcsWhiteR; ee.wg = _tcsWhiteG; ee.wb = _tcsWhiteB;
  for (int i = 0; i < 8; i++) {
    ee.used[i] = _tcsTable[i].used ? 1 : 0;
    ee.r[i] = (uint8_t)constrain(_tcsTable[i].r * 255.0f, 0, 255);
    ee.g[i] = (uint8_t)constrain(_tcsTable[i].g * 255.0f, 0, 255);
    ee.b[i] = (uint8_t)constrain(_tcsTable[i].b * 255.0f, 0, 255);
    ee.L[i] = (uint8_t)constrain(_tcsTable[i].L * 200.0f, 0, 255);
  }
  EEPROM.begin(TCS_EE_SIZE);
  EEPROM.put(TCS_EE_ADDR, ee);
  EEPROM.commit();        // ESP32: begin/put/commit (ไม่ต้อง end)
}

inline bool tcs_loadCal() {
  TcsCalEE ee;
  EEPROM.begin(TCS_EE_SIZE);
  EEPROM.get(TCS_EE_ADDR, ee);

  if (ee.magic != TCS_EE_MAGIC) return false;

  _tcsWhiteC = (ee.cwhite < 1) ? _tcsFullScale : ee.cwhite;
  _tcsWhiteR = (ee.wr < 1) ? _tcsFullScale : ee.wr;
  _tcsWhiteG = (ee.wg < 1) ? _tcsFullScale : ee.wg;
  _tcsWhiteB = (ee.wb < 1) ? _tcsFullScale : ee.wb;
  for (int i = 0; i < 8; i++) {
    _tcsTable[i].used = ee.used[i] != 0;
    _tcsTable[i].r = ee.r[i] / 255.0f;
    _tcsTable[i].g = ee.g[i] / 255.0f;
    _tcsTable[i].b = ee.b[i] / 255.0f;
    _tcsTable[i].L = ee.L[i] / 200.0f;
    strncpy(_tcsTable[i].name, _TCS_STD_NAME[i], 9);
    _tcsTable[i].name[9] = '\0';
  }
  return true;
}

inline bool tcs_hasCal() {
  TcsCalEE ee;
  EEPROM.begin(TCS_EE_SIZE);
  EEPROM.get(TCS_EE_ADDR, ee);
  return ee.magic == TCS_EE_MAGIC;
}

// ── กดปุ่ม SW (pin 15) ค้างตอนเปิดไหม ───────────────────────
inline bool tcs_bootHeld(int holdMs = 1200) {
  pinMode(TCS_BTN, INPUT_PULLUP);
  if (digitalRead(TCS_BTN) != LOW) return false;
  unsigned long t = millis();
  while (digitalRead(TCS_BTN) == LOW) {
    if (millis() - t >= (unsigned long)holdMs) return true;
  }
  return false;
}

// ── สอนสีทั้งชุด + บันทึก (OLED 128x32 + ปุ่ม15 + buzzer12) ──
inline void tcs_teachAll(int count = 6) {
  if (count < 1) count = 1; if (count > 8) count = 8;
  pinMode(TCS_BTN, INPUT_PULLUP);

  for (int i = 0; i < count; i++) {
    oled_clear();
    oled(1, "TEACH: ", _TCS_STD_NAME[i], 1);
    oled(2, "put sensor on it", 1);
    oled(3, "press BTN(15)", 1);
    oled_update();

    while (digitalRead(TCS_BTN) != LOW) delay(8);
    delay(150);
    tcs_teach(i, _TCS_STD_NAME[i]);
    buzzBeep(120);

    oled_clear(); oled(1, "Saved!", 2); oled_update();
    delay(300);
    while (digitalRead(TCS_BTN) == LOW) delay(8);
  }

  tcs_saveCal();
  oled_clear();
  oled(1, "TEACH DONE", 1);
  oled(2, "SAVED to EEPROM", 1);
  oled(3, "Power cycle -> RUN", 1);
  oled_update();
  buzzBeep(150); delay(50);
  buzzBeep(150); delay(50);
  while (true) delay(100);
}

// ── คาลิเบรต (บล็อกเดียวจบ) — กดค้าง=สอน / เปิดปกติ=โหลด ─────
inline void tcs_calibrate(int count = 6) {
  if (tcs_bootHeld()) {
    tcs_teachAll(count);
  } else if (!tcs_loadCal()) {
    oled_clear();
    oled(1, "NO COLOR CAL!", 1);
    oled(2, "Hold BTN at boot", 1);
    oled(3, "to TEACH colors", 1);
    oled_update();
    buzzBeep(200); delay(120);
    buzzBeep(200); delay(120);
    delay(1200);
  }
}
