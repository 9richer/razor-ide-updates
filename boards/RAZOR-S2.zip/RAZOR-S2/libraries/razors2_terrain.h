#pragma once
// ══════════════════════════════════════════════════════════════
//  razors2_terrain.h — ตัวจำแนกสภาพพื้น (ใช้ร่วมทุกชิป IMU)
//
//  แนวคิด: แกนกลางไม่รู้จักชิป รับแค่ 2 ค่าต่อรอบ แล้วจำแนกเอง
//    • terrainFeed(pitchDeg, rockDps)  — ไจโรจริง หน่วย °/s
//        ใช้กับ MPU6050/GY91/ICM20948, BNO055, BNO085(โหมด GIRV)
//    • terrainFeedAngle(pitchDeg)      — ไม่มีไจโรดิบ คำนวณ rock จากอัตราเปลี่ยน pitch
//        ใช้กับ BNO085 โหมด mag (RotationVector) เท่านั้น
//
//  ผลลัพธ์: 0=พื้นราบ  1=ทางเอียง(สะพาน)  2=ลูกระนาด
//  จูนได้ตอนรัน: setTerrainRamp / setTerrainBump / setTerrainBumpCount
// ══════════════════════════════════════════════════════════════

#include <Arduino.h>
#include <math.h>

#define TERRAIN_FLAT 0          // พื้นราบ
#define TERRAIN_RAMP 1          // ทางเอียง (สะพาน)
#define TERRAIN_BUMP 2          // ลูกระนาด

// ── ค่าเริ่มต้น (ปรับตอนรันได้จากบล็อกใน Setup) ────────────────
//  ตั้งไวพอประมาณให้ใช้ได้เลย — ถ้าจับผิด/ไม่ทัน ค่อยจูนด้วยบล็อก Setup
#define TERRAIN_RAMP_TH   5.0f  // องศา  — |tilt| เกินนี้ = ทางเอียง
#define TERRAIN_BUMP_TH   50.0f // °/s   — ความแรงที่นับเป็น "กระดก 1 ครั้ง"
#define TERRAIN_BUMP_CNT  3     // ครั้ง — กระดกกี่ครั้งในหน้าต่าง = ลูกระนาด
#define TERRAIN_WINDOW    1500  // ms    — หน้าต่างเวลานับจำนวนกระดก
#define TERRAIN_HOLD      3     // อ่านซ้ำกี่ครั้งจึงเปลี่ยนสถานะ (กันกระพริบ)

static float _terr_rampTh  = TERRAIN_RAMP_TH;
static float _terr_bumpTh  = TERRAIN_BUMP_TH;
static int   _terr_bumpMin = TERRAIN_BUMP_CNT;
inline void setTerrainRamp(float deg)      { _terr_rampTh  = deg; }  // องศา เกินนี้=ทางเอียง
inline void setTerrainBump(float dps)      { _terr_bumpTh  = dps; }  // °/s ระดับนับเป็นกระดก 1 ครั้ง
inline void setTerrainBumpCount(int n)     { _terr_bumpMin = n;   }  // กระดกกี่ครั้ง=ลูกระนาด

// ── สถานะ ─────────────────────────────────────────────────────
static float _terr_tilt        = 0.0f;   // มุมก้ม-เงย กรองแล้ว (องศา)
static float _terr_bump        = 0.0f;   // ความแรงกระดก กรองแล้ว (°/s) — ไว้ดูระดับ
static int   _terr_state       = TERRAIN_FLAT;   // สถานะที่ยืนยันแล้ว
static int   _terr_cand        = TERRAIN_FLAT;   // สถานะที่กำลังลุ้น
static int   _terr_candCnt     = 0;

static unsigned long _terr_bumpTimes[8] = {0};   // เวลาที่กระดกแต่ละครั้ง (ring)
static int  _terr_bumpHead = 0;
static bool _terr_inBump   = false;              // hysteresis
static int  _terr_bumpNow  = 0;                  // จำนวนครั้งในหน้าต่างล่าสุด

// อัตราเปลี่ยน pitch สำหรับชิป fusion
static float         _terr_prevPitch = 0.0f;
static unsigned long _terr_prevUs    = 0;
static bool          _terr_firstAng  = true;

// ── ป้อนค่า: pitch (องศา) + rock (°/s) แล้วจำแนก ───────────────
inline void terrainFeed(float pitchDeg, float rockDps) {
  _terr_tilt = 0.9f * _terr_tilt + 0.1f * pitchDeg;
  _terr_bump = 0.8f * _terr_bump + 0.2f * rockDps;

  // นับ "ครั้ง" ที่กระดก ด้วย hysteresis (กันนับซ้ำจากสัญญาณสั่น)
  unsigned long nowMs = millis();
  if (!_terr_inBump && rockDps > _terr_bumpTh) {              // ขึ้นเกินระดับ = กระดก 1 ครั้ง
    _terr_inBump = true;
    _terr_bumpTimes[_terr_bumpHead] = nowMs;
    _terr_bumpHead = (_terr_bumpHead + 1) % 8;
  } else if (_terr_inBump && rockDps < _terr_bumpTh * 0.5f) { // ตกลงต่ำ = พร้อมนับครั้งใหม่
    _terr_inBump = false;
  }
  int bumpCnt = 0;
  for (int i = 0; i < 8; i++)
    if (_terr_bumpTimes[i] != 0 && (nowMs - _terr_bumpTimes[i]) <= TERRAIN_WINDOW) bumpCnt++;
  _terr_bumpNow = bumpCnt;

  int cand;
  if      (bumpCnt >= _terr_bumpMin)         cand = TERRAIN_BUMP;   // กระดกซ้ำหลายครั้ง
  else if (fabsf(_terr_tilt) > _terr_rampTh) cand = TERRAIN_RAMP;
  else                                       cand = TERRAIN_FLAT;

  if (cand == _terr_cand) { if (_terr_candCnt < 1000) _terr_candCnt++; }
  else                    { _terr_cand = cand; _terr_candCnt = 0; }
  if (_terr_candCnt >= TERRAIN_HOLD) _terr_state = cand;
}

// ── ป้อนเฉพาะมุม (ชิป fusion) — คำนวณ rock จากอัตราเปลี่ยน pitch ─
inline void terrainFeedAngle(float pitchDeg) {
  unsigned long now = micros();
  float dt = (now - _terr_prevUs) / 1000000.0f;
  float rock = 0.0f;
  if (!_terr_firstAng) {
    if (dt < 0.01f) dt = 0.01f;        // กันหารด้วยค่าน้อยเกิน (ลดสัญญาณรบกวน)
    if (dt > 0.2f)  dt = 0.2f;
    rock = fabsf(pitchDeg - _terr_prevPitch) / dt;
  }
  _terr_prevPitch = pitchDeg;
  _terr_prevUs    = now;
  _terr_firstAng  = false;
  terrainFeed(pitchDeg, rock);
}

// ── อ่านค่า ───────────────────────────────────────────────────
inline int   terrainGet()       { return _terr_state; }
inline float terrainTilt()      { return _terr_tilt;  }
inline float terrainBump()      { return _terr_bump;  }
inline int   terrainBumpCount() { return _terr_bumpNow; }
