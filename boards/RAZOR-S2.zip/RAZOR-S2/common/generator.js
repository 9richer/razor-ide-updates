// ============================================================
//  ESP32 Board Generator — Arduino C++ code
// ============================================================

// ── I/O ──
Blockly.Arduino.forBlock['esp32_digital_write'] = function(block) {
  const pin = block.getFieldValue('PIN');
  const val = block.getFieldValue('VAL');
  return `digitalWrite(${pin}, ${val});\n`;
};
Blockly.Arduino.forBlock['esp32_digital_read'] = function(block) {
  const pin = block.getFieldValue('PIN');
  return [`digitalRead(${pin})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_pin_mode'] = function(block) {
  const pin  = block.getFieldValue('PIN');
  const mode = block.getFieldValue('MODE');
  return `pinMode(${pin}, ${mode});\n`;
};
Blockly.Arduino.forBlock['esp32_analog_read'] = function(block) {
  const pin = block.getFieldValue('PIN');
  return [`analogRead(${pin})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_analog_write'] = function(block) {
  const pin = block.getFieldValue('PIN');
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `analogWrite(${pin}, ${val});\n`;
};

// ── Serial ──
Blockly.Arduino.forBlock['esp32_serial_begin'] = function(block) {
  return `Serial.begin(${block.getFieldValue('BAUD')});\n`;
};
Blockly.Arduino.forBlock['esp32_serial_print'] = function(block) {
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  const nl  = block.getFieldValue('NL') === 'TRUE';
  return nl ? `Serial.println(${val});\n` : `Serial.print(${val});\n`;
};
Blockly.Arduino.forBlock['esp32_serial_println'] = function(block) {
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  return `Serial.println(${val});\n`;
};
Blockly.Arduino.forBlock['esp32_serial_available'] = function(block) {
  return ['Serial.available()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_serial_read'] = function(block) {
  return ['Serial.read()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_serial_readstring'] = function(block) {
  return ['Serial.readString()', Blockly.Arduino.ORDER_ATOMIC];
};

// ── WiFi (เติม #include เฉพาะตอนใช้ — กิน flash ~200KB ไม่บวกทุกสเก็ตช์) ──
function _wifiinc() {
  if (Blockly.Arduino.__extraIncludes) Blockly.Arduino.__extraIncludes.add('#include <WiFi.h>');
}
Blockly.Arduino.forBlock['esp32_wifi_connect'] = function(block) {
  _wifiinc();
  const ssid = block.getFieldValue('SSID');
  const pass = block.getFieldValue('PASS');
  return `WiFi.begin("${ssid}", "${pass}");\nwhile(WiFi.status() != WL_CONNECTED) { delay(500); }\n`;
};
Blockly.Arduino.forBlock['esp32_wifi_connected'] = function(block) {
  _wifiinc();
  return ['(WiFi.status() == WL_CONNECTED)', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_wifi_ip'] = function(block) {
  _wifiinc();
  return ['WiFi.localIP().toString()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_wifi_disconnect'] = function(block) {
  _wifiinc();
  return 'WiFi.disconnect();\n';
};

// ── LED ──
Blockly.Arduino.forBlock['esp32_builtin_led'] = function(block) {
  const val = block.getFieldValue('VAL');
  return `digitalWrite(2, ${val});\n`;
};
Blockly.Arduino.forBlock['esp32_ledc_setup'] = function(block) {
  const ch   = block.getFieldValue('CH');
  const freq = block.getFieldValue('FREQ');
  const res  = block.getFieldValue('RES');
  return `ledcSetup(${ch}, ${freq}, ${res});\n`;
};
Blockly.Arduino.forBlock['esp32_ledc_attach'] = function(block) {
  const pin = block.getFieldValue('PIN');
  const ch  = block.getFieldValue('CH');
  return `ledcAttachPin(${pin}, ${ch});\n`;
};
Blockly.Arduino.forBlock['esp32_ledc_write'] = function(block) {
  const ch   = block.getFieldValue('CH');
  const duty = Blockly.Arduino.valueToCode(block, 'DUTY', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `ledcWrite(${ch}, ${duty});\n`;
};

// ── Touch ──
Blockly.Arduino.forBlock['esp32_touch_read'] = function(block) {
  const pin = block.getFieldValue('PIN');
  return [`touchRead(${pin})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ── Timer ──
Blockly.Arduino.forBlock['esp32_delay_ms'] = function(block) {
  const t = Blockly.Arduino.valueToCode(block, 'TIME', Blockly.Arduino.ORDER_ATOMIC) || '1000';
  return `delay(${t});\n`;
};
Blockly.Arduino.forBlock['esp32_millis'] = function(block) {
  return ['millis()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_micros'] = function(block) {
  return ['micros()', Blockly.Arduino.ORDER_ATOMIC];
};

// ── Math ──
Blockly.Arduino.forBlock['esp32_map'] = function(block) {
  const val    = Blockly.Arduino.valueToCode(block, 'VAL',     Blockly.Arduino.ORDER_ATOMIC) || '0';
  const inMin  = Blockly.Arduino.valueToCode(block, 'IN_MIN',  Blockly.Arduino.ORDER_ATOMIC) || '0';
  const inMax  = Blockly.Arduino.valueToCode(block, 'IN_MAX',  Blockly.Arduino.ORDER_ATOMIC) || '1023';
  const outMin = Blockly.Arduino.valueToCode(block, 'OUT_MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const outMax = Blockly.Arduino.valueToCode(block, 'OUT_MAX', Blockly.Arduino.ORDER_ATOMIC) || '255';
  return [`map(${val}, ${inMin}, ${inMax}, ${outMin}, ${outMax})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_constrain'] = function(block) {
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mn  = Blockly.Arduino.valueToCode(block, 'MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mx  = Blockly.Arduino.valueToCode(block, 'MAX', Blockly.Arduino.ORDER_ATOMIC) || '255';
  return [`constrain(${val}, ${mn}, ${mx})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_random'] = function(block) {
  const mn = Blockly.Arduino.valueToCode(block, 'MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mx = Blockly.Arduino.valueToCode(block, 'MAX', Blockly.Arduino.ORDER_ATOMIC) || '100';
  return [`random(${mn}, ${mx})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ── System ──
Blockly.Arduino.forBlock['esp32_restart'] = function(block) {
  return 'ESP.restart();\n';
};
Blockly.Arduino.forBlock['esp32_free_heap'] = function(block) {
  return ['ESP.getFreeHeap()', Blockly.Arduino.ORDER_ATOMIC];
};

// ── Sonar (RAZOR-S2 / HC-SR04) ──
Blockly.Arduino.forBlock['s2_sonar'] = function(block) {
  const trig = block.getFieldValue('TRIG');
  const echo = block.getFieldValue('ECHO');
  return [`s2Sonar(${trig}, ${echo})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ── OLED (RAZOR-S2 / S2_oled.h) ──
Blockly.Arduino.forBlock['s2_oled_size'] = function(block) {
  return 'oled_setSize(' + block.getFieldValue('H') + ');\n';
};
Blockly.Arduino.forBlock['s2_oled_clear'] = function() {
  return 'oled_clear();\n';
};
Blockly.Arduino.forBlock['s2_oled_update'] = function() {
  return 'oled_update();\n';
};
Blockly.Arduino.forBlock['s2_oled_print'] = function(block) {
  const line = block.getFieldValue('LINE');
  const sz   = block.getFieldValue('SZ');
  const val  = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  return `oled(${line}, ${val}, ${sz});\n`;
};
Blockly.Arduino.forBlock['s2_oled_label'] = function(block) {
  const line  = block.getFieldValue('LINE');
  const sz    = block.getFieldValue('SZ');
  const label = Blockly.Arduino.valueToCode(block, 'LABEL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  const val   = Blockly.Arduino.valueToCode(block, 'VAL',   Blockly.Arduino.ORDER_ATOMIC) || '""';
  return `oled(${line}, String(${label}), ${val}, ${sz});\n`;
};
Blockly.Arduino.forBlock['s2_oled_xy'] = function(block) {
  const x   = Blockly.Arduino.valueToCode(block, 'X',   Blockly.Arduino.ORDER_ATOMIC) || '0';
  const y   = Blockly.Arduino.valueToCode(block, 'Y',   Blockly.Arduino.ORDER_ATOMIC) || '0';
  const sz  = block.getFieldValue('SZ');
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  return `oled_xy(${x}, ${y}, ${val}, ${sz});\n`;
};
Blockly.Arduino.forBlock['s2_oled_line'] = function(block) {
  const x1 = Blockly.Arduino.valueToCode(block, 'X1', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const y1 = Blockly.Arduino.valueToCode(block, 'Y1', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const x2 = Blockly.Arduino.valueToCode(block, 'X2', Blockly.Arduino.ORDER_ATOMIC) || '127';
  const y2 = Blockly.Arduino.valueToCode(block, 'Y2', Blockly.Arduino.ORDER_ATOMIC) || '31';
  return `oled_line(${x1}, ${y1}, ${x2}, ${y2});\n`;
};
Blockly.Arduino.forBlock['s2_oled_rect'] = function(block) {
  const x    = Blockly.Arduino.valueToCode(block, 'X', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const y    = Blockly.Arduino.valueToCode(block, 'Y', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const w    = Blockly.Arduino.valueToCode(block, 'W', Blockly.Arduino.ORDER_ATOMIC) || '50';
  const h    = Blockly.Arduino.valueToCode(block, 'H', Blockly.Arduino.ORDER_ATOMIC) || '20';
  const fill = block.getFieldValue('FILL');
  return fill === '1'
    ? `oled_fill_rect(${x}, ${y}, ${w}, ${h});\n`
    : `oled_rect(${x}, ${y}, ${w}, ${h});\n`;
};
Blockly.Arduino.forBlock['s2_oled_progress'] = function(block) {
  const x   = Blockly.Arduino.valueToCode(block, 'X',   Blockly.Arduino.ORDER_ATOMIC) || '0';
  const y   = Blockly.Arduino.valueToCode(block, 'Y',   Blockly.Arduino.ORDER_ATOMIC) || '20';
  const w   = Blockly.Arduino.valueToCode(block, 'W',   Blockly.Arduino.ORDER_ATOMIC) || '100';
  const h   = Blockly.Arduino.valueToCode(block, 'H',   Blockly.Arduino.ORDER_ATOMIC) || '8';
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `oled_progress(${x}, ${y}, ${w}, ${h}, ${val});\n`;
};
Blockly.Arduino.forBlock['s2_oled_invert'] = function(block) {
  const inv = block.getFieldValue('INV');
  return `oled_invert(${inv === '1' ? 'true' : 'false'});\n`;
};

// ── Servo (RAZOR-S2 / LEDC) ──
Blockly.Arduino.forBlock['s2_servo'] = function(block) {
  const pin   = block.getFieldValue('PIN');
  const angle = Blockly.Arduino.valueToCode(block, 'ANGLE', Blockly.Arduino.ORDER_ATOMIC) || '90';
  const spd   = Blockly.Arduino.valueToCode(block, 'SPEED', Blockly.Arduino.ORDER_ATOMIC) || '10';
  return `s2ServoMove(${pin}, ${angle}, ${spd});\n`;
};
Blockly.Arduino.forBlock['s2_servo_fast'] = function(block) {
  const pin   = block.getFieldValue('PIN');
  const angle = Blockly.Arduino.valueToCode(block, 'ANGLE', Blockly.Arduino.ORDER_ATOMIC) || '90';
  return `s2ServoWrite(${pin}, ${angle});\n`;
};

// ── Motor (RAZOR-S2 / S2_motor.h) — ใช้ offset ──
Blockly.Arduino.forBlock['s2_motor_offset'] = function(block) {
  const l = Blockly.Arduino.valueToCode(block, 'LEFT',  Blockly.Arduino.ORDER_ATOMIC) || '0';
  const r = Blockly.Arduino.valueToCode(block, 'RIGHT', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `_s2MotorOffL = ${l}; _s2MotorOffR = ${r};\n`;
};
// ── ควบคุมมอเตอร์ (FORWARD/BACKWARD L+R, motorL/R, หยุด) ──
// FORWARD/BACKWARD ชดเชย offset ให้วิ่งตรง | motorL/R = raw signed -100..100
Blockly.Arduino.forBlock['s2_forward'] = function(block) {
  var l = Blockly.Arduino.valueToCode(block, 'SPDL', Blockly.Arduino.ORDER_ATOMIC) || '50';
  var r = Blockly.Arduino.valueToCode(block, 'SPDR', Blockly.Arduino.ORDER_ATOMIC) || '50';
  return `motorL(constrain((${l}) + _s2MotorOffL, -100, 100)); motorR(constrain((${r}) + _s2MotorOffR, -100, 100));\n`;
};
Blockly.Arduino.forBlock['s2_backward'] = function(block) {
  var l = Blockly.Arduino.valueToCode(block, 'SPDL', Blockly.Arduino.ORDER_ATOMIC) || '50';
  var r = Blockly.Arduino.valueToCode(block, 'SPDR', Blockly.Arduino.ORDER_ATOMIC) || '50';
  return `motorL(constrain(-((${l}) + _s2MotorOffL), -100, 100)); motorR(constrain(-((${r}) + _s2MotorOffR), -100, 100));\n`;
};
Blockly.Arduino.forBlock['s2_motorL'] = function(block) {
  var spd = Blockly.Arduino.valueToCode(block, 'SPD', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `motorL(${spd});\n`;
};
Blockly.Arduino.forBlock['s2_motorR'] = function(block) {
  var spd = Blockly.Arduino.valueToCode(block, 'SPD', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `motorR(${spd});\n`;
};
Blockly.Arduino.forBlock['s2_stop'] = function(block) {
  return 'motorL(0); motorR(0);\n';
};

// forever — while(true)
Blockly.Arduino.forBlock['forever'] = function(block) {
  const body = Blockly.Arduino.statementToCode(block, 'DO');
  return 'while (true) {\n' + body + '}\n';
};

// ══════════════════════════════════════════════════════════════
//  IMU (MPU6050) Generators — RAZOR-S2
//  ชื่อ function ตรงกับ razors2_imu.h ทุกตัว
// ══════════════════════════════════════════════════════════════

function _v2(block, name, def) {
  return Blockly.Arduino.valueToCode(block, name, Blockly.Arduino.ORDER_ATOMIC) || def;
}

Blockly.Arduino.forBlock['imu_select'] = function(block) {
  return 'setIMU(' + block.getFieldValue('IMU') + ');\n';
};
Blockly.Arduino.forBlock['imu_calibrate'] = function(block) {
  return 'initIMU();\ncalibrateYawStart();\n';
};
Blockly.Arduino.forBlock['imu_reset_yaw'] = function(block) {
  return 'resetYaw(' + (_v2(block,'SAMPLES','10')) + ');\n';
};
Blockly.Arduino.forBlock['imu_get_yaw'] = function(block) {
  return ['getYaw()', Blockly.Arduino.ORDER_UNARY_POSTFIX];
};
Blockly.Arduino.forBlock['imu_get_yaw_raw'] = function(block) {
  return ['getYawRaw()', Blockly.Arduino.ORDER_UNARY_POSTFIX];
};

Blockly.Arduino.forBlock['imu_spin_config'] = function(block) {
  const kpf=_v2(block,'KP_FAST','6.0'), kpm=_v2(block,'KP_MID','3.5');
  const kps=_v2(block,'KP_SLOW','1.5'), kd=_v2(block,'KD','0.3');
  return `setSpinConfig(${kpf}, ${kpm}, ${kps}, ${kd});\n`;
};

Blockly.Arduino.forBlock['imu_spin_to_dir'] = function(block) {
  const yaw=block.getFieldValue('YAW');
  const err=_v2(block,'ERR','1.5'), tout=_v2(block,'TIMEOUT','200');
  const smin=_v2(block,'SMIN','40'), smax=_v2(block,'SMAX','70');
  return `spinTo(${yaw}, ${err}, ${tout}, ${smin}, ${smax});\n`;
};
Blockly.Arduino.forBlock['imu_spin_to_num'] = function(block) {
  const yaw=_v2(block,'YAW','90');
  const err=_v2(block,'ERR','1.5'), tout=_v2(block,'TIMEOUT','200');
  const smin=_v2(block,'SMIN','40'), smax=_v2(block,'SMAX','70');
  return `spinTo(${yaw}, ${err}, ${tout}, ${smin}, ${smax});\n`;
};

Blockly.Arduino.forBlock['imu_turnF_pid'] = function(block) {
  const yaw=_v2(block,'YAW','90'), smin=_v2(block,'SMIN','20'), smax=_v2(block,'SMAX','80');
  const kp=_v2(block,'KP','2.0'), kd=_v2(block,'KD','0.1');
  const err=_v2(block,'ERR','5.0'), tout=_v2(block,'TIMEOUT','2000');
  return `TurnF_PID(${yaw}, ${smin}, ${smax}, ${kp}, ${kd}, ${err}, ${tout});\n`;
};
Blockly.Arduino.forBlock['imu_turnB_pid'] = function(block) {
  const yaw=_v2(block,'YAW','90'), smin=_v2(block,'SMIN','20'), smax=_v2(block,'SMAX','80');
  const kp=_v2(block,'KP','2.0'), kd=_v2(block,'KD','0.1');
  const err=_v2(block,'ERR','5.0'), tout=_v2(block,'TIMEOUT','2000');
  return `TurnB_PID(${yaw}, ${smin}, ${smax}, ${kp}, ${kd}, ${err}, ${tout});\n`;
};
Blockly.Arduino.forBlock['imu_turnF_pid_dir'] = function(block) {
  const yaw=block.getFieldValue('YAW'), smin=_v2(block,'SMIN','20'), smax=_v2(block,'SMAX','80');
  const kp=_v2(block,'KP','2.0'), kd=_v2(block,'KD','0.1');
  const err=_v2(block,'ERR','5.0'), tout=_v2(block,'TIMEOUT','2000');
  return `TurnF_PID(${yaw}, ${smin}, ${smax}, ${kp}, ${kd}, ${err}, ${tout});\n`;
};
Blockly.Arduino.forBlock['imu_turnB_pid_dir'] = function(block) {
  const yaw=block.getFieldValue('YAW'), smin=_v2(block,'SMIN','20'), smax=_v2(block,'SMAX','80');
  const kp=_v2(block,'KP','2.0'), kd=_v2(block,'KD','0.1');
  const err=_v2(block,'ERR','5.0'), tout=_v2(block,'TIMEOUT','2000');
  return `TurnB_PID(${yaw}, ${smin}, ${smax}, ${kp}, ${kd}, ${err}, ${tout});\n`;
};

Blockly.Arduino.forBlock['imu_spin_dir'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=block.getFieldValue('YAW');
  const smax=_v2(block,'SMAX','80'), smin=_v2(block,'SMIN','30');
  const thr=_v2(block,'THR','3.0'), tout=_v2(block,'TIMEOUT','2000');
  const fn = dir==='B' ? 'spinTo_B' : 'spinTo_F';
  return `${fn}(${yaw}, ${smax}, ${smin}, ${thr}, ${tout});\n`;
};
Blockly.Arduino.forBlock['imu_spin_num'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=_v2(block,'YAW','90');
  const smax=_v2(block,'SMAX','80'), smin=_v2(block,'SMIN','30');
  const thr=_v2(block,'THR','3.0'), tout=_v2(block,'TIMEOUT','2000');
  const fn = dir==='B' ? 'spinTo_B' : 'spinTo_F';
  return `${fn}(${yaw}, ${smax}, ${smin}, ${thr}, ${tout});\n`;
};

Blockly.Arduino.forBlock['imu_turns_dir'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=block.getFieldValue('YAW');
  const smax=_v2(block,'SMAX','80'), smin=_v2(block,'SMIN','20');
  const thr=_v2(block,'THR','3.0'), tout=_v2(block,'TIMEOUT','2000');
  const fn = dir==='B' ? 'TurnB_S' : 'TurnF_S';
  return `${fn}(${yaw}, ${smax}, ${smin}, ${thr}, ${tout});\n`;
};
Blockly.Arduino.forBlock['imu_turns_num'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=_v2(block,'YAW','90');
  const smax=_v2(block,'SMAX','80'), smin=_v2(block,'SMIN','20');
  const thr=_v2(block,'THR','3.0'), tout=_v2(block,'TIMEOUT','2000');
  const fn = dir==='B' ? 'TurnB_S' : 'TurnF_S';
  return `${fn}(${yaw}, ${smax}, ${smin}, ${thr}, ${tout});\n`;
};

Blockly.Arduino.forBlock['imu_move'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=block.getFieldValue('YAW');
  const spd=_v2(block,'SPD','50'), time=_v2(block,'TIME','500');
  const kp=_v2(block,'KP','1'), ki=_v2(block,'KI','0'), kd=_v2(block,'KD','0.1');
  const ru=_v2(block,'RAMPUP','0'), rd=_v2(block,'RAMPDOWN','0'), ss=_v2(block,'STARTSPD','30');
  return `MOVE(${dir}, ${yaw}, ${spd}, ${time}, ${kp}, ${ki}, ${kd}, ${ru}, ${rd}, ${ss});\n`;
};
Blockly.Arduino.forBlock['imu_move_num'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=_v2(block,'YAW','0');
  const spd=_v2(block,'SPD','50'), time=_v2(block,'TIME','500');
  const kp=_v2(block,'KP','1'), ki=_v2(block,'KI','0'), kd=_v2(block,'KD','0.1');
  const ru=_v2(block,'RAMPUP','0'), rd=_v2(block,'RAMPDOWN','0'), ss=_v2(block,'STARTSPD','30');
  return `MOVE(${dir}, ${yaw}, ${spd}, ${time}, ${kp}, ${ki}, ${kd}, ${ru}, ${rd}, ${ss});\n`;
};

Blockly.Arduino.forBlock['s2_enc_setup'] = function(block) {
  const pinL = block.getFieldValue('PINL');
  const pinR = block.getFieldValue('PINR');
  const tpc  = _v2(block, 'TPC', '20');
  return `setupEncoder(${pinL}, ${pinR}, ${tpc});\n`;
};
Blockly.Arduino.forBlock['s2_move_enc'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=_v2(block,'YAW','0');
  const spd=_v2(block,'SPD','50'), dist=_v2(block,'DIST','30');
  const kp=_v2(block,'KP','1'), ki=_v2(block,'KI','0'), kd=_v2(block,'KD','0.1');
  const ru=_v2(block,'RAMPUP','0'), rd=_v2(block,'RAMPDOWN','0'), ss=_v2(block,'STARTSPD','30');
  return `MOVE_ENC(${dir}, ${yaw}, ${spd}, ${dist}, ${kp}, ${ki}, ${kd}, ${ru}, ${rd}, ${ss});\n`;
};
Blockly.Arduino.forBlock['s2_enc_read'] = function(block) {
  return ['encDistanceCm()', Blockly.Arduino.ORDER_UNARY_POSTFIX];
};

Blockly.Arduino.forBlock['imu_move_wall'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=block.getFieldValue('YAW');
  const ss=_v2(block,'STARTSPD','30'), spd=_v2(block,'SPD','50'), time=_v2(block,'TIME','1000');
  const kpy=_v2(block,'KP_YAW','1.0'), kpw=_v2(block,'KP_WALL','0.5');
  const dist=_v2(block,'DIST','20');
  const trig=block.getFieldValue('TRIG'), echo=block.getFieldValue('ECHO');
  const ru=_v2(block,'RAMPUP','0'), rd=_v2(block,'RAMPDOWN','0');
  return `MOVE_WALL(${dir}, ${yaw}, ${spd}, ${time}, ${kpy}, ${kpw}, ${dist}, ${trig}, ${echo}, ${ru}, ${rd}, ${ss});\n`;
};

Blockly.Arduino.forBlock['imu_move_loop_reset'] = function(block) {
  return 'MOVE_LOOP_RESET();\n';
};
Blockly.Arduino.forBlock['imu_move_loop'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=block.getFieldValue('YAW');
  const ss=_v2(block,'STARTSPD','30'), spd=_v2(block,'SPD','60');
  const kpy=_v2(block,'KPYAW','1.0'), kdy=_v2(block,'KDYAW','0');
  return `MOVE_LOOP(${dir}, ${yaw}, ${spd}, ${kpy}, ${kdy}, ${ss});\n`;
};
Blockly.Arduino.forBlock['imu_move_loop_num'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=_v2(block,'YAW','0');
  const ss=_v2(block,'STARTSPD','30'), spd=_v2(block,'SPD','60');
  const kpy=_v2(block,'KPYAW','1.0'), kdy=_v2(block,'KDYAW','0');
  return `MOVE_LOOP(${dir}, ${yaw}, ${spd}, ${kpy}, ${kdy}, ${ss});\n`;
};
Blockly.Arduino.forBlock['imu_move_wall_loop'] = function(block) {
  const dir=block.getFieldValue('DIR'), yaw=block.getFieldValue('YAW');
  const ss=_v2(block,'STARTSPD','30'), spd=_v2(block,'SPD','60');
  const kpy=_v2(block,'KPYAW','1.0'), kpw=_v2(block,'KPWALL','0.5');
  const wd=_v2(block,'WALLDIST','20');
  const trig=block.getFieldValue('TRIG'), echo=block.getFieldValue('ECHO');
  return `MOVE_WALL_LOOP(${dir}, ${yaw}, ${spd}, ${kpy}, ${kpw}, ${wd}, ${trig}, ${echo}, ${ss});\n`;
};

// ── PS3 Controller (เติม #include เฉพาะตอนใช้) ──
function _ps3inc() {
  if (Blockly.Arduino.__extraIncludes) Blockly.Arduino.__extraIncludes.add('#include <Ps3Controller.h>');
}
Blockly.Arduino.forBlock['ps3_begin'] = function(block) {
  _ps3inc();
  // เว้น MAC ว่าง → Ps3.begin() ใช้ BT MAC จริงของชิป (ไม่ override base MAC)
  // เลี่ยงปัญหา esp_base_mac_addr_set บน core 3.x ที่ทำให้จอยเชื่อมไม่ติด
  var mac = (block.getFieldValue('MAC') || '').trim();
  return mac ? `Ps3.begin("${mac}");\n` : 'Ps3.begin();\n';
};
Blockly.Arduino.forBlock['ps3_connected'] = function() {
  _ps3inc();
  return ['Ps3.isConnected()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['ps3_button'] = function(block) {
  _ps3inc();
  return [`Ps3.data.button.${block.getFieldValue('BTN')}`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['ps3_stick'] = function(block) {
  _ps3inc();
  return [`Ps3.data.analog.stick.${block.getFieldValue('AXIS')}`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['ps3_rumble'] = function(block) {
  _ps3inc();
  const i = Blockly.Arduino.valueToCode(block, 'INTENSITY', Blockly.Arduino.ORDER_ATOMIC) || '100';
  const d = Blockly.Arduino.valueToCode(block, 'DUR', Blockly.Arduino.ORDER_ATOMIC) || '300';
  return `Ps3.setRumble(${i}, ${d});\n`;
};

// ── Buzzer (active, pin 12 — ON/OFF เท่านั้น) ──
Blockly.Arduino.forBlock['s2_buzzer_tone'] = function(block) {
  const dur = Blockly.Arduino.valueToCode(block, 'DUR', Blockly.Arduino.ORDER_ATOMIC) || '200';
  return `buzzBeep(${dur});\n`;
};
Blockly.Arduino.forBlock['s2_buzzer_on'] = function() {
  return 'buzzOn();\n';
};
Blockly.Arduino.forBlock['s2_buzzer_off'] = function() {
  return 'buzzOff();\n';
};

// ── Button ──
Blockly.Arduino.forBlock['s2_button'] = function() {
  return ['(digitalRead(15) == LOW)', Blockly.Arduino.ORDER_ATOMIC];
};

// ── Robot Menu ────────────────────────────────────────────────
// กดสั้น (< 600ms) = เลือก & รัน  |  กดค้าง (≥ 600ms) = เลื่อนถัดไป
// OLED scrolling window — รองรับ 2-8 รายการ  | ปุ่ม = pin 15 (active-low)
Blockly.Arduino.forBlock['robot_menu'] = function(block) {
  const count = block.itemCount_ || 4;
  const names = [];
  const dos   = [];
  for (let i = 0; i < count; i++) {
    names.push((block.getFieldValue('NAME' + i) || ('Mode ' + (i + 1))).split('"').join('\\"'));
    dos.push(Blockly.Arduino.statementToCode(block, 'DO' + i));
  }

  let code = '{\n';
  code += '  int _ms = 0;\n';
  code += '  const int _mc = ' + count + ';\n';
  code += '  const char* _mn[' + count + '] = {' +
          names.map(function(n){ return '"' + n + '"'; }).join(', ') + '};\n';

  // lambda แสดงเมนู — scrolling window 4 บรรทัด + header position
  code += '  auto _mshow = [&]() {\n';
  code += '    oled_clear();\n';
  code += '    char _hdr[18]; snprintf(_hdr, 18, "[ %d/%d ]", _ms + 1, _mc);\n';
  code += '    oled(1, _hdr, 1);\n';
  // คำนวณ window: เลื่อนให้ cursor อยู่บรรทัดที่ 2 ของ window เสมอ
  code += '    int _win = _ms - 1;\n';
  code += '    if (_win < 0) _win = 0;\n';
  code += '    if (_win + 4 > _mc) _win = _mc - 4;\n';
  code += '    if (_win < 0) _win = 0;\n';
  code += '    for (int _wi = 0; _wi < 4 && _win + _wi < _mc; _wi++) {\n';
  code += '      int _ii = _win + _wi;\n';
  code += '      char _row[18];\n';
  code += '      snprintf(_row, 18, "%c%.15s", _ii == _ms ? \'>\' : \' \', _mn[_ii]);\n';
  code += '      oled(_wi + 2, _row, 1);\n';
  code += '    }\n';
  code += '    oled_update();\n';
  code += '  };\n';

  // navigation loop — ปุ่ม pin 15 (กด = LOW) + debounce กันปุ่มเด้ง
  //  กดสั้น (ปล่อยก่อน 600ms) = เลือก & รัน
  //  กดค้าง (≥ 600ms ระหว่างที่ยังกดอยู่) = เลื่อนถัดไป (ตอบสนองทันทีที่ครบเวลา)
  code += '  pinMode(15, INPUT_PULLUP);\n';
  code += '  while (digitalRead(15) == LOW) delay(10);\n';  // drain ปุ่มที่ค้างตอนเข้าเมนู
  code += '  delay(50);\n';
  code += '  _mshow();\n';
  code += '  while (true) {\n';
  code += '    if (digitalRead(15) == LOW) {\n';
  code += '      delay(25);\n';                            // debounce ขอบกด กันเด้ง
  code += '      if (digitalRead(15) != LOW) { delay(20); continue; }\n';
  code += '      unsigned long _ts = millis();\n';
  code += '      bool _long = false;\n';
  code += '      while (digitalRead(15) == LOW) {\n';      // ยังกดค้างอยู่
  code += '        if (millis() - _ts >= 600) { _long = true; break; }\n';
  code += '        delay(5);\n';
  code += '      }\n';
  code += '      if (_long) {\n';                          // กดค้างครบ = ถัดไป
  code += '        _ms = (_ms + 1) % _mc;\n';
  code += '        _mshow();\n';
  code += '        while (digitalRead(15) == LOW) delay(10);\n';  // รอปล่อยปุ่ม
  code += '        delay(25);\n';
  code += '      } else {\n';                              // ปล่อยก่อนครบ = เลือก
  code += '        break;\n';
  code += '      }\n';
  code += '    }\n';
  code += '    delay(20);\n';
  code += '  }\n';

  // ยืนยันบน OLED แล้วรัน
  code += '  oled_clear();\n';
  code += '  oled(3, "STARTING...", 2);\n';
  code += '  oled_update(); delay(400);\n';

  for (let i = 0; i < count; i++) {
    if (i === 0)              code += '  if (_ms == 0) {\n' + dos[i];
    else if (i === count - 1) code += '  } else {\n' + dos[i];
    else                      code += '  } else if (_ms == ' + i + ') {\n' + dos[i];
  }
  code += '  }\n}\n';
  return code;
};

// ── Analog ──
Blockly.Arduino.forBlock['s2_analog'] = function(block) {
  return [`analogRead(${block.getFieldValue('PIN')})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ══════════════════════════════════════════════════════
//  Color Sensor (TCS34725) Generators
// ══════════════════════════════════════════════════════
Blockly.Arduino.forBlock['s2_color_begin'] = function(block) {
  const gain = block.getFieldValue('GAIN');
  return `tcs_begin(0xEB, ${gain});\n`;
};
Blockly.Arduino.forBlock['s2_color_calibrate'] = function(block) {
  const cnt = block.getFieldValue('CNT');
  return `tcs_calibrate(${cnt});\n`;
};
Blockly.Arduino.forBlock['s2_color_is'] = function(block) {
  const slot = block.getFieldValue('COLOR');
  return [`(tcs_readColor() == ${slot})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['s2_color_read'] = function(block) {
  return ['tcs_readColor()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['s2_color_name'] = function(block) {
  return ['tcs_colorName(tcs_readColor())', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['s2_color_value'] = function(block) {
  const fn = block.getFieldValue('KIND');
  return [`${fn}()`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['s2_color_reject'] = function(block) {
  const d = Blockly.Arduino.valueToCode(block, 'D', Blockly.Arduino.ORDER_ATOMIC) || '0.35';
  return `tcs_setReject(${d});\n`;
};

// ══════════════════════════════════════════════════════
//  Line Sensor + PID + Line+Gyro Generators
// ══════════════════════════════════════════════════════
Blockly.Arduino.forBlock['s2_line_calibrate'] = function(block) {
  const dur = Blockly.Arduino.valueToCode(block, 'DUR', Blockly.Arduino.ORDER_ATOMIC) || '5000';
  return `autoScanSensor(${dur});\n`;
};
Blockly.Arduino.forBlock['s2_line_load'] = function(block) {
  return `loadLineCal();\n`;
};
Blockly.Arduino.forBlock['s2_line_setup_front'] = function(block) {
  const type = block.getFieldValue('TYPE');
  const from = block.getFieldValue('FROM');
  const to   = block.getFieldValue('TO');
  return `setupLineFront(${from}, ${to}, ${type});\n`;
};
Blockly.Arduino.forBlock['s2_line_setup_back'] = function(block) {
  const type  = block.getFieldValue('TYPE');
  const from  = block.getFieldValue('FROM');
  const to    = block.getFieldValue('TO');
  const bflip = block.getFieldValue('BFLIP');
  return `setupLineBack(${from}, ${to}, ${type}, ${bflip});\n`;
};
Blockly.Arduino.forBlock['s2_line_pid_front'] = function(block) {
  const spd = Blockly.Arduino.valueToCode(block, 'SPEED', Blockly.Arduino.ORDER_ATOMIC) || '50';
  const kp  = Blockly.Arduino.valueToCode(block, 'KP', Blockly.Arduino.ORDER_ATOMIC) || '0.5';
  const kd  = Blockly.Arduino.valueToCode(block, 'KD', Blockly.Arduino.ORDER_ATOMIC) || '0.3';
  return `linePID_front(${spd}, ${kp}, ${kd});\n`;
};
Blockly.Arduino.forBlock['s2_line_pid_back'] = function(block) {
  const spd = Blockly.Arduino.valueToCode(block, 'SPEED', Blockly.Arduino.ORDER_ATOMIC) || '50';
  const kp  = Blockly.Arduino.valueToCode(block, 'KP', Blockly.Arduino.ORDER_ATOMIC) || '0.5';
  const kd  = Blockly.Arduino.valueToCode(block, 'KD', Blockly.Arduino.ORDER_ATOMIC) || '0.3';
  return `linePID_back(${spd}, ${kp}, ${kd});\n`;
};
Blockly.Arduino.forBlock['s2_line_move'] = function(block) {
  const dir      = block.getFieldValue('DIR');
  const yaw      = block.getFieldValue('YAW');
  const startspd = Blockly.Arduino.valueToCode(block, 'STARTSPD', Blockly.Arduino.ORDER_ATOMIC) || '30';
  const spd      = Blockly.Arduino.valueToCode(block, 'SPD', Blockly.Arduino.ORDER_ATOMIC) || '50';
  const time     = Blockly.Arduino.valueToCode(block, 'TIME', Blockly.Arduino.ORDER_ATOMIC) || '1000';
  const kpline   = Blockly.Arduino.valueToCode(block, 'KPLINE', Blockly.Arduino.ORDER_ATOMIC) || '0.8';
  const kdline   = Blockly.Arduino.valueToCode(block, 'KDLINE', Blockly.Arduino.ORDER_ATOMIC) || '0.5';
  const kpyaw    = Blockly.Arduino.valueToCode(block, 'KPYAW', Blockly.Arduino.ORDER_ATOMIC) || '0.6';
  const kdyaw    = Blockly.Arduino.valueToCode(block, 'KDYAW', Blockly.Arduino.ORDER_ATOMIC) || '0.1';
  const rampup   = Blockly.Arduino.valueToCode(block, 'RAMPUP', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const rampdown = Blockly.Arduino.valueToCode(block, 'RAMPDOWN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `LINE_MOVE(${dir}, ${yaw}, ${spd}, ${time}, ${kpline}, ${kdline}, ${kpyaw}, ${kdyaw}, ${rampup}, ${rampdown}, ${startspd});\n`;
};
Blockly.Arduino.forBlock['s2_line_move_num'] = function(block) {
  const dir      = block.getFieldValue('DIR');
  const yaw      = Blockly.Arduino.valueToCode(block, 'YAW', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const startspd = Blockly.Arduino.valueToCode(block, 'STARTSPD', Blockly.Arduino.ORDER_ATOMIC) || '30';
  const spd      = Blockly.Arduino.valueToCode(block, 'SPD', Blockly.Arduino.ORDER_ATOMIC) || '50';
  const time     = Blockly.Arduino.valueToCode(block, 'TIME', Blockly.Arduino.ORDER_ATOMIC) || '1000';
  const kpline   = Blockly.Arduino.valueToCode(block, 'KPLINE', Blockly.Arduino.ORDER_ATOMIC) || '0.8';
  const kdline   = Blockly.Arduino.valueToCode(block, 'KDLINE', Blockly.Arduino.ORDER_ATOMIC) || '0.5';
  const kpyaw    = Blockly.Arduino.valueToCode(block, 'KPYAW', Blockly.Arduino.ORDER_ATOMIC) || '0.6';
  const kdyaw    = Blockly.Arduino.valueToCode(block, 'KDYAW', Blockly.Arduino.ORDER_ATOMIC) || '0.1';
  const rampup   = Blockly.Arduino.valueToCode(block, 'RAMPUP', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const rampdown = Blockly.Arduino.valueToCode(block, 'RAMPDOWN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `LINE_MOVE(${dir}, ${yaw}, ${spd}, ${time}, ${kpline}, ${kdline}, ${kpyaw}, ${kdyaw}, ${rampup}, ${rampdown}, ${startspd});\n`;
};
Blockly.Arduino.forBlock['s2_line_move_enc'] = function(block) {
  const dir      = block.getFieldValue('DIR');
  const yaw      = block.getFieldValue('YAW');
  const startspd = Blockly.Arduino.valueToCode(block, 'STARTSPD', Blockly.Arduino.ORDER_ATOMIC) || '30';
  const spd      = Blockly.Arduino.valueToCode(block, 'SPD', Blockly.Arduino.ORDER_ATOMIC) || '50';
  const dist     = Blockly.Arduino.valueToCode(block, 'DIST', Blockly.Arduino.ORDER_ATOMIC) || '30';
  const kpline   = Blockly.Arduino.valueToCode(block, 'KPLINE', Blockly.Arduino.ORDER_ATOMIC) || '0.8';
  const kdline   = Blockly.Arduino.valueToCode(block, 'KDLINE', Blockly.Arduino.ORDER_ATOMIC) || '0.5';
  const kpyaw    = Blockly.Arduino.valueToCode(block, 'KPYAW', Blockly.Arduino.ORDER_ATOMIC) || '0.6';
  const kdyaw    = Blockly.Arduino.valueToCode(block, 'KDYAW', Blockly.Arduino.ORDER_ATOMIC) || '0.1';
  const rampup   = Blockly.Arduino.valueToCode(block, 'RAMPUP', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const rampdown = Blockly.Arduino.valueToCode(block, 'RAMPDOWN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `LINE_MOVE_ENC(${dir}, ${yaw}, ${spd}, ${dist}, ${kpline}, ${kdline}, ${kpyaw}, ${kdyaw}, ${rampup}, ${rampdown}, ${startspd});\n`;
};
Blockly.Arduino.forBlock['s2_line_count'] = function(block) {
  const from = block.getFieldValue('FROM');
  const to   = block.getFieldValue('TO');
  const type = block.getFieldValue('TYPE');
  return [`countSensors(${from}, ${to}, ${type})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['s2_line_on_line'] = function(block) {
  const ch   = block.getFieldValue('CH');
  const type = block.getFieldValue('TYPE');
  return [`sensorOnLine(${ch}, ${type})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['s2_line_get_ref'] = function(block) {
  const ch = block.getFieldValue('CH');
  return [`getRef(${ch})`, Blockly.Arduino.ORDER_ATOMIC];
};
