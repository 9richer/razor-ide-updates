// ============================================================
//  ESP32 Board Generator — Arduino C++ code
// ============================================================

// ── I/O ──
Blockly.Arduino.forBlock['esp32_digital_write'] = function(block) {
  const pin = block.getFieldValue('PIN');
  const val = block.getFieldValue('VAL');
  return `digitalWrite(${pin}, ${val});\n`;
};
Blockly.Arduino.forBlock['esp32_digital_read'] = function(block) {
  const pin = block.getFieldValue('PIN');
  return [`digitalRead(${pin})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_pin_mode'] = function(block) {
  const pin  = block.getFieldValue('PIN');
  const mode = block.getFieldValue('MODE');
  return `pinMode(${pin}, ${mode});\n`;
};
Blockly.Arduino.forBlock['esp32_analog_read'] = function(block) {
  const pin = block.getFieldValue('PIN');
  return [`analogRead(${pin})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_analog_write'] = function(block) {
  const pin = block.getFieldValue('PIN');
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `analogWrite(${pin}, ${val});\n`;
};

// ── Serial ──
Blockly.Arduino.forBlock['esp32_serial_begin'] = function(block) {
  return `Serial.begin(${block.getFieldValue('BAUD')});\n`;
};
Blockly.Arduino.forBlock['esp32_serial_print'] = function(block) {
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  const nl  = block.getFieldValue('NL') === 'TRUE';
  return nl ? `Serial.println(${val});\n` : `Serial.print(${val});\n`;
};
Blockly.Arduino.forBlock['esp32_serial_println'] = function(block) {
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  return `Serial.println(${val});\n`;
};
Blockly.Arduino.forBlock['esp32_serial_available'] = function(block) {
  return ['Serial.available()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_serial_read'] = function(block) {
  return ['Serial.read()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_serial_readstring'] = function(block) {
  return ['Serial.readString()', Blockly.Arduino.ORDER_ATOMIC];
};

// ── WiFi ──
Blockly.Arduino.forBlock['esp32_wifi_connect'] = function(block) {
  const ssid = block.getFieldValue('SSID');
  const pass = block.getFieldValue('PASS');
  return `WiFi.begin("${ssid}", "${pass}");\nwhile(WiFi.status() != WL_CONNECTED) { delay(500); }\n`;
};
Blockly.Arduino.forBlock['esp32_wifi_connected'] = function(block) {
  return ['(WiFi.status() == WL_CONNECTED)', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_wifi_ip'] = function(block) {
  return ['WiFi.localIP().toString()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_wifi_disconnect'] = function(block) {
  return 'WiFi.disconnect();\n';
};

// ── LED ──
Blockly.Arduino.forBlock['esp32_builtin_led'] = function(block) {
  const val = block.getFieldValue('VAL');
  return `digitalWrite(2, ${val});\n`;
};
Blockly.Arduino.forBlock['esp32_ledc_setup'] = function(block) {
  const ch   = block.getFieldValue('CH');
  const freq = block.getFieldValue('FREQ');
  const res  = block.getFieldValue('RES');
  return `ledcSetup(${ch}, ${freq}, ${res});\n`;
};
Blockly.Arduino.forBlock['esp32_ledc_attach'] = function(block) {
  const pin = block.getFieldValue('PIN');
  const ch  = block.getFieldValue('CH');
  return `ledcAttachPin(${pin}, ${ch});\n`;
};
Blockly.Arduino.forBlock['esp32_ledc_write'] = function(block) {
  const ch   = block.getFieldValue('CH');
  const duty = Blockly.Arduino.valueToCode(block, 'DUTY', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `ledcWrite(${ch}, ${duty});\n`;
};

// ── Touch ──
Blockly.Arduino.forBlock['esp32_touch_read'] = function(block) {
  const pin = block.getFieldValue('PIN');
  return [`touchRead(${pin})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ── Timer ──
Blockly.Arduino.forBlock['esp32_delay_ms'] = function(block) {
  const t = Blockly.Arduino.valueToCode(block, 'TIME', Blockly.Arduino.ORDER_ATOMIC) || '1000';
  return `delay(${t});\n`;
};
Blockly.Arduino.forBlock['esp32_millis'] = function(block) {
  return ['millis()', Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_micros'] = function(block) {
  return ['micros()', Blockly.Arduino.ORDER_ATOMIC];
};

// ── Math ──
Blockly.Arduino.forBlock['esp32_map'] = function(block) {
  const val    = Blockly.Arduino.valueToCode(block, 'VAL',     Blockly.Arduino.ORDER_ATOMIC) || '0';
  const inMin  = Blockly.Arduino.valueToCode(block, 'IN_MIN',  Blockly.Arduino.ORDER_ATOMIC) || '0';
  const inMax  = Blockly.Arduino.valueToCode(block, 'IN_MAX',  Blockly.Arduino.ORDER_ATOMIC) || '1023';
  const outMin = Blockly.Arduino.valueToCode(block, 'OUT_MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const outMax = Blockly.Arduino.valueToCode(block, 'OUT_MAX', Blockly.Arduino.ORDER_ATOMIC) || '255';
  return [`map(${val}, ${inMin}, ${inMax}, ${outMin}, ${outMax})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_constrain'] = function(block) {
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mn  = Blockly.Arduino.valueToCode(block, 'MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mx  = Blockly.Arduino.valueToCode(block, 'MAX', Blockly.Arduino.ORDER_ATOMIC) || '255';
  return [`constrain(${val}, ${mn}, ${mx})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['esp32_random'] = function(block) {
  const mn = Blockly.Arduino.valueToCode(block, 'MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mx = Blockly.Arduino.valueToCode(block, 'MAX', Blockly.Arduino.ORDER_ATOMIC) || '100';
  return [`random(${mn}, ${mx})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ── System ──
Blockly.Arduino.forBlock['esp32_restart'] = function(block) {
  return 'ESP.restart();\n';
};
Blockly.Arduino.forBlock['esp32_free_heap'] = function(block) {
  return ['ESP.getFreeHeap()', Blockly.Arduino.ORDER_ATOMIC];
};

// ── Sonar (RAZOR-S2 / HC-SR04) ──
Blockly.Arduino.forBlock['s2_sonar'] = function(block) {
  const trig = block.getFieldValue('TRIG');
  const echo = block.getFieldValue('ECHO');
  return [`s2Sonar(${trig}, ${echo})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ── OLED (RAZOR-S2 / S2_oled.h) ──
Blockly.Arduino.forBlock['s2_oled_clear'] = function() {
  return 'oled_clear();\n';
};
Blockly.Arduino.forBlock['s2_oled_update'] = function() {
  return 'oled_update();\n';
};
Blockly.Arduino.forBlock['s2_oled_print'] = function(block) {
  const line = block.getFieldValue('LINE');
  const sz   = block.getFieldValue('SZ');
  const val  = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  return `oled(${line}, ${val}, ${sz});\n`;
};
Blockly.Arduino.forBlock['s2_oled_label'] = function(block) {
  const line  = block.getFieldValue('LINE');
  const sz    = block.getFieldValue('SZ');
  const label = Blockly.Arduino.valueToCode(block, 'LABEL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  const val   = Blockly.Arduino.valueToCode(block, 'VAL',   Blockly.Arduino.ORDER_ATOMIC) || '""';
  return `oled(${line}, String(${label}), ${val}, ${sz});\n`;
};
Blockly.Arduino.forBlock['s2_oled_xy'] = function(block) {
  const x   = Blockly.Arduino.valueToCode(block, 'X',   Blockly.Arduino.ORDER_ATOMIC) || '0';
  const y   = Blockly.Arduino.valueToCode(block, 'Y',   Blockly.Arduino.ORDER_ATOMIC) || '0';
  const sz  = block.getFieldValue('SZ');
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  return `oled_xy(${x}, ${y}, ${val}, ${sz});\n`;
};
Blockly.Arduino.forBlock['s2_oled_line'] = function(block) {
  const x1 = Blockly.Arduino.valueToCode(block, 'X1', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const y1 = Blockly.Arduino.valueToCode(block, 'Y1', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const x2 = Blockly.Arduino.valueToCode(block, 'X2', Blockly.Arduino.ORDER_ATOMIC) || '127';
  const y2 = Blockly.Arduino.valueToCode(block, 'Y2', Blockly.Arduino.ORDER_ATOMIC) || '31';
  return `oled_line(${x1}, ${y1}, ${x2}, ${y2});\n`;
};
Blockly.Arduino.forBlock['s2_oled_rect'] = function(block) {
  const x    = Blockly.Arduino.valueToCode(block, 'X', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const y    = Blockly.Arduino.valueToCode(block, 'Y', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const w    = Blockly.Arduino.valueToCode(block, 'W', Blockly.Arduino.ORDER_ATOMIC) || '50';
  const h    = Blockly.Arduino.valueToCode(block, 'H', Blockly.Arduino.ORDER_ATOMIC) || '20';
  const fill = block.getFieldValue('FILL');
  return fill === '1'
    ? `oled_fill_rect(${x}, ${y}, ${w}, ${h});\n`
    : `oled_rect(${x}, ${y}, ${w}, ${h});\n`;
};
Blockly.Arduino.forBlock['s2_oled_progress'] = function(block) {
  const x   = Blockly.Arduino.valueToCode(block, 'X',   Blockly.Arduino.ORDER_ATOMIC) || '0';
  const y   = Blockly.Arduino.valueToCode(block, 'Y',   Blockly.Arduino.ORDER_ATOMIC) || '20';
  const w   = Blockly.Arduino.valueToCode(block, 'W',   Blockly.Arduino.ORDER_ATOMIC) || '100';
  const h   = Blockly.Arduino.valueToCode(block, 'H',   Blockly.Arduino.ORDER_ATOMIC) || '8';
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `oled_progress(${x}, ${y}, ${w}, ${h}, ${val});\n`;
};
Blockly.Arduino.forBlock['s2_oled_invert'] = function(block) {
  const inv = block.getFieldValue('INV');
  return `oled_invert(${inv === '1' ? 'true' : 'false'});\n`;
};

// ── Servo (RAZOR-S2 / LEDC) ──
Blockly.Arduino.forBlock['s2_servo'] = function(block) {
  const pin   = block.getFieldValue('PIN');
  const angle = Blockly.Arduino.valueToCode(block, 'ANGLE', Blockly.Arduino.ORDER_ATOMIC) || '90';
  const spd   = Blockly.Arduino.valueToCode(block, 'SPEED', Blockly.Arduino.ORDER_ATOMIC) || '10';
  return `s2ServoMove(${pin}, ${angle}, ${spd});\n`;
};
Blockly.Arduino.forBlock['s2_servo_fast'] = function(block) {
  const pin   = block.getFieldValue('PIN');
  const angle = Blockly.Arduino.valueToCode(block, 'ANGLE', Blockly.Arduino.ORDER_ATOMIC) || '90';
  return `s2ServoWrite(${pin}, ${angle});\n`;
};

// ── Motor (RAZOR-S2 / S2_motor.h) — ใช้ offset ──
Blockly.Arduino.forBlock['s2_motor_l'] = function(block) {
  const spd = Blockly.Arduino.valueToCode(block, 'SPEED', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `motorL(constrain((${spd}) + _s2MotorOffL, -100, 100));\n`;
};
Blockly.Arduino.forBlock['s2_motor_r'] = function(block) {
  const spd = Blockly.Arduino.valueToCode(block, 'SPEED', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `motorR(constrain((${spd}) + _s2MotorOffR, -100, 100));\n`;
};
Blockly.Arduino.forBlock['s2_motor_offset'] = function(block) {
  const l = Blockly.Arduino.valueToCode(block, 'LEFT',  Blockly.Arduino.ORDER_ATOMIC) || '0';
  const r = Blockly.Arduino.valueToCode(block, 'RIGHT', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `_s2MotorOffL = ${l}; _s2MotorOffR = ${r};\n`;
};
Blockly.Arduino.forBlock['s2_motor_stop'] = function(block) {
  return 'motorL(0); motorR(0);\n';
};

// forever — while(true)
Blockly.Arduino.forBlock['forever'] = function(block) {
  const body = Blockly.Arduino.statementToCode(block, 'DO');
  return 'while (true) {\n' + body + '}\n';
};
