// ============================================================
//  ESP32 Board Blocks — มาตรฐาน Arduino ESP32
//  ครอบคลุม: Digital I/O, Analog, PWM, Serial, WiFi, 
//             LED PWM (LEDC), Touch, Timer, I2C, SPI
// ============================================================

// ══════════════════════════════════════════════════════
//  I/O — Digital / Analog / PWM
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_digital_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalWrite pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('=')
        .appendField(new Blockly.FieldDropdown([['HIGH','HIGH'],['LOW','LOW']]), 'VAL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('ตั้งค่า digital output');
  }
};

Blockly.Blocks['esp32_digital_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalRead pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e'); this.setTooltip('อ่านค่า digital input (0/1)');
  }
};

Blockly.Blocks['esp32_pin_mode'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('pinMode pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('เป็น')
        .appendField(new Blockly.FieldDropdown([
          ['OUTPUT','OUTPUT'],['INPUT','INPUT'],
          ['INPUT_PULLUP','INPUT_PULLUP'],['INPUT_PULLDOWN','INPUT_PULLDOWN']
        ]), 'MODE');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('ตั้งค่าโหมดของ pin');
  }
};

Blockly.Blocks['esp32_analog_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogRead pin')
        .appendField(new Blockly.FieldDropdown([
          ['34','34'],['35','35'],['36','36'],['39','39'],
          ['32','32'],['33','33'],['25','25'],['26','26'],['27','27']
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e'); this.setTooltip('อ่าน ADC 0-4095 (12-bit)');
  }
};

Blockly.Blocks['esp32_analog_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogWrite pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('ค่า');
    this.appendValueInput('VAL').setCheck('Number');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('PWM 0-255');
  }
};

// ══════════════════════════════════════════════════════
//  Serial
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_serial_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Serial.begin')
        .appendField(new Blockly.FieldDropdown([
          ['115200','115200'],['9600','9600'],['57600','57600'],['230400','230400']
        ]), 'BAUD');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('เริ่ม Serial communication');
  }
};

Blockly.Blocks['esp32_serial_print'] = {
  init: function() {
    this.appendValueInput('VAL')
        .appendField('Serial.print');
    this.appendDummyInput()
        .appendField(new Blockly.FieldCheckbox('TRUE'), 'NL')
        .appendField('newline');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('พิมพ์ข้อความออก Serial');
  }
};

Blockly.Blocks['esp32_serial_println'] = {
  init: function() {
    this.appendValueInput('VAL')
        .appendField('Serial.println');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('พิมพ์ข้อความพร้อม newline');
  }
};

Blockly.Blocks['esp32_serial_available'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.available()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b'); this.setTooltip('จำนวน bytes ที่รอใน buffer');
  }
};

Blockly.Blocks['esp32_serial_read'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.read()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b'); this.setTooltip('อ่าน 1 byte จาก Serial');
  }
};

Blockly.Blocks['esp32_serial_readstring'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.readString()');
    this.setOutput(true, 'String');
    this.setColour('#c0392b'); this.setTooltip('อ่าน String จาก Serial');
  }
};

// ══════════════════════════════════════════════════════
//  WiFi
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_wifi_connect'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('WiFi เชื่อมต่อ SSID')
        .appendField(new Blockly.FieldTextInput('MyWiFi'), 'SSID');
    this.appendDummyInput()
        .appendField('Password')
        .appendField(new Blockly.FieldTextInput('password'), 'PASS');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2'); this.setTooltip('เชื่อมต่อ WiFi');
  }
};

Blockly.Blocks['esp32_wifi_connected'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi เชื่อมต่ออยู่?');
    this.setOutput(true, 'Boolean');
    this.setColour('#0891b2'); this.setTooltip('true ถ้า WiFi connected');
  }
};

Blockly.Blocks['esp32_wifi_ip'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi IP Address');
    this.setOutput(true, 'String');
    this.setColour('#0891b2'); this.setTooltip('คืน IP address เป็น String');
  }
};

Blockly.Blocks['esp32_wifi_disconnect'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi ตัดการเชื่อมต่อ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2'); this.setTooltip('ตัด WiFi');
  }
};

// ══════════════════════════════════════════════════════
//  LED (Onboard + LEDC PWM)
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_builtin_led'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LED บนบอร์ด')
        .appendField(new Blockly.FieldDropdown([['เปิด','HIGH'],['ปิด','LOW']]), 'VAL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('LED pin 2 บน ESP32');
  }
};

Blockly.Blocks['esp32_ledc_setup'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC setup channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH')
        .appendField('freq')
        .appendField(new Blockly.FieldNumber(5000), 'FREQ')
        .appendField('Hz resolution')
        .appendField(new Blockly.FieldNumber(8, 1, 16), 'RES')
        .appendField('bit');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('ตั้งค่า LEDC PWM channel');
  }
};

Blockly.Blocks['esp32_ledc_attach'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC attach pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
  }
};

Blockly.Blocks['esp32_ledc_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC write channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH')
        .appendField('duty');
    this.appendValueInput('DUTY').setCheck('Number');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('ตั้ง duty cycle 0-255');
  }
};

// ══════════════════════════════════════════════════════
//  Touch Sensor (ESP32 built-in)
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_touch_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('touchRead pin')
        .appendField(new Blockly.FieldDropdown([
          ['T0 (GPIO4)','4'],['T1 (GPIO0)','0'],['T2 (GPIO2)','2'],
          ['T3 (GPIO15)','15'],['T4 (GPIO13)','13'],['T5 (GPIO12)','12'],
          ['T6 (GPIO14)','14'],['T7 (GPIO27)','27'],['T8 (GPIO33)','33'],['T9 (GPIO32)','32']
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#8b5cf6'); this.setTooltip('อ่านค่า capacitive touch (ยิ่งต่ำยิ่งถูกแตะ)');
  }
};

// ══════════════════════════════════════════════════════
//  Timer / Delay
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_delay_ms'] = {
  init: function() {
    this.appendValueInput('TIME')
        .appendField('รอ (ms)');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8'); this.setTooltip('หน่วงเวลา millisecond');
  }
};

Blockly.Blocks['esp32_millis'] = {
  init: function() {
    this.appendDummyInput().appendField('millis()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8'); this.setTooltip('เวลาที่ผ่านไปตั้งแต่เปิดบอร์ด (ms)');
  }
};

Blockly.Blocks['esp32_micros'] = {
  init: function() {
    this.appendDummyInput().appendField('micros()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8'); this.setTooltip('เวลาที่ผ่านไปตั้งแต่เปิดบอร์ด (µs)');
  }
};

// ══════════════════════════════════════════════════════
//  Math / Utility
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_map'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('map');
    this.appendValueInput('IN_MIN').appendField('จาก');
    this.appendValueInput('IN_MAX').appendField('ถึง');
    this.appendValueInput('OUT_MIN').appendField('→');
    this.appendValueInput('OUT_MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('แปลงช่วงค่า');
  }
};

Blockly.Blocks['esp32_constrain'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('constrain');
    this.appendValueInput('MIN').appendField('min');
    this.appendValueInput('MAX').appendField('max');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('จำกัดค่าอยู่ในช่วง min-max');
  }
};

Blockly.Blocks['esp32_random'] = {
  init: function() {
    this.appendValueInput('MIN').appendField('random จาก');
    this.appendValueInput('MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('สุ่มตัวเลข');
  }
};

// ══════════════════════════════════════════════════════
//  ESP32 System
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_restart'] = {
  init: function() {
    this.appendDummyInput().appendField('ESP.restart()');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#dc2626'); this.setTooltip('รีสตาร์ท ESP32');
  }
};

Blockly.Blocks['esp32_free_heap'] = {
  init: function() {
    this.appendDummyInput().appendField('ESP.getFreeHeap()');
    this.setOutput(true, 'Number');
    this.setColour('#dc2626'); this.setTooltip('RAM ที่เหลือ (bytes)');
  }
};

// ══════════════════════════════════════════════════════
//  OLED 128×32 / 128×64 — RAZOR-S2  (S2_oled.h)
//  I2C SDA=21  SCL=23  addr=0x3C
//  line 1–4 (size=1)  หรือ  1–2 (size=2)  [จอ 64 ได้ 1–8 / 1–4]
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_oled_size'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('OLED ขนาดจอ')
        .appendField(new Blockly.FieldDropdown([
          ['128 x 32', '32'],
          ['128 x 64', '64']
        ]), 'H');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('เลือกขนาดจอ OLED — วางบนสุดของ Setup\nค่าเริ่มต้นถ้าไม่ใส่ = 128x32\nGenerate: oled_setSize(h);');
  }
};

Blockly.Blocks['s2_oled_clear'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED ล้างหน้าจอ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('ล้างหน้าจอ OLED (ยังไม่แสดงผลจนกว่าจะ update)');
  }
};

Blockly.Blocks['s2_oled_update'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED แสดงผล');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('ส่งข้อมูลไปแสดงบนหน้าจอ OLED');
  }
};

Blockly.Blocks['s2_oled_print'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED แถว')
        .appendField(new Blockly.FieldDropdown([
          ['1','1'],['2','2'],['3','3'],['4','4']
        ]), 'LINE');
    this.appendValueInput('VAL').appendField('ค่า');
    this.appendDummyInput()
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2']]), 'SZ');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('แสดงข้อความที่แถวที่ระบุ (1–4)\nsize 2 = ตัวใหญ่ขึ้น 2 เท่า');
  }
};

Blockly.Blocks['s2_oled_label'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED แถว')
        .appendField(new Blockly.FieldDropdown([
          ['1','1'],['2','2'],['3','3'],['4','4']
        ]), 'LINE');
    this.appendValueInput('LABEL').appendField('หัวข้อ');
    this.appendValueInput('VAL').appendField('ค่า');
    this.appendDummyInput()
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2']]), 'SZ');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('แสดง "หัวข้อ: ค่า" บนแถวที่ระบุ');
  }
};

Blockly.Blocks['s2_oled_xy'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED ที่ x');
    this.appendValueInput('X');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y');
    this.appendValueInput('VAL').appendField('ค่า');
    this.appendDummyInput()
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2']]), 'SZ');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('แสดงข้อความที่ตำแหน่ง pixel x,y\nx: 0–127  y: 0–31');
  }
};

Blockly.Blocks['s2_oled_line'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED เส้น x1');
    this.appendValueInput('X1');
    this.appendDummyInput().appendField('y1');
    this.appendValueInput('Y1');
    this.appendDummyInput().appendField('→ x2');
    this.appendValueInput('X2');
    this.appendDummyInput().appendField('y2');
    this.appendValueInput('Y2');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('วาดเส้นตรงจาก (x1,y1) ถึง (x2,y2)');
  }
};

Blockly.Blocks['s2_oled_rect'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED กรอบ x');
    this.appendValueInput('X');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y');
    this.appendDummyInput().appendField('w');
    this.appendValueInput('W');
    this.appendDummyInput().appendField('h');
    this.appendValueInput('H');
    this.appendDummyInput()
        .appendField(new Blockly.FieldDropdown([['กรอบ','0'],['ทึบ','1']]), 'FILL');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('วาดสี่เหลี่ยม (กรอบ หรือ ทึบ)');
  }
};

Blockly.Blocks['s2_oled_progress'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED Progress x');
    this.appendValueInput('X');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y');
    this.appendDummyInput().appendField('w');
    this.appendValueInput('W');
    this.appendDummyInput().appendField('h');
    this.appendValueInput('H');
    this.appendValueInput('VAL').appendField('ค่า');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('แสดง progress bar 0–100%');
  }
};

Blockly.Blocks['s2_sonar'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📡 Sonar trig')
        .appendField(new Blockly.FieldDropdown([
          ['A8 (13)','13'],['A9 (14)','14'],
          ['A6 (27)','27'],['A7 (26)','26'],
          ['A4 (25)','25'],['A5 (33)','33'],
          ['A2 (32)','32']
        ]), 'TRIG')
        .appendField('echo')
        .appendField(new Blockly.FieldDropdown([
          ['A9 (14)','14'],['A8 (13)','13'],
          ['A7 (26)','26'],['A6 (27)','27'],
          ['A5 (33)','33'],['A4 (25)','25'],
          ['A0 (39)','39'],['A1 (34)','34'],['A3 (35)','35']
        ]), 'ECHO');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('วัดระยะ HC-SR04 (cm)\nคืน -1 ถ้าเกินระยะ 4m หรือไม่เจอวัตถุ');
  }
};

Blockly.Blocks['s2_oled_invert'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED กลับสี')
        .appendField(new Blockly.FieldDropdown([['เปิด','1'],['ปิด','0']]), 'INV');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('กลับสีหน้าจอ (ขาวเป็นดำ / ดำเป็นขาว)');
  }
};

// ══════════════════════════════════════════════════════
//  Servo Control — RAZOR-S2  (LEDC, ไม่ต้องใช้ library ภายนอก)
//  ใช้ LEDC channel 8–11 สำรองไว้สำหรับ servo 4 ตัว
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_servo'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎯 Servo pin')
        .appendField(new Blockly.FieldDropdown([
          ['18','18'],['19','19'],['23','23'],['5','5'],
          ['25','25'],['26','26'],['27','27'],['32','32'],['33','33']
        ]), 'PIN');
    this.appendValueInput('ANGLE').appendField('มุม');
    this.appendValueInput('SPEED').appendField('speed');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('หมุน Servo ไปมุมที่กำหนด (0–180°) แบบค่อยๆหมุน\nspeed = ms ต่อ 1° (น้อย=เร็ว)');
  }
};

Blockly.Blocks['s2_servo_fast'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚡ ServoFast pin')
        .appendField(new Blockly.FieldDropdown([
          ['18','18'],['19','19'],['23','23'],['5','5'],
          ['25','25'],['26','26'],['27','27'],['32','32'],['33','33']
        ]), 'PIN');
    this.appendValueInput('ANGLE').appendField('มุม');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('หมุน Servo ไปมุมทันที ไม่มีการค่อยๆหมุน');
  }
};

// ══════════════════════════════════════════════════════
//  Motor Control — RAZOR-S2  (S2_motor.h)
//  ซ้าย: pin2(ถอย) + pin4(หน้า)   ขวา: pin16(ถอย) + pin17(หน้า)
//  ความเร็ว: -100 (ถอย) ~ 0 (หยุด) ~ +100 (ไปหน้า)
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_motor_offset'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚙️ Motor Offset ซ้าย');
    this.appendValueInput('LEFT');
    this.appendDummyInput().appendField('ขวา');
    this.appendValueInput('RIGHT');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('ปรับชดเชยมอเตอร์ให้หุ่นยนต์วิ่งตรง\nใส่ใน setup | ช่วง −20 ถึง 20');
  }
};

// ── ควบคุมมอเตอร์ (FORWARD/BACKWARD L+R, motorL/R, หยุด) ──
Blockly.Blocks['s2_forward'] = {
  init: function() {
    this.appendDummyInput().appendField('FORWARD  L');
    this.appendValueInput('SPDL').setCheck('Number');
    this.appendDummyInput().appendField('R');
    this.appendValueInput('SPDR').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('เดินหน้า ตั้งความเร็วซ้าย/ขวาแยกกัน (0-100) — ชดเชย offset ให้วิ่งตรง');
  }
};

Blockly.Blocks['s2_backward'] = {
  init: function() {
    this.appendDummyInput().appendField('BACKWARD  L');
    this.appendValueInput('SPDL').setCheck('Number');
    this.appendDummyInput().appendField('R');
    this.appendValueInput('SPDR').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('ถอยหลัง ตั้งความเร็วซ้าย/ขวาแยกกัน (0-100)');
  }
};

Blockly.Blocks['s2_motorL'] = {
  init: function() {
    this.appendValueInput('SPD').setCheck('Number').appendField('motorL speed');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('ความเร็วมอเตอร์ซ้าย −100 ถึง 100 (บวก=หน้า ลบ=ถอย)');
  }
};

Blockly.Blocks['s2_motorR'] = {
  init: function() {
    this.appendValueInput('SPD').setCheck('Number').appendField('motorR speed');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('ความเร็วมอเตอร์ขวา −100 ถึง 100 (บวก=หน้า ลบ=ถอย)');
  }
};

Blockly.Blocks['s2_stop'] = {
  init: function() {
    this.appendDummyInput().appendField('หยุด');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('หยุดมอเตอร์ทั้งสองล้อ');
  }
};

// forever — while(true)
// แต่ละ board กำหนด style เองได้อิสระ (สี, tooltip, format)
Blockly.Blocks['forever'] = {
  init: function() {
    this.appendStatementInput('DO').appendField('🔁 Forever');
    this.setPreviousStatement(true);
    this.setNextStatement(false);
    this.setColour('#e63946');
    this.setTooltip('while(true) — วนซ้ำตลอดไป');
  }
};

// ══════════════════════════════════════════════════════════════
//  IMU (MPU6050) — RAZOR-S2
//  ทุก block ชื่อเหมือน RAZOR-S3 → โค้ดใช้แทนกันได้เลย
// ══════════════════════════════════════════════════════════════

// _S2_SONAR_PINS — inline ใน init() ของแต่ละ block (ห้าม declare ระดับ module เพราะ load ซ้ำได้)

Blockly.Blocks['imu_select'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🧭 เลือก IMU')
        .appendField(new Blockly.FieldDropdown([
          ['MPU6050',          'IMU_MPU6050'],
          ['GY-91 (MPU9250)',  'IMU_GY91'],
          ['BNO055',           'IMU_BNO055'],
          ['BNO055 + เข็มทิศ', 'IMU_BNO055_MAG'],
          ['BNO085',           'IMU_BNO085'],
          ['BNO085 + เข็มทิศ', 'IMU_BNO085_MAG'],
          ['ICM-20948',        'IMU_ICM20948']
        ]), 'IMU');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('เลือก IMU ที่จะใช้ — วางไว้บนสุดของ Setup ก่อน "IMU คาริเบต"\nถ้าไม่ใส่ = ใช้ MPU6050 (ค่าเริ่มต้น)\nGenerate: setIMU(IMU_xxx);');
  }
};

Blockly.Blocks['imu_calibrate'] = {
  init: function() {
    this.appendDummyInput().appendField('🔧 IMU คาริเบตทิศครั้งแรก');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('เริ่ม MPU6050 + ตั้งทิศหน้า=0°\nใส่ใน Setup\nGenerate: initIMU(); calibrateYawStart();');
  }
};

Blockly.Blocks['imu_reset_yaw'] = {
  init: function() {
    this.appendDummyInput().appendField('🔄 รีเซตทิศ  จำนวนรอบ');
    this.appendValueInput('SAMPLES').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('รีเซตทิศปัจจุบัน=0°\nรอบ=1→เร็ว  รอบ=10→แม่น\nGenerate: resetYaw(samples);');
  }
};

Blockly.Blocks['imu_get_yaw'] = {
  init: function() {
    this.appendDummyInput().appendField('🧭 มุมปัจจุบัน');
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed');
    this.setTooltip('อ่านมุม yaw 0–360°\nGenerate: getYaw()');
  }
};

Blockly.Blocks['imu_get_yaw_raw'] = {
  init: function() {
    this.appendDummyInput().appendField('🧭 มุมดิบ (raw)');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('อ่านมุม yaw ดิบ ไม่มี offset\nGenerate: getYawRaw()');
  }
};

// ── spinTo config ─────────────────────────────────────────────
Blockly.Blocks['imu_spin_config'] = {
  init: function() {
    this.appendDummyInput().appendField('⚙️ ตั้งค่า spinTo  kp_fast');
    this.appendValueInput('KP_FAST').setCheck('Number');
    this.appendDummyInput().appendField('kp_mid');
    this.appendValueInput('KP_MID').setCheck('Number');
    this.appendDummyInput().appendField('kp_slow');
    this.appendValueInput('KP_SLOW').setCheck('Number');
    this.appendDummyInput().appendField('kd');
    this.appendValueInput('KD').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('ตั้งค่า spinTo ใน Setup\nGenerate: setSpinConfig(...);');
  }
};

// ── spinTo (dropdown ลูกศร) ───────────────────────────────────
Blockly.Blocks['imu_spin_to_dir'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎯 spinTo  ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('error');
    this.appendValueInput('ERR').setCheck('Number');
    this.appendDummyInput().appendField('timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms  min');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('max');
    this.appendValueInput('SMAX').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('เลี้ยวแม่นสุด (PD + Adaptive kp)\nGenerate: spinTo(yaw, error, timeout, min, max);');
  }
};

// ── spinTo (พิมพ์องศาเอง) ─────────────────────────────────────
Blockly.Blocks['imu_spin_to_num'] = {
  init: function() {
    this.appendDummyInput().appendField('🎯 spinTo  ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('error');
    this.appendValueInput('ERR').setCheck('Number');
    this.appendDummyInput().appendField('timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms  min');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('max');
    this.appendValueInput('SMAX').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('เลี้ยวแม่นสุด — พิมพ์องศาเอง\nGenerate: spinTo(yaw, error, timeout, min, max);');
  }
};

// ── TurnF/B_PID ──────────────────────────────────────────────
Blockly.Blocks['imu_turnF_pid'] = {
  init: function() {
    this.appendDummyInput().appendField('↩ TurnF_PID  ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('min');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('max');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('kp');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('kd');
    this.appendValueInput('KD').setCheck('Number');
    this.appendDummyInput().appendField('error');
    this.appendValueInput('ERR').setCheck('Number');
    this.appendDummyInput().appendField('timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('ดิฟหน้า PID — ล้อซ้ายดัน ล้อขวาแตะ\nGenerate: TurnF_PID(yaw, min, max, kp, kd, error, timeout);');
  }
};

Blockly.Blocks['imu_turnB_pid'] = {
  init: function() {
    this.appendDummyInput().appendField('↪ TurnB_PID  ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('min');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('max');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('kp');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('kd');
    this.appendValueInput('KD').setCheck('Number');
    this.appendDummyInput().appendField('error');
    this.appendValueInput('ERR').setCheck('Number');
    this.appendDummyInput().appendField('timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('ดิฟหลัง PID — ล้อซ้ายถอย ล้อขวาแตะ\nGenerate: TurnB_PID(yaw, min, max, kp, kd, error, timeout);');
  }
};

Blockly.Blocks['imu_turnF_pid_dir'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('↩ TurnF_PID  ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('min');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('max');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('kp');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('kd');
    this.appendValueInput('KD').setCheck('Number');
    this.appendDummyInput().appendField('error');
    this.appendValueInput('ERR').setCheck('Number');
    this.appendDummyInput().appendField('timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('ดิฟหน้า PID — เลือกทิศด้วยลูกศร\nGenerate: TurnF_PID(yaw, min, max, kp, kd, error, timeout);');
  }
};

Blockly.Blocks['imu_turnB_pid_dir'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('↪ TurnB_PID  ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('min');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('max');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('kp');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('kd');
    this.appendValueInput('KD').setCheck('Number');
    this.appendDummyInput().appendField('error');
    this.appendValueInput('ERR').setCheck('Number');
    this.appendDummyInput().appendField('timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('ดิฟหลัง PID — เลือกทิศด้วยลูกศร\nGenerate: TurnB_PID(yaw, min, max, kp, kd, error, timeout);');
  }
};

// ── หมุน smooth (spinTo_F/B) ──────────────────────────────────
Blockly.Blocks['imu_spin_dir'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔄 หมุน')
        .appendField(new Blockly.FieldDropdown([['หน้า','F'],['หลัง','B']]), 'DIR')
        .appendField('  ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('เร็วสุด');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('ช้าสุด');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('หยุดที่');
    this.appendValueInput('THR').setCheck('Number');
    this.appendDummyInput().appendField('°  timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('หมุนในที่ ไม่มี PID\nGenerate: spinTo_F / spinTo_B(yaw, max, min, thr, timeout);');
  }
};

Blockly.Blocks['imu_spin_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔄 หมุน')
        .appendField(new Blockly.FieldDropdown([['หน้า','F'],['หลัง','B']]), 'DIR')
        .appendField('  ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('เร็วสุด');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('ช้าสุด');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('หยุดที่');
    this.appendValueInput('THR').setCheck('Number');
    this.appendDummyInput().appendField('°  timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0e7490');
    this.setTooltip('หมุนในที่ ไม่มี PID — พิมพ์องศาเอง\nGenerate: spinTo_F / spinTo_B(yaw, max, min, thr, timeout);');
  }
};

// ── ดิฟ smooth (TurnF_S/TurnB_S) ─────────────────────────────
Blockly.Blocks['imu_turns_dir'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('↩↪ ดิฟ')
        .appendField(new Blockly.FieldDropdown([['หน้า','F'],['หลัง','B']]), 'DIR')
        .appendField('  ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('เร็วสุด');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('ช้าสุด');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('หยุดที่');
    this.appendValueInput('THR').setCheck('Number');
    this.appendDummyInput().appendField('°  timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0d9488');
    this.setTooltip('ดิฟ ไม่มี PID\nGenerate: TurnF_S / TurnB_S(yaw, max, min, thr, timeout);');
  }
};

Blockly.Blocks['imu_turns_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('↩↪ ดิฟ')
        .appendField(new Blockly.FieldDropdown([['หน้า','F'],['หลัง','B']]), 'DIR')
        .appendField('  ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('เร็วสุด');
    this.appendValueInput('SMAX').setCheck('Number');
    this.appendDummyInput().appendField('ช้าสุด');
    this.appendValueInput('SMIN').setCheck('Number');
    this.appendDummyInput().appendField('หยุดที่');
    this.appendValueInput('THR').setCheck('Number');
    this.appendDummyInput().appendField('°  timeout');
    this.appendValueInput('TIMEOUT').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e');
    this.setTooltip('ดิฟ ไม่มี PID — พิมพ์องศาเอง\nGenerate: TurnF_S / TurnB_S(yaw, max, min, thr, timeout);');
  }
};

// ── MOVE ─────────────────────────────────────────────────────
Blockly.Blocks['imu_move'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🚀 MOVE')
        .appendField(new Blockly.FieldDropdown([['เดินหน้า','0'],['ถอยหลัง','1']]), 'DIR')
        .appendField('ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('KI');
    this.appendValueInput('KI').setCheck('Number');
    this.appendDummyInput().appendField('KD');
    this.appendValueInput('KD').setCheck('Number');
    this.appendDummyInput().appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#d97706');
    this.setTooltip('เดินหน้า/ถอยหลัง PID ยึดทิศ\nGenerate: MOVE(dir, yaw, speed, time, kp, ki, kd, rampUp, rampDown, startSpeed);');
  }
};

Blockly.Blocks['imu_move_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🚀 MOVE')
        .appendField(new Blockly.FieldDropdown([['เดินหน้า','0'],['ถอยหลัง','1']]), 'DIR')
        .appendField('ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('°  ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('KI');
    this.appendValueInput('KI').setCheck('Number');
    this.appendDummyInput().appendField('KD');
    this.appendValueInput('KD').setCheck('Number');
    this.appendDummyInput().appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#d97706');
    this.setTooltip('เดินหน้า/ถอยหลัง PID — พิมพ์องศาเอง\nGenerate: MOVE(dir, yaw, speed, time, kp, ki, kd, rampUp, rampDown, startSpeed);');
  }
};

// ── MOVE_WALL ─────────────────────────────────────────────────
Blockly.Blocks['imu_move_wall'] = {
  init: function() {
    const _PINS = [
      ['A8 (13)','13'],['A9 (14)','14'],
      ['A6 (27)','27'],['A7 (26)','26'],
      ['A4 (25)','25'],['A5 (33)','33'],
      ['A2 (32)','32'],['A3 (35)','35'],
      ['A0 (39)','39'],['A1 (34)','34']
    ];
    this.appendDummyInput()
        .appendField('🚗 MOVE_WALL')
        .appendField(new Blockly.FieldDropdown([['เดินหน้า','0'],['ถอยหลัง','1']]), 'DIR')
        .appendField('ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP_yaw');
    this.appendValueInput('KP_YAW').setCheck('Number');
    this.appendDummyInput().appendField('KP_wall');
    this.appendValueInput('KP_WALL').setCheck('Number');
    this.appendDummyInput().appendField('ระยะ');
    this.appendValueInput('DIST').setCheck('Number');
    this.appendDummyInput()
        .appendField('cm  TRIG')
        .appendField(new Blockly.FieldDropdown(_PINS), 'TRIG')
        .appendField('ECHO')
        .appendField(new Blockly.FieldDropdown(_PINS), 'ECHO')
        .appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#be185d');
    this.setTooltip('เดินหน้า/ถอยหลัง IMU + Sonar กำแพง\nGenerate: MOVE_WALL(...);');
  }
};

// ── MOVE_LOOP ─────────────────────────────────────────────────
Blockly.Blocks['imu_move_loop_reset'] = {
  init: function() {
    this.appendDummyInput().appendField('🔁 MOVE_LOOP reset');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#be185d');
    this.setTooltip('reset state ก่อนเริ่ม loop\nGenerate: MOVE_LOOP_RESET();');
  }
};

Blockly.Blocks['imu_move_loop'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🚗 MOVE_LOOP')
        .appendField(new Blockly.FieldDropdown([['เดินหน้า','0'],['ถอยหลัง','1']]), 'DIR')
        .appendField('ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('KP_yaw');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KD_yaw');
    this.appendValueInput('KDYAW').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#be185d');
    this.setTooltip('เดิน 1 cycle ต่อการเรียก — ไม่มี duration\nGenerate: MOVE_LOOP(...);');
  }
};

Blockly.Blocks['imu_move_loop_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🚗 MOVE_LOOP')
        .appendField(new Blockly.FieldDropdown([['เดินหน้า','0'],['ถอยหลัง','1']]), 'DIR')
        .appendField('ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('°  ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('KP_yaw');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KD_yaw');
    this.appendValueInput('KDYAW').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#be185d');
    this.setTooltip('เดิน 1 cycle — ทิศพิมพ์เองหรือเสียบตัวแปรได้\nGenerate: MOVE_LOOP(...);');
  }
};

Blockly.Blocks['imu_move_wall_loop'] = {
  init: function() {
    const _PINS = [
      ['A8 (13)','13'],['A9 (14)','14'],
      ['A6 (27)','27'],['A7 (26)','26'],
      ['A4 (25)','25'],['A5 (33)','33'],
      ['A2 (32)','32'],['A3 (35)','35'],
      ['A0 (39)','39'],['A1 (34)','34']
    ];
    this.appendDummyInput()
        .appendField('🚗 MOVE_WALL_LOOP')
        .appendField(new Blockly.FieldDropdown([['เดินหน้า','0'],['ถอยหลัง','1']]), 'DIR')
        .appendField('ทิศ')
        .appendField(new Blockly.FieldDropdown([
          ['↑','0'],['→','90'],['↓','180'],['←','270'],
          ['↗','45'],['↘','135'],['↙','225'],['↖','315']
        ]), 'YAW')
        .appendField('ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('KP_yaw');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KP_wall');
    this.appendValueInput('KPWALL').setCheck('Number');
    this.appendDummyInput().appendField('ระยะข้าง');
    this.appendValueInput('WALLDIST').setCheck('Number');
    this.appendDummyInput()
        .appendField('cm  TRIG')
        .appendField(new Blockly.FieldDropdown(_PINS), 'TRIG')
        .appendField('ECHO')
        .appendField(new Blockly.FieldDropdown(_PINS), 'ECHO');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#9d174d');
    this.setTooltip('เดิน 1 cycle + Sonar กำแพง\nGenerate: MOVE_WALL_LOOP(...);');
  }
};

// ══════════════════════════════════════════════════════
//  PS3 Controller (Bluetooth) — ใช้ ESP32 BT Classic
//  จับคู่ MAC ของ ESP32 ลงจอยด้วย SixaxisPairTool ก่อน
//  #include <Ps3Controller.h> ถูกเติมอัตโนมัติเมื่อใช้บล็อกพวกนี้
// ══════════════════════════════════════════════════════

if (typeof _PS3_BTN_OPT === 'undefined') {
  var _PS3_BTN_OPT = [
    ['✕ (Cross)','cross'], ['◯ (Circle)','circle'],
    ['△ (Triangle)','triangle'], ['▢ (Square)','square'],
    ['ลูกศร ขึ้น','up'], ['ลูกศร ลง','down'],
    ['ลูกศร ซ้าย','left'], ['ลูกศร ขวา','right'],
    ['L1','l1'], ['R1','r1'], ['L2','l2'], ['R2','r2'],
    ['L3 (กดสติ๊กซ้าย)','l3'], ['R3 (กดสติ๊กขวา)','r3'],
    ['START','start'], ['SELECT','select'], ['PS','ps']
  ];
  var _PS3_STICK_OPT = [
    ['สติ๊กซ้าย แกน X (ซ้าย/ขวา)','lx'], ['สติ๊กซ้าย แกน Y (หน้า/หลัง)','ly'],
    ['สติ๊กขวา แกน X (ซ้าย/ขวา)','rx'], ['สติ๊กขวา แกน Y (หน้า/หลัง)','ry']
  ];
}

// เริ่ม PS3 (ใส่ใน Setup) — MAC = ของ ESP32 ที่เขียนลงจอยไว้
Blockly.Blocks['ps3_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('PS3 เริ่ม  MAC')
        .appendField(new Blockly.FieldTextInput('01:02:03:04:05:06'), 'MAC');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('เริ่มรับจอย PS3 ผ่าน Bluetooth (ใส่ใน Setup)\nเว้นว่าง = ใช้ MAC จริงของชิป (แนะนำ) → Ps3.begin()\nใส่ MAC = บังคับ MAC (ต้องตรงกับที่เขียนลงจอยด้วย SixaxisPairTool) → Ps3.begin("MAC")');
  }
};

// PS3 เชื่อมต่อแล้ว? (Boolean)
Blockly.Blocks['ps3_connected'] = {
  init: function() {
    this.appendDummyInput().appendField('PS3 เชื่อมต่อแล้ว?');
    this.setOutput(true, 'Boolean');
    this.setColour('#2563eb');
    this.setTooltip('คืน true ถ้าจอย PS3 เชื่อมต่ออยู่\nGenerate: Ps3.isConnected()');
  }
};

// ปุ่ม PS3 ถูกกด? (Boolean)
Blockly.Blocks['ps3_button'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ปุ่ม PS3')
        .appendField(new Blockly.FieldDropdown(_PS3_BTN_OPT), 'BTN')
        .appendField('ถูกกด?');
    this.setOutput(true, 'Boolean');
    this.setColour('#2563eb');
    this.setTooltip('คืน true ถ้าปุ่มนั้นถูกกด\nGenerate: Ps3.data.button.xxx');
  }
};

// อนาล็อกสติ๊ก PS3 (Number −128..127, กลาง=0)
Blockly.Blocks['ps3_stick'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ค่าสติ๊ก PS3')
        .appendField(new Blockly.FieldDropdown(_PS3_STICK_OPT), 'AXIS');
    this.setOutput(true, 'Number');
    this.setColour('#2563eb');
    this.setTooltip('คืนค่าอนาล็อกสติ๊ก −128..127 (กลาง=0)\nY: ดันหน้า = ลบ, ดึงหลัง = บวก\nGenerate: Ps3.data.analog.stick.xx');
  }
};

// สั่นจอย PS3
Blockly.Blocks['ps3_rumble'] = {
  init: function() {
    this.appendDummyInput().appendField('PS3 สั่น แรง');
    this.appendValueInput('INTENSITY').setCheck('Number');
    this.appendDummyInput().appendField('% นาน');
    this.appendValueInput('DUR').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#2563eb');
    this.setTooltip('สั่นมอเตอร์ในจอย (แรง 0-100%, นาน ms)\nGenerate: Ps3.setRumble(intensity, duration);');
  }
};

// ══════════════════════════════════════════════════════
//  Buzzer (active, pin 12) — สั่ง ON/OFF เท่านั้น ปรับความถี่ไม่ได้
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_buzzer_tone'] = {
  init: function() {
    this.appendDummyInput().appendField('🔔 Buzzer บีบ');
    this.appendValueInput('DUR').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
    this.setTooltip('เปิด Buzzer นาน (ms) แล้วปิดเอง\nactive buzzer ปรับความถี่ไม่ได้  pin 12');
  }
};

Blockly.Blocks['s2_buzzer_on'] = {
  init: function() {
    this.appendDummyInput().appendField('🔔 Buzzer เปิด');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
    this.setTooltip('เปิดเสียง Buzzer ค้างไว้ (ปิดด้วยบล็อก Buzzer ปิด)  pin 12');
  }
};

Blockly.Blocks['s2_buzzer_off'] = {
  init: function() {
    this.appendDummyInput().appendField('🔕 Buzzer ปิด');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
    this.setTooltip('หยุดเสียง Buzzer  pin 12');
  }
};

// ══════════════════════════════════════════════════════
//  Button — RAZOR-S2  SW pin 15 (INPUT_PULLUP, กด = LOW)
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_button'] = {
  init: function() {
    this.appendDummyInput().appendField('🔘 ปุ่มถูกกด?');
    this.setOutput(true, 'Boolean');
    this.setColour('#6d28d9');
    this.setTooltip('คืน true เมื่อกดปุ่ม SW (pin 15)');
  }
};

// ══════════════════════════════════════════════════════════════
//  Robot Menu — เมนูเลือกโปรแกรม ปุ่มเดียว (SW pin 15)
//  Mutator: คลิก ⚙️ เพื่อเพิ่ม/ลบรายการ (2-8 รายการ)
//  พอร์ตจาก RAZOR-S3 → เปลี่ยนปุ่ม SW10() เป็น pin 15
// ══════════════════════════════════════════════════════════════

// ── Popup container (ใน mutator workspace) ──────────────────
Blockly.Blocks['robot_menu_container'] = {
  init: function() {
    this.appendDummyInput().appendField('📋 Robot Menu');
    this.appendStatementInput('STACK');
    this.setColour('#7c3aed');
    this.setTooltip('ลาก "รายการ" เข้า-ออก เพื่อเพิ่ม/ลบ (2-8 รายการ)');
    this.contextMenu = false;
  }
};

// ── Popup item block ─────────────────────────────────────────
Blockly.Blocks['robot_menu_item'] = {
  init: function() {
    this.appendDummyInput().appendField('  📌 รายการ');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#7c3aed');
    this.setTooltip('รายการในเมนู — ลากออกเพื่อลบ');
    this.contextMenu = false;
  }
};

// ── Main block ───────────────────────────────────────────────
Blockly.Blocks['robot_menu'] = {
  itemCount_: 4,

  init: function() {
    this.appendDummyInput('TITLE')
        .appendField('📋 Robot Menu')
        .appendField('   กด=เลือก  ค้าง=ถัดไป');
    this.updateShape_();
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour('#7c3aed');
    this.setTooltip(
      'เมนูเลือกโปรแกรมบน OLED ด้วยปุ่มเดียว (SW pin 15)\n' +
      'กดสั้น = เลือก & รัน\n' +
      'กดค้าง ≥ 0.6s = เลื่อนถัดไป (วนกลับ)\n' +
      'OLED scrolling — รองรับสูงสุด 8 รายการ\n' +
      'คลิก ⚙️ เพื่อเพิ่ม/ลบรายการ'
    );
    // รองรับ Blockly v10 (MutatorIcon) และเก่ากว่า (Mutator)
    const MutClass = (Blockly.icons && Blockly.icons.MutatorIcon)
      ? Blockly.icons.MutatorIcon : Blockly.Mutator;
    this.setMutator(new MutClass(['robot_menu_item'], this));
  },

  mutationToDom: function() {
    const el = document.createElement('mutation');
    el.setAttribute('items', this.itemCount_);
    return el;
  },

  domToMutation: function(xmlElement) {
    this.itemCount_ = Math.max(2, Math.min(8,
      parseInt(xmlElement.getAttribute('items'), 10) || 4));
    this.updateShape_();
  },

  decompose: function(workspace) {
    const container = workspace.newBlock('robot_menu_container');
    container.initSvg();
    let conn = container.getInput('STACK').connection;
    for (let i = 0; i < this.itemCount_; i++) {
      const item = workspace.newBlock('robot_menu_item');
      item.initSvg();
      conn.connect(item.previousConnection);
      conn = item.nextConnection;
    }
    return container;
  },

  compose: function(containerBlock) {
    // เก็บ block ปัจจุบันก่อน rebuild
    let itemBlock = containerBlock.getInputTargetBlock('STACK');
    const savedBlocks = [];
    while (itemBlock && !itemBlock.isInsertionMarker()) {
      savedBlocks.push(itemBlock._menuSaved || null);
      itemBlock._menuSaved = null;
      itemBlock = itemBlock.nextConnection && itemBlock.nextConnection.targetBlock();
    }
    // ถอดต่อ input ที่จะถูกลบ
    const newCount = Math.max(2, Math.min(8, savedBlocks.length));
    for (let i = newCount; i < this.itemCount_; i++) {
      const inp = this.getInput('DO' + i);
      if (inp) { const tb = inp.connection.targetBlock(); if (tb) tb.unplug(false); }
    }
    this.itemCount_ = newCount;
    this.updateShape_();
    // ต่อ block กลับ
    for (let i = 0; i < savedBlocks.length; i++) {
      const blk = savedBlocks[i];
      const inp = this.getInput('DO' + i);
      if (blk && inp && blk.workspace && !blk.isDisposed()) {
        try { inp.connection.connect(blk.previousConnection); } catch(e) {}
      }
    }
  },

  saveConnections: function(containerBlock) {
    let itemBlock = containerBlock.getInputTargetBlock('STACK');
    let i = 0;
    while (itemBlock && !itemBlock.isInsertionMarker()) {
      const inp = this.getInput('DO' + i);
      itemBlock._menuSaved = inp && inp.connection.targetBlock();
      i++;
      itemBlock = itemBlock.nextConnection && itemBlock.nextConnection.targetBlock();
    }
  },

  updateShape_: function() {
    // บันทึกชื่อที่มีอยู่ก่อน rebuild
    const savedNames = [];
    let k = 0;
    while (this.getInput('LABEL' + k)) {
      savedNames[k] = this.getFieldValue('NAME' + k) || ('Mode ' + (k + 1));
      k++;
    }
    // ลบ input เก่า
    let i = 0;
    while (this.getInput('LABEL' + i)) {
      this.removeInput('LABEL' + i);
      this.removeInput('DO' + i);
      i++;
    }
    // สร้าง input ใหม่
    for (let j = 0; j < this.itemCount_; j++) {
      const defName = savedNames[j] || ('Mode ' + (j + 1));
      const corner  = j === 0 ? '┌' : (j === this.itemCount_ - 1 ? '└' : '├');
      this.appendDummyInput('LABEL' + j)
          .appendField('  ' + corner + ' รายการ ' + (j + 1) + ' :')
          .appendField(new Blockly.FieldTextInput(defName), 'NAME' + j);
      this.appendStatementInput('DO' + j).setCheck(null);
    }
  }
};

// ══════════════════════════════════════════════════════
//  Analog Read — RAZOR-S2  A0–A9
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_analog'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📊 Analog')
        .appendField(new Blockly.FieldDropdown([
          ['A0 (39)','39'],['A1 (34)','34'],['A2 (32)','32'],
          ['A3 (35)','35'],['A4 (25)','25'],['A5 (33)','33'],
          ['A6 (27)','27'],['A7 (26)','26'],['A8 (13)','13'],
          ['A9 (14)','14']
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('อ่านค่า Analog 0–4095 (12-bit)');
  }
};

// ══════════════════════════════════════════════════════
//  Color Sensor (TCS34725) — Wire SDA21/SCL23 · addr 0x29
//  (var + guard กัน "already declared" ตอนสลับบอร์ด)
// ══════════════════════════════════════════════════════
if (typeof _S2COLOR_OPT === 'undefined') {
  var _S2COLOR_OPT = [
    ['⬜ ขาว','0'], ['🟥 แดง','1'], ['🟩 เขียว','2'],
    ['🟦 น้ำเงิน','3'], ['🟨 เหลือง','4'], ['⬛ ดำ','5']
  ];
  var _S2COLOR_GAIN_OPT = [
    ['1x','0'], ['4x (แนะนำ)','1'], ['16x','2'], ['60x (พื้นมืด)','3']
  ];
  var _S2COLOR_CNT_OPT = [['6 สี (รวมดำ)','6'],['5 สี','5'],['4 สี','4'],['3 สี','3']];
}

Blockly.Blocks['s2_color_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎨 เริ่มเซนเซอร์สี gain')
        .appendField(new Blockly.FieldDropdown(_S2COLOR_GAIN_OPT), 'GAIN');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('เริ่ม TCS34725 บน Wire (SDA21/SCL23)\nใส่ใน Setup\nGenerate: tcs_begin(0xEB, gain);');
  }
};

Blockly.Blocks['s2_color_calibrate'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎓 คาลิเบรตสอนสี + EEPROM')
        .appendField(new Blockly.FieldDropdown(_S2COLOR_CNT_OPT), 'CNT');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('ใส่ใน Setup · กดปุ่ม SW(15) ค้างตอนเปิด = สอน+เซฟ / เปิดปกติ = โหลด\n' +
                    'ลำดับสอน: ขาว→แดง→เขียว→น้ำเงิน→เหลือง→ดำ (เริ่มขาวเสมอ)\n' +
                    'Generate: tcs_calibrate(count);');
  }
};

Blockly.Blocks['s2_color_is'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🔍 สีพื้นคือ')
        .appendField(new Blockly.FieldDropdown(_S2COLOR_OPT), 'COLOR');
    this.setOutput(true, 'Boolean');
    this.setColour('#6d28d9');
    this.setTooltip('คืน true ถ้าสีพื้นตรงกับที่เลือก\nGenerate: (tcs_readColor() == slot)');
  }
};

Blockly.Blocks['s2_color_read'] = {
  init: function() {
    this.appendDummyInput().appendField('🎯 อ่านสี (เลขช่อง)');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('คืนเลขช่องสีที่ใกล้สุด 0-5 (-1=ไม่รู้จัก)\nGenerate: tcs_readColor()');
  }
};

Blockly.Blocks['s2_color_name'] = {
  init: function() {
    this.appendDummyInput().appendField('🏷️ ชื่อสีที่อ่านได้');
    this.setOutput(true, 'String');
    this.setColour('#6d28d9');
    this.setTooltip('คืนชื่อสีที่อ่านได้ (ไว้โชว์ OLED)\nGenerate: tcs_colorName(tcs_readColor())');
  }
};

Blockly.Blocks['s2_color_value'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📊 ค่าสี')
        .appendField(new Blockly.FieldDropdown([
          ['R (แดง 0-255)','tcs_r'],
          ['G (เขียว 0-255)','tcs_g'],
          ['B (น้ำเงิน 0-255)','tcs_b'],
          ['Lux (ความสว่าง)','tcs_lux'],
          ['Hue (สี 0-360)','tcs_hue'],
          ['Sat (ความสด 0-100)','tcs_sat'],
          ['Clear (ความสว่างดิบ)','tcs_clear']
        ]), 'KIND');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('อ่านค่าเดี่ยว ไว้ทำเงื่อนไขเอง / debug\n' +
                    'R,G,B = 0-255 (สอนขาวก่อน ขาว=255) · Lux=ความสว่าง');
  }
};

Blockly.Blocks['s2_color_reject'] = {
  init: function() {
    this.appendDummyInput().appendField('⚙️ ความเข้มงวดสี');
    this.appendValueInput('D').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('ระยะตัดสิน "ไม่รู้จักสี" 0.0-2.0 เล็ก=เข้มงวด (เริ่มต้น 0.35)\nGenerate: tcs_setReject(d);');
  }
};

// ══════════════════════════════════════════════════════
//  Line Sensor + PID + Line+Gyro — analog A0-A7 (12-bit)
//  (var + guard กัน "already declared" ตอนสลับบอร์ด)
// ══════════════════════════════════════════════════════
if (typeof _S2LINE_CH_OPT === 'undefined') {
  var _S2LINE_CH_OPT = [['A0','0'],['A1','1'],['A2','2'],['A3','3'],
                        ['A4','4'],['A5','5'],['A6','6'],['A7','7']];
  var _S2LINE_TYPE_OPT = [['ดำ/พื้นขาว','0'],['ขาว/พื้นดำ','1']];
  var _S2LINE_DIR_OPT  = [['เดินหน้า','0'],['ถอยหลัง','1']];
  var _S2LINE_YAW_OPT  = [['↑','0'],['→','90'],['↓','180'],['←','270'],
                          ['↗','45'],['↘','135'],['↙','225'],['↖','315']];
}

// คาลิเบรตเซนเซอร์ (กวาดหาค่ากลาง + เซฟ) — ใส่ใน Setup ตอนจูน
Blockly.Blocks['s2_line_calibrate'] = {
  init: function() {
    this.appendDummyInput().appendField('🎚️ คาลิเบรตเส้น (ms)');
    this.appendValueInput('DUR').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('กวาดหาค่ากลาง A0-A7 แล้วเซฟ EEPROM (ลากหุ่นคร่อมเส้นไปมาตามเวลา)\nGenerate: autoScanSensor(dur);');
  }
};

// โหลดค่ากลางจาก EEPROM — ใส่ใน Setup ตอนใช้งานจริง
Blockly.Blocks['s2_line_load'] = {
  init: function() {
    this.appendDummyInput().appendField('📂 โหลดค่าเส้นจาก EEPROM');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('โหลดค่ากลางที่คาลิเบรตไว้ (ใส่ใน Setup)\nGenerate: loadLineCal();');
  }
};

// ตั้งค่าเซนเซอร์หน้า (Setup)
Blockly.Blocks['s2_line_setup_front'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ตั้งค่าเซนเซอร์หน้า  สี')
        .appendField(new Blockly.FieldDropdown(_S2LINE_TYPE_OPT), 'TYPE')
        .appendField('ชุด A')
        .appendField(new Blockly.FieldDropdown(_S2LINE_CH_OPT), 'FROM')
        .appendField('-A')
        .appendField(new Blockly.FieldDropdown(_S2LINE_CH_OPT), 'TO');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8');
    this.setTooltip('ตั้งช่วงเซนเซอร์หน้า + สีเส้น (Setup ครั้งเดียว)\nGenerate: setupLineFront(from, to, type);');
  }
};

// ตั้งค่าเซนเซอร์หลัง (Setup)
Blockly.Blocks['s2_line_setup_back'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ตั้งค่าเซนเซอร์หลัง  สี')
        .appendField(new Blockly.FieldDropdown(_S2LINE_TYPE_OPT), 'TYPE')
        .appendField('ชุด A')
        .appendField(new Blockly.FieldDropdown(_S2LINE_CH_OPT), 'FROM')
        .appendField('-A')
        .appendField(new Blockly.FieldDropdown(_S2LINE_CH_OPT), 'TO')
        .appendField('ถอยกลับทิศ')
        .appendField(new Blockly.FieldDropdown([['ปกติ','0'],['กลับซ้าย-ขวา','1']]), 'BFLIP');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1e40af');
    this.setTooltip('ตั้งช่วงเซนเซอร์หลัง + สี + กลับทิศตอนถอย (Setup)\nGenerate: setupLineBack(from, to, type, backFlip);');
  }
};

// ตามเส้น PID หน้า (loop)
Blockly.Blocks['s2_line_pid_front'] = {
  init: function() {
    this.appendDummyInput().appendField('ตามเส้น PID หน้า  speed');
    this.appendValueInput('SPEED').setCheck('Number');
    this.appendDummyInput().appendField('KP');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('KD');
    this.appendValueInput('KD').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip('เดินตามเส้น 1 รอบ (ใส่ใน loop) — เซนเซอร์ชุดหน้า\nต้อง setup หน้า + calibrate ก่อน\nGenerate: linePID_front(speed, kp, kd);');
  }
};

// ตามเส้น PID หลัง (loop)
Blockly.Blocks['s2_line_pid_back'] = {
  init: function() {
    this.appendDummyInput().appendField('ตามเส้น PID หลัง  speed');
    this.appendValueInput('SPEED').setCheck('Number');
    this.appendDummyInput().appendField('KP');
    this.appendValueInput('KP').setCheck('Number');
    this.appendDummyInput().appendField('KD');
    this.appendValueInput('KD').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309');
    this.setTooltip('ถอยตามเส้น 1 รอบ (ใส่ใน loop) — เซนเซอร์ชุดหลัง\nGenerate: linePID_back(speed, kp, kd);');
  }
};

// ตามเส้น + ไจโร (ทิศแบบลูกศร)
Blockly.Blocks['s2_line_move'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ตามเส้น+ไจโร')
        .appendField(new Blockly.FieldDropdown(_S2LINE_DIR_OPT), 'DIR')
        .appendField('ทิศ')
        .appendField(new Blockly.FieldDropdown(_S2LINE_YAW_OPT), 'YAW')
        .appendField('ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP เส้น');
    this.appendValueInput('KPLINE').setCheck('Number');
    this.appendDummyInput().appendField('KD เส้น');
    this.appendValueInput('KDLINE').setCheck('Number');
    this.appendDummyInput().appendField('KP ไจโร');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KD ไจโร');
    this.appendValueInput('KDYAW').setCheck('Number');
    this.appendDummyInput().appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#d97706');
    this.setTooltip('เดินตามเส้น + ไจโรยึดทิศ (ผสม PID 2 ชุด) — ทางโค้งลด KP ไจโร\nต้อง setup + calibrate ก่อน\nGenerate: LINE_MOVE(dir, yaw, speed, time, kpLine, kdLine, kpYaw, kdYaw, rampUp, rampDown, startSpeed);');
  }
};

// ตามเส้น + ไจโร (พิมพ์องศาเอง / เสียบตัวแปร)
Blockly.Blocks['s2_line_move_num'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ตามเส้น+ไจโร')
        .appendField(new Blockly.FieldDropdown(_S2LINE_DIR_OPT), 'DIR')
        .appendField('ทิศ');
    this.appendValueInput('YAW').setCheck('Number');
    this.appendDummyInput().appendField('° ความเร็วต้น');
    this.appendValueInput('STARTSPD').setCheck('Number');
    this.appendDummyInput().appendField('speed');
    this.appendValueInput('SPD').setCheck('Number');
    this.appendDummyInput().appendField('time');
    this.appendValueInput('TIME').setCheck('Number');
    this.appendDummyInput().appendField('ms  KP เส้น');
    this.appendValueInput('KPLINE').setCheck('Number');
    this.appendDummyInput().appendField('KD เส้น');
    this.appendValueInput('KDLINE').setCheck('Number');
    this.appendDummyInput().appendField('KP ไจโร');
    this.appendValueInput('KPYAW').setCheck('Number');
    this.appendDummyInput().appendField('KD ไจโร');
    this.appendValueInput('KDYAW').setCheck('Number');
    this.appendDummyInput().appendField('เร่ง');
    this.appendValueInput('RAMPUP').setCheck('Number');
    this.appendDummyInput().appendField('ms  ชะลอ');
    this.appendValueInput('RAMPDOWN').setCheck('Number');
    this.appendDummyInput().appendField('ms');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#d97706');
    this.setTooltip('ตามเส้น+ไจโร พิมพ์องศาทิศเอง (เสียบตัวแปรได้)\nGenerate: LINE_MOVE(dir, yaw, ...);');
  }
};

// นับเซนเซอร์ที่เจอเส้น (เช็คทางแยก / หลุดเส้น = 0)
Blockly.Blocks['s2_line_count'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('นับเซนเซอร์เจอเส้น A')
        .appendField(new Blockly.FieldDropdown(_S2LINE_CH_OPT), 'FROM')
        .appendField('-A')
        .appendField(new Blockly.FieldDropdown(_S2LINE_CH_OPT), 'TO')
        .appendField('สี')
        .appendField(new Blockly.FieldDropdown(_S2LINE_TYPE_OPT), 'TYPE');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('คืนจำนวนเซนเซอร์ที่เจอเส้น (0=หลุดเส้น, มาก=ทางแยก)\nGenerate: countSensors(from, to, type)');
  }
};

// เซนเซอร์ช่องเดียวเจอเส้นไหม
Blockly.Blocks['s2_line_on_line'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('เซนเซอร์ A')
        .appendField(new Blockly.FieldDropdown(_S2LINE_CH_OPT), 'CH')
        .appendField('เจอเส้น สี')
        .appendField(new Blockly.FieldDropdown(_S2LINE_TYPE_OPT), 'TYPE');
    this.setOutput(true, 'Boolean');
    this.setColour('#6d28d9');
    this.setTooltip('คืน true ถ้าเซนเซอร์ช่องนั้นเจอเส้น\nGenerate: sensorOnLine(ch, type)');
  }
};

// ค่ากลาง (ref / threshold) ของเซนเซอร์ช่องนั้น
Blockly.Blocks['s2_line_get_ref'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('ค่ากลาง(ref) เซนเซอร์ A')
        .appendField(new Blockly.FieldDropdown(_S2LINE_CH_OPT), 'CH');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('อ่านค่ากลาง (threshold) ที่คาลิเบรตไว้ของเซนเซอร์เส้นช่องนั้น\nใช้เทียบกับค่าดิบจาก ADC\nGenerate: getRef(ch);');
  }
};
