// ============================================================
//  ESP32 Board Blocks — มาตรฐาน Arduino ESP32
//  ครอบคลุม: Digital I/O, Analog, PWM, Serial, WiFi, 
//             LED PWM (LEDC), Touch, Timer, I2C, SPI
// ============================================================

// ══════════════════════════════════════════════════════
//  I/O — Digital / Analog / PWM
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_digital_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalWrite pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('=')
        .appendField(new Blockly.FieldDropdown([['HIGH','HIGH'],['LOW','LOW']]), 'VAL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('ตั้งค่า digital output');
  }
};

Blockly.Blocks['esp32_digital_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalRead pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e'); this.setTooltip('อ่านค่า digital input (0/1)');
  }
};

Blockly.Blocks['esp32_pin_mode'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('pinMode pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('เป็น')
        .appendField(new Blockly.FieldDropdown([
          ['OUTPUT','OUTPUT'],['INPUT','INPUT'],
          ['INPUT_PULLUP','INPUT_PULLUP'],['INPUT_PULLDOWN','INPUT_PULLDOWN']
        ]), 'MODE');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('ตั้งค่าโหมดของ pin');
  }
};

Blockly.Blocks['esp32_analog_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogRead pin')
        .appendField(new Blockly.FieldDropdown([
          ['34','34'],['35','35'],['36','36'],['39','39'],
          ['32','32'],['33','33'],['25','25'],['26','26'],['27','27']
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e'); this.setTooltip('อ่าน ADC 0-4095 (12-bit)');
  }
};

Blockly.Blocks['esp32_analog_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogWrite pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('ค่า');
    this.appendValueInput('VAL').setCheck('Number');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('PWM 0-255');
  }
};

// ══════════════════════════════════════════════════════
//  Serial
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_serial_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Serial.begin')
        .appendField(new Blockly.FieldDropdown([
          ['115200','115200'],['9600','9600'],['57600','57600'],['230400','230400']
        ]), 'BAUD');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('เริ่ม Serial communication');
  }
};

Blockly.Blocks['esp32_serial_print'] = {
  init: function() {
    this.appendValueInput('VAL')
        .appendField('Serial.print');
    this.appendDummyInput()
        .appendField(new Blockly.FieldCheckbox('TRUE'), 'NL')
        .appendField('newline');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('พิมพ์ข้อความออก Serial');
  }
};

Blockly.Blocks['esp32_serial_println'] = {
  init: function() {
    this.appendValueInput('VAL')
        .appendField('Serial.println');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('พิมพ์ข้อความพร้อม newline');
  }
};

Blockly.Blocks['esp32_serial_available'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.available()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b'); this.setTooltip('จำนวน bytes ที่รอใน buffer');
  }
};

Blockly.Blocks['esp32_serial_read'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.read()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b'); this.setTooltip('อ่าน 1 byte จาก Serial');
  }
};

Blockly.Blocks['esp32_serial_readstring'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.readString()');
    this.setOutput(true, 'String');
    this.setColour('#c0392b'); this.setTooltip('อ่าน String จาก Serial');
  }
};

// ══════════════════════════════════════════════════════
//  WiFi
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_wifi_connect'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('WiFi เชื่อมต่อ SSID')
        .appendField(new Blockly.FieldTextInput('MyWiFi'), 'SSID');
    this.appendDummyInput()
        .appendField('Password')
        .appendField(new Blockly.FieldTextInput('password'), 'PASS');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2'); this.setTooltip('เชื่อมต่อ WiFi');
  }
};

Blockly.Blocks['esp32_wifi_connected'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi เชื่อมต่ออยู่?');
    this.setOutput(true, 'Boolean');
    this.setColour('#0891b2'); this.setTooltip('true ถ้า WiFi connected');
  }
};

Blockly.Blocks['esp32_wifi_ip'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi IP Address');
    this.setOutput(true, 'String');
    this.setColour('#0891b2'); this.setTooltip('คืน IP address เป็น String');
  }
};

Blockly.Blocks['esp32_wifi_disconnect'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi ตัดการเชื่อมต่อ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2'); this.setTooltip('ตัด WiFi');
  }
};

// ══════════════════════════════════════════════════════
//  LED (Onboard + LEDC PWM)
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_builtin_led'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LED บนบอร์ด')
        .appendField(new Blockly.FieldDropdown([['เปิด','HIGH'],['ปิด','LOW']]), 'VAL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('LED pin 2 บน ESP32');
  }
};

Blockly.Blocks['esp32_ledc_setup'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC setup channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH')
        .appendField('freq')
        .appendField(new Blockly.FieldNumber(5000), 'FREQ')
        .appendField('Hz resolution')
        .appendField(new Blockly.FieldNumber(8, 1, 16), 'RES')
        .appendField('bit');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('ตั้งค่า LEDC PWM channel');
  }
};

Blockly.Blocks['esp32_ledc_attach'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC attach pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
  }
};

Blockly.Blocks['esp32_ledc_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC write channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH')
        .appendField('duty');
    this.appendValueInput('DUTY').setCheck('Number');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('ตั้ง duty cycle 0-255');
  }
};

// ══════════════════════════════════════════════════════
//  Touch Sensor (ESP32 built-in)
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_touch_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('touchRead pin')
        .appendField(new Blockly.FieldDropdown([
          ['T0 (GPIO4)','4'],['T1 (GPIO0)','0'],['T2 (GPIO2)','2'],
          ['T3 (GPIO15)','15'],['T4 (GPIO13)','13'],['T5 (GPIO12)','12'],
          ['T6 (GPIO14)','14'],['T7 (GPIO27)','27'],['T8 (GPIO33)','33'],['T9 (GPIO32)','32']
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#8b5cf6'); this.setTooltip('อ่านค่า capacitive touch (ยิ่งต่ำยิ่งถูกแตะ)');
  }
};

// ══════════════════════════════════════════════════════
//  Timer / Delay
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_delay_ms'] = {
  init: function() {
    this.appendValueInput('TIME')
        .appendField('รอ (ms)');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8'); this.setTooltip('หน่วงเวลา millisecond');
  }
};

Blockly.Blocks['esp32_millis'] = {
  init: function() {
    this.appendDummyInput().appendField('millis()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8'); this.setTooltip('เวลาที่ผ่านไปตั้งแต่เปิดบอร์ด (ms)');
  }
};

Blockly.Blocks['esp32_micros'] = {
  init: function() {
    this.appendDummyInput().appendField('micros()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8'); this.setTooltip('เวลาที่ผ่านไปตั้งแต่เปิดบอร์ด (µs)');
  }
};

// ══════════════════════════════════════════════════════
//  Math / Utility
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_map'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('map');
    this.appendValueInput('IN_MIN').appendField('จาก');
    this.appendValueInput('IN_MAX').appendField('ถึง');
    this.appendValueInput('OUT_MIN').appendField('→');
    this.appendValueInput('OUT_MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('แปลงช่วงค่า');
  }
};

Blockly.Blocks['esp32_constrain'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('constrain');
    this.appendValueInput('MIN').appendField('min');
    this.appendValueInput('MAX').appendField('max');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('จำกัดค่าอยู่ในช่วง min-max');
  }
};

Blockly.Blocks['esp32_random'] = {
  init: function() {
    this.appendValueInput('MIN').appendField('random จาก');
    this.appendValueInput('MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('สุ่มตัวเลข');
  }
};

// ══════════════════════════════════════════════════════
//  ESP32 System
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_restart'] = {
  init: function() {
    this.appendDummyInput().appendField('ESP.restart()');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#dc2626'); this.setTooltip('รีสตาร์ท ESP32');
  }
};

Blockly.Blocks['esp32_free_heap'] = {
  init: function() {
    this.appendDummyInput().appendField('ESP.getFreeHeap()');
    this.setOutput(true, 'Number');
    this.setColour('#dc2626'); this.setTooltip('RAM ที่เหลือ (bytes)');
  }
};

// ══════════════════════════════════════════════════════
//  OLED 128×32 — RAZOR-S2  (S2_oled.h / Adafruit_SSD1306)
//  I2C SDA=21  SCL=23  addr=0x3C
//  line 1–4 (size=1)  หรือ  1–2 (size=2)
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_oled_clear'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED ล้างหน้าจอ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('ล้างหน้าจอ OLED (ยังไม่แสดงผลจนกว่าจะ update)');
  }
};

Blockly.Blocks['s2_oled_update'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED แสดงผล');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('ส่งข้อมูลไปแสดงบนหน้าจอ OLED');
  }
};

Blockly.Blocks['s2_oled_print'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED แถว')
        .appendField(new Blockly.FieldDropdown([
          ['1','1'],['2','2'],['3','3'],['4','4']
        ]), 'LINE');
    this.appendValueInput('VAL').appendField('ค่า');
    this.appendDummyInput()
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2']]), 'SZ');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('แสดงข้อความที่แถวที่ระบุ (1–4)\nsize 2 = ตัวใหญ่ขึ้น 2 เท่า');
  }
};

Blockly.Blocks['s2_oled_label'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED แถว')
        .appendField(new Blockly.FieldDropdown([
          ['1','1'],['2','2'],['3','3'],['4','4']
        ]), 'LINE');
    this.appendValueInput('LABEL').appendField('หัวข้อ');
    this.appendValueInput('VAL').appendField('ค่า');
    this.appendDummyInput()
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2']]), 'SZ');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('แสดง "หัวข้อ: ค่า" บนแถวที่ระบุ');
  }
};

Blockly.Blocks['s2_oled_xy'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED ที่ x');
    this.appendValueInput('X');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y');
    this.appendValueInput('VAL').appendField('ค่า');
    this.appendDummyInput()
        .appendField('size')
        .appendField(new Blockly.FieldDropdown([['1','1'],['2','2']]), 'SZ');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9');
    this.setTooltip('แสดงข้อความที่ตำแหน่ง pixel x,y\nx: 0–127  y: 0–31');
  }
};

Blockly.Blocks['s2_oled_line'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED เส้น x1');
    this.appendValueInput('X1');
    this.appendDummyInput().appendField('y1');
    this.appendValueInput('Y1');
    this.appendDummyInput().appendField('→ x2');
    this.appendValueInput('X2');
    this.appendDummyInput().appendField('y2');
    this.appendValueInput('Y2');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('วาดเส้นตรงจาก (x1,y1) ถึง (x2,y2)');
  }
};

Blockly.Blocks['s2_oled_rect'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED กรอบ x');
    this.appendValueInput('X');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y');
    this.appendDummyInput().appendField('w');
    this.appendValueInput('W');
    this.appendDummyInput().appendField('h');
    this.appendValueInput('H');
    this.appendDummyInput()
        .appendField(new Blockly.FieldDropdown([['กรอบ','0'],['ทึบ','1']]), 'FILL');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('วาดสี่เหลี่ยม (กรอบ หรือ ทึบ)');
  }
};

Blockly.Blocks['s2_oled_progress'] = {
  init: function() {
    this.appendDummyInput().appendField('🖥 OLED Progress x');
    this.appendValueInput('X');
    this.appendDummyInput().appendField('y');
    this.appendValueInput('Y');
    this.appendDummyInput().appendField('w');
    this.appendValueInput('W');
    this.appendDummyInput().appendField('h');
    this.appendValueInput('H');
    this.appendValueInput('VAL').appendField('ค่า');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('แสดง progress bar 0–100%');
  }
};

Blockly.Blocks['s2_sonar'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('📡 Sonar trig')
        .appendField(new Blockly.FieldDropdown([
          ['A8 (13)','13'],['A9 (14)','14'],
          ['A6 (27)','27'],['A7 (26)','26'],
          ['A4 (25)','25'],['A5 (33)','33'],
          ['A2 (32)','32']
        ]), 'TRIG')
        .appendField('echo')
        .appendField(new Blockly.FieldDropdown([
          ['A9 (14)','14'],['A8 (13)','13'],
          ['A7 (26)','26'],['A6 (27)','27'],
          ['A5 (33)','33'],['A4 (25)','25'],
          ['A0 (39)','39'],['A1 (34)','34'],['A3 (35)','35']
        ]), 'ECHO');
    this.setOutput(true, 'Number');
    this.setColour('#6d28d9');
    this.setTooltip('วัดระยะ HC-SR04 (cm)\nคืน -1 ถ้าเกินระยะ 4m หรือไม่เจอวัตถุ');
  }
};

Blockly.Blocks['s2_oled_invert'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🖥 OLED กลับสี')
        .appendField(new Blockly.FieldDropdown([['เปิด','1'],['ปิด','0']]), 'INV');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#6d28d9'); this.setTooltip('กลับสีหน้าจอ (ขาวเป็นดำ / ดำเป็นขาว)');
  }
};

// ══════════════════════════════════════════════════════
//  Servo Control — RAZOR-S2  (LEDC, ไม่ต้องใช้ library ภายนอก)
//  ใช้ LEDC channel 8–11 สำรองไว้สำหรับ servo 4 ตัว
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_servo'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('🎯 Servo pin')
        .appendField(new Blockly.FieldDropdown([
          ['18','18'],['19','19'],['23','23'],['5','5'],
          ['25','25'],['26','26'],['27','27'],['32','32'],['33','33']
        ]), 'PIN');
    this.appendValueInput('ANGLE').appendField('มุม');
    this.appendValueInput('SPEED').appendField('speed');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('หมุน Servo ไปมุมที่กำหนด (0–180°) แบบค่อยๆหมุน\nspeed = ms ต่อ 1° (น้อย=เร็ว)');
  }
};

Blockly.Blocks['s2_servo_fast'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚡ ServoFast pin')
        .appendField(new Blockly.FieldDropdown([
          ['18','18'],['19','19'],['23','23'],['5','5'],
          ['25','25'],['26','26'],['27','27'],['32','32'],['33','33']
        ]), 'PIN');
    this.appendValueInput('ANGLE').appendField('มุม');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2');
    this.setTooltip('หมุน Servo ไปมุมทันที ไม่มีการค่อยๆหมุน');
  }
};

// ══════════════════════════════════════════════════════
//  Motor Control — RAZOR-S2  (S2_motor.h)
//  ซ้าย: pin2(ถอย) + pin4(หน้า)   ขวา: pin16(ถอย) + pin17(หน้า)
//  ความเร็ว: -100 (ถอย) ~ 0 (หยุด) ~ +100 (ไปหน้า)
// ══════════════════════════════════════════════════════

Blockly.Blocks['s2_motor_l'] = {
  init: function() {
    this.appendValueInput('SPEED')
        .appendField('🔴 มอเตอร์ซ้าย  ความเร็ว');
    this.appendDummyInput().appendField('%');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('ควบคุมมอเตอร์ซ้าย  −100 (ถอย) ถึง 100 (หน้า)');
  }
};

Blockly.Blocks['s2_motor_r'] = {
  init: function() {
    this.appendValueInput('SPEED')
        .appendField('🔴 มอเตอร์ขวา  ความเร็ว');
    this.appendDummyInput().appendField('%');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('ควบคุมมอเตอร์ขวา  −100 (ถอย) ถึง 100 (หน้า)');
  }
};


Blockly.Blocks['s2_motor_stop'] = {
  init: function() {
    this.appendDummyInput().appendField('⏹ หยุดมอเตอร์');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('หยุดมอเตอร์ทั้งสองล้อทันที');
  }
};

Blockly.Blocks['s2_motor_offset'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('⚙️ Motor Offset ซ้าย');
    this.appendValueInput('LEFT');
    this.appendDummyInput().appendField('ขวา');
    this.appendValueInput('RIGHT');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b91c1c');
    this.setTooltip('ปรับชดเชยมอเตอร์ให้หุ่นยนต์วิ่งตรง\nใส่ใน setup | ช่วง −20 ถึง 20');
  }
};

// forever — while(true)
// แต่ละ board กำหนด style เองได้อิสระ (สี, tooltip, format)
Blockly.Blocks['forever'] = {
  init: function() {
    this.appendStatementInput('DO').appendField('🔁 Forever');
    this.setPreviousStatement(true);
    this.setNextStatement(false);
    this.setColour('#e63946');
    this.setTooltip('while(true) — วนซ้ำตลอดไป');
  }
};
