// ============================================================
//  ESP32 Board Blocks — มาตรฐาน Arduino ESP32
//  ครอบคลุม: Digital I/O, Analog, PWM, Serial, WiFi, 
//             LED PWM (LEDC), Touch, Timer, I2C, SPI
// ============================================================

// ══════════════════════════════════════════════════════
//  I/O — Digital / Analog / PWM
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_digital_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalWrite pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('=')
        .appendField(new Blockly.FieldDropdown([['HIGH','HIGH'],['LOW','LOW']]), 'VAL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('ตั้งค่า digital output');
  }
};

Blockly.Blocks['esp32_digital_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalRead pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e'); this.setTooltip('อ่านค่า digital input (0/1)');
  }
};

Blockly.Blocks['esp32_pin_mode'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('pinMode pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('เป็น')
        .appendField(new Blockly.FieldDropdown([
          ['OUTPUT','OUTPUT'],['INPUT','INPUT'],
          ['INPUT_PULLUP','INPUT_PULLUP'],['INPUT_PULLDOWN','INPUT_PULLDOWN']
        ]), 'MODE');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('ตั้งค่าโหมดของ pin');
  }
};

Blockly.Blocks['esp32_analog_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogRead pin')
        .appendField(new Blockly.FieldDropdown([
          ['34','34'],['35','35'],['36','36'],['39','39'],
          ['32','32'],['33','33'],['25','25'],['26','26'],['27','27']
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e'); this.setTooltip('อ่าน ADC 0-4095 (12-bit)');
  }
};

Blockly.Blocks['esp32_analog_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogWrite pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('ค่า');
    this.appendValueInput('VAL').setCheck('Number');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('PWM 0-255');
  }
};

// ══════════════════════════════════════════════════════
//  Serial
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_serial_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Serial.begin')
        .appendField(new Blockly.FieldDropdown([
          ['115200','115200'],['9600','9600'],['57600','57600'],['230400','230400']
        ]), 'BAUD');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('เริ่ม Serial communication');
  }
};

Blockly.Blocks['esp32_serial_print'] = {
  init: function() {
    this.appendValueInput('VAL')
        .appendField('Serial.print');
    this.appendDummyInput()
        .appendField(new Blockly.FieldCheckbox('TRUE'), 'NL')
        .appendField('newline');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('พิมพ์ข้อความออก Serial');
  }
};

Blockly.Blocks['esp32_serial_println'] = {
  init: function() {
    this.appendValueInput('VAL')
        .appendField('Serial.println');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('พิมพ์ข้อความพร้อม newline');
  }
};

Blockly.Blocks['esp32_serial_available'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.available()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b'); this.setTooltip('จำนวน bytes ที่รอใน buffer');
  }
};

Blockly.Blocks['esp32_serial_read'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.read()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b'); this.setTooltip('อ่าน 1 byte จาก Serial');
  }
};

Blockly.Blocks['esp32_serial_readstring'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.readString()');
    this.setOutput(true, 'String');
    this.setColour('#c0392b'); this.setTooltip('อ่าน String จาก Serial');
  }
};

// ══════════════════════════════════════════════════════
//  WiFi
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_wifi_connect'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('WiFi เชื่อมต่อ SSID')
        .appendField(new Blockly.FieldTextInput('MyWiFi'), 'SSID');
    this.appendDummyInput()
        .appendField('Password')
        .appendField(new Blockly.FieldTextInput('password'), 'PASS');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2'); this.setTooltip('เชื่อมต่อ WiFi');
  }
};

Blockly.Blocks['esp32_wifi_connected'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi เชื่อมต่ออยู่?');
    this.setOutput(true, 'Boolean');
    this.setColour('#0891b2'); this.setTooltip('true ถ้า WiFi connected');
  }
};

Blockly.Blocks['esp32_wifi_ip'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi IP Address');
    this.setOutput(true, 'String');
    this.setColour('#0891b2'); this.setTooltip('คืน IP address เป็น String');
  }
};

Blockly.Blocks['esp32_wifi_disconnect'] = {
  init: function() {
    this.appendDummyInput().appendField('WiFi ตัดการเชื่อมต่อ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0891b2'); this.setTooltip('ตัด WiFi');
  }
};

// ══════════════════════════════════════════════════════
//  LED (Onboard + LEDC PWM)
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_builtin_led'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LED บนบอร์ด')
        .appendField(new Blockly.FieldDropdown([['เปิด','HIGH'],['ปิด','LOW']]), 'VAL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('LED pin 2 บน ESP32');
  }
};

Blockly.Blocks['esp32_ledc_setup'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC setup channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH')
        .appendField('freq')
        .appendField(new Blockly.FieldNumber(5000), 'FREQ')
        .appendField('Hz resolution')
        .appendField(new Blockly.FieldNumber(8, 1, 16), 'RES')
        .appendField('bit');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('ตั้งค่า LEDC PWM channel');
  }
};

Blockly.Blocks['esp32_ledc_attach'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC attach pin')
        .appendField(new Blockly.FieldNumber(2, 0, 39), 'PIN')
        .appendField('channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b');
  }
};

Blockly.Blocks['esp32_ledc_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('LEDC write channel')
        .appendField(new Blockly.FieldNumber(0, 0, 15), 'CH')
        .appendField('duty');
    this.appendValueInput('DUTY').setCheck('Number');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('ตั้ง duty cycle 0-255');
  }
};

// ══════════════════════════════════════════════════════
//  Touch Sensor (ESP32 built-in)
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_touch_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('touchRead pin')
        .appendField(new Blockly.FieldDropdown([
          ['T0 (GPIO4)','4'],['T1 (GPIO0)','0'],['T2 (GPIO2)','2'],
          ['T3 (GPIO15)','15'],['T4 (GPIO13)','13'],['T5 (GPIO12)','12'],
          ['T6 (GPIO14)','14'],['T7 (GPIO27)','27'],['T8 (GPIO33)','33'],['T9 (GPIO32)','32']
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#8b5cf6'); this.setTooltip('อ่านค่า capacitive touch (ยิ่งต่ำยิ่งถูกแตะ)');
  }
};

// ══════════════════════════════════════════════════════
//  Timer / Delay
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_delay_ms'] = {
  init: function() {
    this.appendValueInput('TIME')
        .appendField('รอ (ms)');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8'); this.setTooltip('หน่วงเวลา millisecond');
  }
};

Blockly.Blocks['esp32_millis'] = {
  init: function() {
    this.appendDummyInput().appendField('millis()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8'); this.setTooltip('เวลาที่ผ่านไปตั้งแต่เปิดบอร์ด (ms)');
  }
};

Blockly.Blocks['esp32_micros'] = {
  init: function() {
    this.appendDummyInput().appendField('micros()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8'); this.setTooltip('เวลาที่ผ่านไปตั้งแต่เปิดบอร์ด (µs)');
  }
};

// ══════════════════════════════════════════════════════
//  Math / Utility
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_map'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('map');
    this.appendValueInput('IN_MIN').appendField('จาก');
    this.appendValueInput('IN_MAX').appendField('ถึง');
    this.appendValueInput('OUT_MIN').appendField('→');
    this.appendValueInput('OUT_MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('แปลงช่วงค่า');
  }
};

Blockly.Blocks['esp32_constrain'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('constrain');
    this.appendValueInput('MIN').appendField('min');
    this.appendValueInput('MAX').appendField('max');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('จำกัดค่าอยู่ในช่วง min-max');
  }
};

Blockly.Blocks['esp32_random'] = {
  init: function() {
    this.appendValueInput('MIN').appendField('random จาก');
    this.appendValueInput('MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('สุ่มตัวเลข');
  }
};

// ══════════════════════════════════════════════════════
//  ESP32 System
// ══════════════════════════════════════════════════════

Blockly.Blocks['esp32_restart'] = {
  init: function() {
    this.appendDummyInput().appendField('ESP.restart()');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#dc2626'); this.setTooltip('รีสตาร์ท ESP32');
  }
};

Blockly.Blocks['esp32_free_heap'] = {
  init: function() {
    this.appendDummyInput().appendField('ESP.getFreeHeap()');
    this.setOutput(true, 'Number');
    this.setColour('#dc2626'); this.setTooltip('RAM ที่เหลือ (bytes)');
  }
};

// forever — while(true)
// แต่ละ board กำหนด style เองได้อิสระ (สี, tooltip, format)
Blockly.Blocks['forever'] = {
  init: function() {
    this.appendStatementInput('DO').appendField('🔁 Forever');
    this.setPreviousStatement(true);
    this.setNextStatement(false);
    this.setColour('#e63946');
    this.setTooltip('while(true) — วนซ้ำตลอดไป');
  }
};
