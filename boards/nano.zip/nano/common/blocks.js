// ============================================================
//  Arduino Nano Board Blocks — มาตรฐาน AVR Arduino
//  ครอบคลุม: Digital I/O, Analog, PWM, Serial, Servo,
//             Tone, EEPROM, Interrupt, LED
// ============================================================

// ══════════════════════════════════════════════════════
//  I/O — Digital / Analog / PWM
// ══════════════════════════════════════════════════════

Blockly.Blocks['nano_pin_mode'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('pinMode pin')
        .appendField(new Blockly.FieldNumber(2, 0, 19), 'PIN')
        .appendField('เป็น')
        .appendField(new Blockly.FieldDropdown([
          ['OUTPUT','OUTPUT'],['INPUT','INPUT'],['INPUT_PULLUP','INPUT_PULLUP']
        ]), 'MODE');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('ตั้งค่าโหมด pin');
  }
};

Blockly.Blocks['nano_digital_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalWrite pin')
        .appendField(new Blockly.FieldNumber(2, 0, 13), 'PIN')
        .appendField('=')
        .appendField(new Blockly.FieldDropdown([['HIGH','HIGH'],['LOW','LOW']]), 'VAL');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('ตั้งค่า digital output');
  }
};

Blockly.Blocks['nano_digital_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('digitalRead pin')
        .appendField(new Blockly.FieldNumber(2, 0, 13), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e'); this.setTooltip('อ่าน digital input (0/1)');
  }
};

Blockly.Blocks['nano_analog_read'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogRead')
        .appendField(new Blockly.FieldDropdown([
          ['A0','A0'],['A1','A1'],['A2','A2'],
          ['A3','A3'],['A4','A4'],['A5','A5']
        ]), 'PIN');
    this.setOutput(true, 'Number');
    this.setColour('#0f766e'); this.setTooltip('อ่าน ADC 0-1023 (10-bit)');
  }
};

Blockly.Blocks['nano_analog_write'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('analogWrite (PWM) pin')
        .appendField(new Blockly.FieldDropdown([
          ['3','3'],['5','5'],['6','6'],['9','9'],['10','10'],['11','11']
        ]), 'PIN')
        .appendField('ค่า');
    this.appendValueInput('VAL').setCheck('Number');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#0f766e'); this.setTooltip('PWM 0-255 (เฉพาะ pin 3,5,6,9,10,11)');
  }
};

// ══════════════════════════════════════════════════════
//  LED บนบอร์ด (pin 13)
// ══════════════════════════════════════════════════════

Blockly.Blocks['nano_led_on'] = {
  init: function() {
    this.appendDummyInput().appendField('LED บนบอร์ด เปิด');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('เปิด LED pin 13');
  }
};

Blockly.Blocks['nano_led_off'] = {
  init: function() {
    this.appendDummyInput().appendField('LED บนบอร์ด ปิด');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('ปิด LED pin 13');
  }
};

Blockly.Blocks['nano_led_toggle'] = {
  init: function() {
    this.appendDummyInput().appendField('LED บนบอร์ด สลับ');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#f59e0b'); this.setTooltip('สลับ LED pin 13 on/off');
  }
};

// ══════════════════════════════════════════════════════
//  Serial
// ══════════════════════════════════════════════════════

Blockly.Blocks['nano_serial_begin'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('Serial.begin')
        .appendField(new Blockly.FieldDropdown([
          ['9600','9600'],['115200','115200'],['57600','57600'],['38400','38400']
        ]), 'BAUD');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b'); this.setTooltip('เริ่ม Serial');
  }
};

Blockly.Blocks['nano_serial_print'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('Serial.print');
    this.appendDummyInput()
        .appendField(new Blockly.FieldCheckbox('TRUE'), 'NL')
        .appendField('newline');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#c0392b');
  }
};

Blockly.Blocks['nano_serial_available'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.available()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b'); this.setTooltip('bytes ที่รอใน buffer');
  }
};

Blockly.Blocks['nano_serial_read'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.read()');
    this.setOutput(true, 'Number');
    this.setColour('#c0392b'); this.setTooltip('อ่าน 1 byte');
  }
};

Blockly.Blocks['nano_serial_readstring'] = {
  init: function() {
    this.appendDummyInput().appendField('Serial.readString()');
    this.setOutput(true, 'String');
    this.setColour('#c0392b');
  }
};

// ══════════════════════════════════════════════════════
//  Tone (Buzzer)
// ══════════════════════════════════════════════════════

Blockly.Blocks['nano_tone'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('tone pin')
        .appendField(new Blockly.FieldNumber(8, 0, 13), 'PIN')
        .appendField('ความถี่');
    this.appendValueInput('FREQ').setCheck('Number');
    this.appendDummyInput()
        .appendField('นาน (ms)');
    this.appendValueInput('DUR').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309'); this.setTooltip('เล่นเสียง tone');
  }
};

Blockly.Blocks['nano_no_tone'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('noTone pin')
        .appendField(new Blockly.FieldNumber(8, 0, 13), 'PIN');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#b45309'); this.setTooltip('หยุดเสียง tone');
  }
};

// ══════════════════════════════════════════════════════
//  Timer
// ══════════════════════════════════════════════════════

Blockly.Blocks['nano_delay_ms'] = {
  init: function() {
    this.appendValueInput('TIME').appendField('รอ (ms)');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8'); this.setTooltip('หน่วงเวลา millisecond');
  }
};

Blockly.Blocks['nano_delay_us'] = {
  init: function() {
    this.appendValueInput('TIME').appendField('รอ (µs)');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#1d4ed8'); this.setTooltip('หน่วงเวลา microsecond');
  }
};

Blockly.Blocks['nano_millis'] = {
  init: function() {
    this.appendDummyInput().appendField('millis()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8'); this.setTooltip('เวลาที่ผ่านไป (ms)');
  }
};

Blockly.Blocks['nano_micros'] = {
  init: function() {
    this.appendDummyInput().appendField('micros()');
    this.setOutput(true, 'Number');
    this.setColour('#1d4ed8'); this.setTooltip('เวลาที่ผ่านไป (µs)');
  }
};

// ══════════════════════════════════════════════════════
//  Math / Utility
// ══════════════════════════════════════════════════════

Blockly.Blocks['nano_map'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('map');
    this.appendValueInput('IN_MIN').appendField('จาก');
    this.appendValueInput('IN_MAX').appendField('ถึง');
    this.appendValueInput('OUT_MIN').appendField('→');
    this.appendValueInput('OUT_MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed'); this.setTooltip('แปลงช่วงค่า');
  }
};

Blockly.Blocks['nano_constrain'] = {
  init: function() {
    this.appendValueInput('VAL').appendField('constrain');
    this.appendValueInput('MIN').appendField('min');
    this.appendValueInput('MAX').appendField('max');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed');
  }
};

Blockly.Blocks['nano_random'] = {
  init: function() {
    this.appendValueInput('MIN').appendField('random จาก');
    this.appendValueInput('MAX').appendField('ถึง');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#7c3aed');
  }
};

// ══════════════════════════════════════════════════════
//  Interrupt
// ══════════════════════════════════════════════════════

Blockly.Blocks['nano_attach_interrupt'] = {
  init: function() {
    this.appendDummyInput()
        .appendField('attachInterrupt pin')
        .appendField(new Blockly.FieldDropdown([['2 (INT0)','2'],['3 (INT1)','3']]), 'PIN')
        .appendField('function')
        .appendField(new Blockly.FieldTextInput('myISR'), 'FUNC')
        .appendField('mode')
        .appendField(new Blockly.FieldDropdown([
          ['RISING','RISING'],['FALLING','FALLING'],['CHANGE','CHANGE']
        ]), 'MODE');
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#dc2626'); this.setTooltip('ตั้ง interrupt บน pin 2 หรือ 3');
  }
};

// ══════════════════════════════════════════════════════
//  EEPROM
// ══════════════════════════════════════════════════════

Blockly.Blocks['nano_eeprom_write'] = {
  init: function() {
    this.appendDummyInput().appendField('EEPROM.write address');
    this.appendValueInput('ADDR').setCheck('Number');
    this.appendDummyInput().appendField('ค่า');
    this.appendValueInput('VAL').setCheck('Number');
    this.setInputsInline(true);
    this.setPreviousStatement(true); this.setNextStatement(true);
    this.setColour('#475569'); this.setTooltip('เขียน 1 byte ลง EEPROM (0-1023)');
  }
};

Blockly.Blocks['nano_eeprom_read'] = {
  init: function() {
    this.appendDummyInput().appendField('EEPROM.read address');
    this.appendValueInput('ADDR').setCheck('Number');
    this.setInputsInline(true);
    this.setOutput(true, 'Number');
    this.setColour('#475569'); this.setTooltip('อ่าน 1 byte จาก EEPROM');
  }
};

// forever — while(true)
// แต่ละ board กำหนด style เองได้อิสระ (สี, tooltip, format)
Blockly.Blocks['forever'] = {
  init: function() {
    this.appendStatementInput('DO').appendField('🔁 Forever');
    this.setPreviousStatement(true);
    this.setNextStatement(false);
    this.setColour('#e63946');
    this.setTooltip('while(true) — วนซ้ำตลอดไป');
  }
};
