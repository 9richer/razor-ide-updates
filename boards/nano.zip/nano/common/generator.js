// ============================================================
//  Arduino Nano Generator
// ============================================================

// ── I/O ──
Blockly.Arduino.forBlock['nano_pin_mode'] = function(block) {
  return `pinMode(${block.getFieldValue('PIN')}, ${block.getFieldValue('MODE')});\n`;
};
Blockly.Arduino.forBlock['nano_digital_write'] = function(block) {
  return `digitalWrite(${block.getFieldValue('PIN')}, ${block.getFieldValue('VAL')});\n`;
};
Blockly.Arduino.forBlock['nano_digital_read'] = function(block) {
  return [`digitalRead(${block.getFieldValue('PIN')})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['nano_analog_read'] = function(block) {
  return [`analogRead(${block.getFieldValue('PIN')})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['nano_analog_write'] = function(block) {
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `analogWrite(${block.getFieldValue('PIN')}, ${val});\n`;
};

// ── LED ──
Blockly.Arduino.forBlock['nano_led_on']     = () => 'digitalWrite(13, HIGH);\n';
Blockly.Arduino.forBlock['nano_led_off']    = () => 'digitalWrite(13, LOW);\n';
Blockly.Arduino.forBlock['nano_led_toggle'] = () => 'digitalWrite(13, !digitalRead(13));\n';

// ── Serial ──
Blockly.Arduino.forBlock['nano_serial_begin'] = function(block) {
  return `Serial.begin(${block.getFieldValue('BAUD')});\n`;
};
Blockly.Arduino.forBlock['nano_serial_print'] = function(block) {
  const val = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '""';
  const nl  = block.getFieldValue('NL') === 'TRUE';
  return nl ? `Serial.println(${val});\n` : `Serial.print(${val});\n`;
};
Blockly.Arduino.forBlock['nano_serial_available'] = () => ['Serial.available()', Blockly.Arduino.ORDER_ATOMIC];
Blockly.Arduino.forBlock['nano_serial_read']      = () => ['Serial.read()', Blockly.Arduino.ORDER_ATOMIC];
Blockly.Arduino.forBlock['nano_serial_readstring']= () => ['Serial.readString()', Blockly.Arduino.ORDER_ATOMIC];

// ── Tone ──
Blockly.Arduino.forBlock['nano_tone'] = function(block) {
  const pin  = block.getFieldValue('PIN');
  const freq = Blockly.Arduino.valueToCode(block, 'FREQ', Blockly.Arduino.ORDER_ATOMIC) || '1000';
  const dur  = Blockly.Arduino.valueToCode(block, 'DUR',  Blockly.Arduino.ORDER_ATOMIC) || '200';
  return `tone(${pin}, ${freq}, ${dur});\n`;
};
Blockly.Arduino.forBlock['nano_no_tone'] = function(block) {
  return `noTone(${block.getFieldValue('PIN')});\n`;
};

// ── Timer ──
Blockly.Arduino.forBlock['nano_delay_ms'] = function(block) {
  const t = Blockly.Arduino.valueToCode(block, 'TIME', Blockly.Arduino.ORDER_ATOMIC) || '1000';
  return `delay(${t});\n`;
};
Blockly.Arduino.forBlock['nano_delay_us'] = function(block) {
  const t = Blockly.Arduino.valueToCode(block, 'TIME', Blockly.Arduino.ORDER_ATOMIC) || '100';
  return `delayMicroseconds(${t});\n`;
};
Blockly.Arduino.forBlock['nano_millis'] = () => ['millis()', Blockly.Arduino.ORDER_ATOMIC];
Blockly.Arduino.forBlock['nano_micros'] = () => ['micros()', Blockly.Arduino.ORDER_ATOMIC];

// ── Math ──
Blockly.Arduino.forBlock['nano_map'] = function(block) {
  const v  = Blockly.Arduino.valueToCode(block, 'VAL',     Blockly.Arduino.ORDER_ATOMIC) || '0';
  const i0 = Blockly.Arduino.valueToCode(block, 'IN_MIN',  Blockly.Arduino.ORDER_ATOMIC) || '0';
  const i1 = Blockly.Arduino.valueToCode(block, 'IN_MAX',  Blockly.Arduino.ORDER_ATOMIC) || '1023';
  const o0 = Blockly.Arduino.valueToCode(block, 'OUT_MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const o1 = Blockly.Arduino.valueToCode(block, 'OUT_MAX', Blockly.Arduino.ORDER_ATOMIC) || '255';
  return [`map(${v}, ${i0}, ${i1}, ${o0}, ${o1})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['nano_constrain'] = function(block) {
  const v  = Blockly.Arduino.valueToCode(block, 'VAL', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mn = Blockly.Arduino.valueToCode(block, 'MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mx = Blockly.Arduino.valueToCode(block, 'MAX', Blockly.Arduino.ORDER_ATOMIC) || '255';
  return [`constrain(${v}, ${mn}, ${mx})`, Blockly.Arduino.ORDER_ATOMIC];
};
Blockly.Arduino.forBlock['nano_random'] = function(block) {
  const mn = Blockly.Arduino.valueToCode(block, 'MIN', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const mx = Blockly.Arduino.valueToCode(block, 'MAX', Blockly.Arduino.ORDER_ATOMIC) || '100';
  return [`random(${mn}, ${mx})`, Blockly.Arduino.ORDER_ATOMIC];
};

// ── Interrupt ──
Blockly.Arduino.forBlock['nano_attach_interrupt'] = function(block) {
  const pin  = block.getFieldValue('PIN');
  const func = block.getFieldValue('FUNC');
  const mode = block.getFieldValue('MODE');
  return `attachInterrupt(digitalPinToInterrupt(${pin}), ${func}, ${mode});\n`;
};

// ── EEPROM ──
Blockly.Arduino.forBlock['nano_eeprom_write'] = function(block) {
  const addr = Blockly.Arduino.valueToCode(block, 'ADDR', Blockly.Arduino.ORDER_ATOMIC) || '0';
  const val  = Blockly.Arduino.valueToCode(block, 'VAL',  Blockly.Arduino.ORDER_ATOMIC) || '0';
  return `EEPROM.write(${addr}, ${val});\n`;
};
Blockly.Arduino.forBlock['nano_eeprom_read'] = function(block) {
  const addr = Blockly.Arduino.valueToCode(block, 'ADDR', Blockly.Arduino.ORDER_ATOMIC) || '0';
  return [`EEPROM.read(${addr})`, Blockly.Arduino.ORDER_ATOMIC];
};

// forever — while(true)
Blockly.Arduino.forBlock['forever'] = function(block) {
  const body = Blockly.Arduino.statementToCode(block, 'DO');
  return 'while (true) {\n' + body + '}\n';
};
